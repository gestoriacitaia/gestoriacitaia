-- Migration: Fix RLS policies for referral tables (USING vs WITH CHECK)

DO $$ 
BEGIN
    -- Drop existing potentially incorrect policies
    DROP POLICY IF EXISTS "Users can insert own referrals" ON tabla_referidos;
    DROP POLICY IF EXISTS "Users can view own referrals" ON tabla_referidos;
    DROP POLICY IF EXISTS "Users can update own referrals" ON tabla_referidos;
    DROP POLICY IF EXISTS "Users can delete own referrals" ON tabla_referidos;
    
    DROP POLICY IF EXISTS "Users can insert own rewards" ON tabla_referral_rewards;
    DROP POLICY IF EXISTS "Users can view own rewards" ON tabla_referral_rewards;
    DROP POLICY IF EXISTS "Users can update own rewards" ON tabla_referral_rewards;
    DROP POLICY IF EXISTS "Users can delete own rewards" ON tabla_referral_rewards;
END $$;

-- Enable Row Level Security
ALTER TABLE tabla_referidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE tabla_referral_rewards ENABLE ROW LEVEL SECURITY;

-- ==========================================
-- tabla_referidos Policies
-- ==========================================

-- SELECT, UPDATE, DELETE strictly use USING
CREATE POLICY "Users can view own referrals" ON tabla_referidos 
    FOR SELECT USING (auth.uid() = referrer_id OR auth.uid() = referred_user_id);
    
CREATE POLICY "Users can update own referrals" ON tabla_referidos 
    FOR UPDATE USING (auth.uid() = referrer_id OR auth.uid() = referred_user_id);
    
CREATE POLICY "Users can delete own referrals" ON tabla_referidos 
    FOR DELETE USING (auth.uid() = referrer_id OR auth.uid() = referred_user_id);
    
-- INSERT strictly uses WITH CHECK (Task 1)
-- Added `OR auth.uid() = referred_user_id` so the tracked new user can successfully insert the row during signup.
CREATE POLICY "Users can insert own referrals" ON tabla_referidos 
    FOR INSERT WITH CHECK (auth.uid() = referrer_id OR auth.uid() = referred_user_id);


-- ==========================================
-- tabla_referral_rewards Policies
-- ==========================================

-- SELECT, UPDATE, DELETE strictly use USING
CREATE POLICY "Users can view own rewards" ON tabla_referral_rewards 
    FOR SELECT USING (auth.uid() = user_id);
    
CREATE POLICY "Users can update own rewards" ON tabla_referral_rewards 
    FOR UPDATE USING (auth.uid() = user_id);
    
CREATE POLICY "Users can delete own rewards" ON tabla_referral_rewards 
    FOR DELETE USING (auth.uid() = user_id);
    
-- INSERT strictly uses WITH CHECK (Task 2)
-- Verifies that the reward being created for the user actually has a valid referral linked to them.
CREATE POLICY "Users can insert own rewards" ON tabla_referral_rewards 
    FOR INSERT WITH CHECK (
        auth.uid() = user_id AND 
        EXISTS (SELECT 1 FROM tabla_referidos WHERE referrer_id = user_id)
    );