-- Migration for Subscriptions Table

CREATE TABLE IF NOT EXISTS subscriptions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    plan_name TEXT NOT NULL,
    stripe_session_id TEXT UNIQUE,
    amount DECIMAL(10, 2),
    currency TEXT DEFAULT 'eur',
    status TEXT NOT NULL CHECK (status IN ('active', 'canceled', 'expired', 'past_due', 'pending')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ
);

-- RLS Policies
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscriptions" 
    ON subscriptions FOR SELECT 
    USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage subscriptions" 
    ON subscriptions FOR ALL 
    USING (true)
    WITH CHECK (true);