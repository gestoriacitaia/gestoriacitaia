-- Avatar System Tables
-- Run this in your Supabase SQL Editor

-- 1. Avatar Sessions
CREATE TABLE IF NOT EXISTS avatar_sessions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id), -- Or text if using mock auth
    avatar_id TEXT NOT NULL,
    mode TEXT NOT NULL,
    started_at TIMESTAMPTZ DEFAULT NOW(),
    ended_at TIMESTAMPTZ
);

-- 2. User Interactions (Chat History)
CREATE TABLE IF NOT EXISTS user_interactions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    session_id UUID REFERENCES avatar_sessions(id),
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Document Verifications
CREATE TABLE IF NOT EXISTS document_verifications (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID, -- Link to user
    document_type TEXT NOT NULL,
    status TEXT NOT NULL, -- 'verified', 'rejected', 'pending'
    metadata JSONB, -- Stores non-sensitive result data
    verified_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Form Submissions
CREATE TABLE IF NOT EXISTS form_submissions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    user_id UUID,
    form_type TEXT NOT NULL,
    form_data JSONB, -- Encrypt sensitive data in application layer before storing
    status TEXT DEFAULT 'draft',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS Policies (Basic)
ALTER TABLE avatar_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_interactions ENABLE ROW LEVEL SECURITY;

-- Allow users to see their own data (assuming auth.uid() works)
CREATE POLICY "Users can view own sessions" ON avatar_sessions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own sessions" ON avatar_sessions FOR INSERT WITH CHECK (auth.uid() = user_id);