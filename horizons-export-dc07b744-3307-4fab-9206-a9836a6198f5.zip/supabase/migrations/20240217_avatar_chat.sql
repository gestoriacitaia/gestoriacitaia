-- Create Conversations Table
CREATE TABLE IF NOT EXISTS conversations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_message TEXT NOT NULL,
    avatar_response TEXT NOT NULL,
    language VARCHAR(50),
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    session_id UUID
);

-- Create Avatar Sessions Table
CREATE TABLE IF NOT EXISTS avatar_sessions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    avatar_id VARCHAR(100),
    language VARCHAR(50),
    duration INTEGER, -- in seconds
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS (Row Level Security) if needed, but for now we'll allow insert/select for public for the demo
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE avatar_sessions ENABLE ROW LEVEL SECURITY;

-- Simple policies for development (WARNING: Not for production without auth)
CREATE POLICY "Enable insert for all users" ON conversations FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable read for all users" ON conversations FOR SELECT USING (true);

CREATE POLICY "Enable insert for all users" ON avatar_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable read for all users" ON avatar_sessions FOR SELECT USING (true);