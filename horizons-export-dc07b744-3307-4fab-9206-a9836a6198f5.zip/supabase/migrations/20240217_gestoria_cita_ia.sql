-- Migration for GestoríaCitaIA Backend Schema

-- 1. User Subscriptions Table
CREATE TABLE IF NOT EXISTS users_subscriptions (
    user_id UUID PRIMARY KEY REFERENCES auth.users(id),
    plan_tier TEXT NOT NULL CHECK (plan_tier IN ('basic', 'standard', 'pro')),
    active_until TIMESTAMPTZ NOT NULL,
    consent_rgpd BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. User Consultations (Chat History)
CREATE TABLE IF NOT EXISTS user_consultations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    avatar_mode TEXT NOT NULL,
    messages JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Form Submissions (PDF Generation)
CREATE TABLE IF NOT EXISTS form_submissions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    form_type TEXT NOT NULL, -- EX-10, EX-11 etc
    data_json JSONB NOT NULL, -- Encrypted content ideally
    pdf_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Document Verifications
CREATE TABLE IF NOT EXISTS document_verifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    document_type TEXT NOT NULL,
    validation_result JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. WhatsApp Preferences
CREATE TABLE IF NOT EXISTS whatsapp_preferences (
    user_id UUID REFERENCES auth.users(id),
    phone_number TEXT NOT NULL,
    province TEXT NOT NULL,
    opted_in BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, phone_number)
);

-- 6. RLS Policies
ALTER TABLE users_subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own subscription" ON users_subscriptions FOR SELECT USING (auth.uid() = user_id);

ALTER TABLE user_consultations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own consultations" ON user_consultations FOR SELECT USING (auth.uid() = user_id);

ALTER TABLE whatsapp_preferences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage own preferences" ON whatsapp_preferences FOR ALL USING (auth.uid() = user_id);