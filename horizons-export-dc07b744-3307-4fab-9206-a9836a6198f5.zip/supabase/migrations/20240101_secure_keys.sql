-- Enable pgcrypto for encryption
create extension if not exists pgcrypto;

-- Create API Keys table
create table public.api_keys (
  id uuid default gen_random_uuid() primary key,
  service_name text not null unique,
  encrypted_key text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable RLS
alter table public.api_keys enable row level security;

-- Create policy: Only service role can access keys (or specific admin users)
create policy "Allow service role full access" 
on public.api_keys 
for all 
to service_role 
using (true) 
with check (true);

-- Functions for key management
create or replace function encrypt_key(key_value text, secret text)
returns text as $$
begin
  return pgp_sym_encrypt(key_value, secret);
end;
$$ language plpgsql security definer;

create or replace function decrypt_key(service text, secret text)
returns text as $$
declare
  enc_key text;
begin
  select encrypted_key into enc_key from public.api_keys where service_name = service;
  return pgp_sym_decrypt(enc_key::bytea, secret);
end;
$$ language plpgsql security definer;