import React from 'react';
import { FileText, Download, CheckCircle, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DocumentDownloadPanel = ({ documents, onDownloadAll }) => {
  if (!documents) return null;

  const docTypes = [
    { key: 'summary', label: 'Resumen de Consulta', icon: FileText },
    { key: 'recommendations', label: 'Recomendaciones Legales', icon: CheckCircle },
    { key: 'receipt', label: 'Recibo de Pago', icon: FileText },
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 w-full animate-in fade-in slide-in-from-bottom-4">
      <h3 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
        <Package className="w-5 h-5 text-cyan" />
        Documentos Generados
      </h3>
      
      <div className="grid gap-3 mb-6">
        {docTypes.map((type) => (
          documents[type.key] && (
            <div key={type.key} className="flex items-center justify-between p-3 bg-slate-950 rounded-lg border border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-900 rounded-full text-cyan">
                  <type.icon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{type.label}</p>
                  <p className="text-xs text-slate-500">PDF • Listo para descargar</p>
                </div>
              </div>
              <div className="flex gap-2">
                <a 
                  href={documents[type.key]} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-2 text-slate-400 hover:text-white transition-colors"
                  title="Preview"
                >
                  <FileText className="w-4 h-4" />
                </a>
                <a 
                  href={documents[type.key]} 
                  download 
                  className="p-2 text-cyan hover:text-cyan/80 transition-colors"
                  title="Download"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>
            </div>
          )
        ))}
      </div>

      <Button 
        onClick={() => onDownloadAll(documents)}
        className="w-full bg-cyan hover:bg-cyan/90 text-navy font-bold"
      >
        <Download className="w-4 h-4 mr-2" />
        Descargar Todo (.zip)
      </Button>
    </div>
  );
};

export default DocumentDownloadPanel;