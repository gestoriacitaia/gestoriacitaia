import React from 'react';
import { useNavigate } from 'react-router-dom';
import { XCircle, ArrowLeft } from 'lucide-react';
import GestoriaHeader from './GestoriaHeader';
import Footer from './Footer';

const ConsultationPaymentCancelled = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col font-sans">
      <GestoriaHeader />
      
      <main className="flex-1 container mx-auto px-4 flex flex-col items-center justify-center py-20">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center shadow-2xl">
          <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <XCircle className="w-10 h-10 text-red-500" />
          </div>
          
          <h1 className="text-3xl font-bold mb-2 text-white">Payment Cancelled</h1>
          <p className="text-slate-400 mb-8">
            You have not been charged. The consultation booking was cancelled.
          </p>

          <button
            onClick={() => navigate('/consultation/payment')}
            className="w-full bg-cyan hover:bg-cyan/90 text-navy font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            Try Again
          </button>
          
          <button
            onClick={() => navigate('/')}
            className="w-full mt-4 text-slate-500 hover:text-slate-300 text-sm font-medium transition-colors"
          >
            Return to Home
          </button>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ConsultationPaymentCancelled;