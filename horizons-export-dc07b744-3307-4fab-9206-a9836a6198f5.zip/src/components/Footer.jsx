import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Mail, MapPin, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const { t } = useLanguage();

  return (
    <footer className="w-full bg-navy-dark text-gray-400 py-12 border-t border-navy-light">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-cyan rounded-lg flex items-center justify-center font-bold text-white">IA</div>
              <span className="text-xl font-bold text-white">gestoria<span className="text-cyan">cita</span>ia</span>
            </div>
            <p className="text-sm text-gray-500 max-w-sm">
              {t.aboutText}
            </p>
          </div>

          {/* Legal Links */}
          <div className="flex flex-col gap-3 text-sm">
             <h4 className="font-bold text-white mb-2 uppercase text-xs tracking-wider">Legal</h4>
             <Link to="/aviso-legal" className="hover:text-cyan transition-colors">Aviso Legal</Link>
             <Link to="/politica-privacidad" className="hover:text-cyan transition-colors">{t.privacy}</Link>
             <Link to="/politica-cookies" className="hover:text-cyan transition-colors">Política de Cookies</Link>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-3 text-sm">
             <h4 className="font-bold text-white mb-2 uppercase text-xs tracking-wider">{t.contact}</h4>
             <a href="mailto:info@gestoriacitaia.com" className="flex items-center gap-2 hover:text-cyan transition-colors">
               <Mail className="w-4 h-4" /> info@gestoriacitaia.com
             </a>
             <span className="flex items-center gap-2 text-gray-500">
               <MapPin className="w-4 h-4" /> Madrid, España
             </span>
          </div>
        </div>

        <div className="border-t border-navy-lighter pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-600">
          <p>© 2026 {t.siteName}. {t.rights}</p>
          <div className="flex items-center gap-2 text-cyan">
            <ShieldCheck className="w-3 h-3" />
            <span>Secure SSL Encrypted • RGPD Compliant</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;