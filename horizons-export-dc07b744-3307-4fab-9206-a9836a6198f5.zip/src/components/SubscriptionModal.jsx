import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, ArrowRight, Download, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SubscriptionModal = ({ isOpen, onClose, planName, price, expiryDate }) => {
  const navigate = useNavigate();

  // Auto-close logic or navigate could be handled by parent, but simple timeout here is nice
  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        // Optional: onClose(); 
      }, 8000);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  const handleGoToChat = () => {
    onClose();
    navigate('/consultation');
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-navy border border-cyan/30 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl relative"
        >
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6 ring-2 ring-green-500/50">
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>

            <h2 className="text-2xl font-bold text-white mb-2">¡Suscripción Activada!</h2>
            <p className="text-gray-400 mb-6">
              Has suscrito correctamente al <span className="text-cyan font-semibold">{planName || 'Plan Básico'}</span>.
            </p>

            <div className="bg-navy-light rounded-xl p-4 mb-6 border border-navy-lighter text-left">
              <div className="flex justify-between mb-2">
                <span className="text-gray-400 text-sm">Estado</span>
                <span className="text-green-400 text-sm font-bold bg-green-900/30 px-2 py-0.5 rounded">Activo</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-400 text-sm">Precio</span>
                <span className="text-white text-sm font-bold">{price}€ / mes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400 text-sm">Válido hasta</span>
                <span className="text-white text-sm">
                  {expiryDate ? new Date(expiryDate).toLocaleDateString() : '30 días'}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={handleGoToChat}
                className="w-full bg-cyan hover:bg-cyan-dark text-white font-bold py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02]"
              >
                Ir al Chatbot IA
                <ArrowRight className="w-4 h-4" />
              </button>
              
              <button className="w-full bg-navy-light hover:bg-navy-lighter text-gray-300 font-medium py-3 px-6 rounded-xl flex items-center justify-center gap-2 transition-colors">
                <Download className="w-4 h-4" />
                Descargar Recibo
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default SubscriptionModal;