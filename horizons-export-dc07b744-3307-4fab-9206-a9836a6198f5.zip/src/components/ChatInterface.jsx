import React, { useState, useEffect, useRef } from 'react';
import { Send, User, Bot, X } from 'lucide-react';
import { useAvatarSystem } from '@/contexts/AvatarSystemContext';
import { useLanguage } from '@/contexts/LanguageContext';

const ChatInterface = ({ isOpen, onClose }) => {
  const { conversationHistory, addMessage } = useAvatarSystem();
  const { language } = useLanguage();
  const [inputText, setInputText] = useState("");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, conversationHistory]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    
    addMessage('user', inputText);
    setInputText("");
    
    // Simulate generic response for demo
    setTimeout(() => {
      addMessage('assistant', language === 'es' 
        ? "Gracias por tu mensaje. Estoy procesando tu solicitud." 
        : "Thank you for your message. I am processing your request.");
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="absolute inset-0 z-20 bg-slate-900/95 backdrop-blur-md flex flex-col animate-in slide-in-from-bottom duration-300 rounded-3xl overflow-hidden">
      
      {/* Header */}
      <div className="p-4 border-b border-slate-700 flex justify-between items-center bg-slate-900">
        <h3 className="text-white font-semibold">Chat</h3>
        <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {conversationHistory.length === 0 && (
          <div className="text-center text-slate-500 text-sm mt-10">
            {language === 'es' ? 'Empieza la conversación...' : 'Start the conversation...'}
          </div>
        )}
        {conversationHistory.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                msg.role === 'user' ? 'bg-blue-600' : 'bg-slate-700'
              }`}>
                {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-cyan-400" />}
              </div>
              <div className={`p-3 rounded-2xl text-sm ${
                msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700'
              }`}>
                {msg.content}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-slate-700 bg-slate-900">
        <form onSubmit={handleSend} className="relative">
          <input 
            type="text" 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={language === 'es' ? "Escribe un mensaje..." : "Type a message..."}
            className="w-full bg-slate-800 border border-slate-600 rounded-full px-5 py-3 pr-12 text-sm text-white focus:ring-2 focus:ring-blue-500 outline-none placeholder:text-slate-500"
          />
          <button 
            type="submit" 
            disabled={!inputText.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-600 hover:bg-blue-500 rounded-full text-white transition-colors disabled:opacity-50 disabled:bg-slate-700"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;