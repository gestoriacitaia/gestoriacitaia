import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { Button } from './ui/button';
import { useLanguage } from '../contexts/LanguageContext';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { language, switchLanguage } = useLanguage();

  const translations = {
    es: {
      home: 'Inicio',
      services: 'Servicios',
      pricing: 'Precios',
      contact: 'Contacto',
      castellano: 'Castellano',
      darija: 'Darija Marroquí',
    },
    ar: {
      home: 'Axxam',
      services: 'Ixeddamen',
      pricing: 'Isuman',
      contact: 'Anemhal',
      castellano: 'Tacastilanit',
      darija: 'Darija Merrukya',
    }
  };

  const t = translations[language];

  const navItems = [
    { label: t.home, href: '#home' },
    { label: t.services, href: '#services' },
    { label: t.pricing, href: '#pricing' },
    { label: t.contact, href: '#contact' },
  ];

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md shadow-md z-40"
    >
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">GA</span>
            </div>
            <span className="text-xl font-bold text-gray-900">gestoriaia.com</span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium"
              >
                {item.label}
              </a>
            ))}
          </div>

          {/* Language Selector */}
          <div className="hidden md:flex items-center gap-2">
            <Button
              onClick={() => switchLanguage('es')}
              variant={language === 'es' ? 'default' : 'outline'}
              className={language === 'es' ? 'bg-blue-600 text-white' : 'border-gray-300 text-gray-700'}
            >
              {t.castellano}
            </Button>
            <Button
              onClick={() => switchLanguage('ar')}
              variant={language === 'ar' ? 'default' : 'outline'}
              className={language === 'ar' ? 'bg-blue-600 text-white' : 'border-gray-300 text-gray-700'}
            >
              {t.darija}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            variant="ghost"
            size="icon"
            className="md:hidden text-gray-700"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden mt-4 pb-4 border-t border-gray-200 pt-4"
          >
            <div className="flex flex-col gap-4">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-gray-700 hover:text-blue-600 transition-colors duration-200 font-medium"
                >
                  {item.label}
                </a>
              ))}
              <div className="flex gap-2 mt-2">
                <Button
                  onClick={() => {
                    switchLanguage('es');
                    setMobileMenuOpen(false);
                  }}
                  variant={language === 'es' ? 'default' : 'outline'}
                  className={`flex-1 ${language === 'es' ? 'bg-blue-600 text-white' : 'border-gray-300 text-gray-700'}`}
                >
                  {t.castellano}
                </Button>
                <Button
                  onClick={() => {
                    switchLanguage('ar');
                    setMobileMenuOpen(false);
                  }}
                  variant={language === 'ar' ? 'default' : 'outline'}
                  className={`flex-1 ${language === 'ar' ? 'bg-blue-600 text-white' : 'border-gray-300 text-gray-700'}`}
                >
                  {t.darija}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </nav>
    </motion.header>
  );
};

export default Header;