import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const SimpleAvatarCard = ({ name, image, onClick, specialty, imageStyle }) => {
  const { t } = useLanguage();

  return (
    <motion.div
      whileHover={{ y: -5, borderColor: '#06B6D4' }}
      whileTap={{ scale: 0.98 }}
      className="bg-navy-light border border-navy-lighter rounded-2xl p-3 md:p-6 flex flex-col items-center gap-2 md:gap-4 shadow-lg hover:shadow-cyan/10 transition-all cursor-pointer group h-full w-full justify-between"
      onClick={onClick}
    >
      <div className="relative">
        {/* Mobile: Smaller Avatar */}
        <div className="w-16 h-16 md:w-24 md:h-24 rounded-full overflow-hidden border-2 border-cyan/30 group-hover:border-cyan transition-colors">
          <img 
            src={image || 'https://via.placeholder.com/150'} 
            alt={name || 'Avatar'} 
            className="w-full h-full object-cover" 
            style={imageStyle}
          />
        </div>
        
        {/* Online Status */}
        <div className="absolute bottom-1 right-1 w-3 h-3 md:w-4 md:h-4 rounded-full border-2 border-navy-light bg-green-500" />
      </div>

      <div className="text-center w-full">
        <h3 className="text-sm md:text-xl font-bold text-white mb-1 truncate">{name || 'Asistente'}</h3>
        {specialty && (
          <p className="text-[10px] md:text-xs text-cyan mb-2 truncate font-semibold uppercase tracking-wider">{specialty}</p>
        )}
        <button 
          className="w-full bg-cyan hover:bg-cyan-dark text-white font-bold py-1.5 md:py-2 px-1 md:px-6 rounded-lg md:rounded-xl flex items-center justify-center gap-1 md:gap-2 text-[10px] md:text-sm transition-colors shadow-lg shadow-cyan/20 group-hover:scale-105"
        >
          <MessageCircle className="w-3 h-3 md:w-4 md:h-4" />
          <span className="truncate">Hablar Ahora</span>
        </button>
      </div>
    </motion.div>
  );
};

export default SimpleAvatarCard;