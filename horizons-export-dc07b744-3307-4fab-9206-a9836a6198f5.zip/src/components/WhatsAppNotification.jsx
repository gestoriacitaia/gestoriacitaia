import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePayment } from '../contexts/PaymentContext';

const WhatsAppNotification = ({ appointment, userData }) => {
  const [status, setStatus] = useState('sending');
  const { sendWhatsAppNotification } = usePayment();
  const navigate = useNavigate();

  useEffect(() => {
    const send = async () => {
      // Send notification
      await sendWhatsAppNotification(
        userData.phone,
        userData.name,
        appointment.date,
        appointment.time
      );
      
      setStatus('sent');

      // Navigate to confirmation page after short delay
      setTimeout(() => {
        navigate('/buscar-cita-confirmation', { 
            state: { appointment, userData } 
        });
      }, 2000);
    };

    send();
  }, [appointment, userData, sendWhatsAppNotification, navigate]);

  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {status === 'sending' ? (
        <>
           <div className="relative mb-6">
            <div className="absolute inset-0 bg-green-500/20 rounded-full animate-ping"></div>
            <div className="relative bg-navy-light p-4 rounded-full border border-green-500/30">
               <MessageCircle className="w-12 h-12 text-green-500 animate-pulse" />
            </div>
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Enviando WhatsApp...</h2>
          <p className="text-gray-400">Te estamos enviando los detalles de la cita.</p>
        </>
      ) : (
        <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
        >
          <div className="bg-green-500/10 p-4 rounded-full inline-block mb-6 border border-green-500/30">
            <CheckCircle className="w-16 h-16 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">¡Mensaje Enviado!</h2>
          <p className="text-gray-400">Redirigiendo a la confirmación...</p>
        </motion.div>
      )}
    </div>
  );
};

export default WhatsAppNotification;