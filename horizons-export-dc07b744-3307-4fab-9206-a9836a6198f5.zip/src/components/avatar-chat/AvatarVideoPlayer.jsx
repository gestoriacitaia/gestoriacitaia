import React, { useRef, useEffect, useState } from 'react';
import { Loader2, AlertCircle, Play, Pause, Volume2, VolumeX } from 'lucide-react';

const AvatarVideoPlayer = ({ videoSrcObject, isLoading, error, isPlaying, onTogglePlay }) => {
  const videoRef = useRef(null);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    if (videoRef.current && videoSrcObject) {
      videoRef.current.srcObject = videoSrcObject;
      videoRef.current.play().catch(e => console.error("Error autoplay:", e));
    }
  }, [videoSrcObject]);

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <div className="relative w-full aspect-video md:aspect-[3/4] bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-700 group">
      {/* Video Element */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className={`w-full h-full object-cover transition-opacity duration-500 ${videoSrcObject ? 'opacity-100' : 'opacity-0'}`}
      />

      {/* Loading State */}
      {isLoading && !videoSrcObject && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/80 z-10 backdrop-blur-sm">
          <Loader2 className="w-12 h-12 text-cyan animate-spin mb-4" />
          <p className="text-cyan font-bold animate-pulse text-lg">Iniciando Avatar...</p>
          <p className="text-slate-400 text-xs mt-2">Estableciendo conexión segura</p>
        </div>
      )}

      {/* Idle State / Placeholder */}
      {!videoSrcObject && !isLoading && !error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 z-0 text-center p-6">
          <div className="w-24 h-24 bg-slate-800 rounded-full flex items-center justify-center mb-6 border-2 border-slate-700 shadow-inner">
            <span className="text-5xl animate-bounce">👋</span>
          </div>
          <h3 className="text-white font-bold text-xl mb-2">¡Hola! Soy tu asistente IA</h3>
          <p className="text-slate-400 text-sm max-w-xs">Selecciona un avatar arriba y pulsa "Hablar Ahora" para comenzar nuestra videollamada.</p>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/95 z-20 p-6 text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
          <p className="text-red-400 text-lg font-bold mb-2">Error de Conexión</p>
          <p className="text-slate-400 text-sm">{error}</p>
        </div>
      )}

      {/* Controls Overlay (Only when active) */}
      {videoSrcObject && (
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex items-center gap-2">
             <button onClick={onTogglePlay} className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-sm transition-colors">
               {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
             </button>
             <button onClick={toggleMute} className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-sm transition-colors">
               {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
             </button>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-white text-xs font-mono">EN VIVO</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default AvatarVideoPlayer;