import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Edit3, Download, Loader2 } from 'lucide-react';

const FormFillingAssistant = () => {
  const [formType, setFormType] = useState('EX-15');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState(null);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('form-generator', {
        body: { formType, formData: { name } }
      });
      if (error) throw error;
      setDownloadUrl(data.url);
    } catch (e) {
      console.error(e);
      alert("Error generando formulario.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-800 p-6 border border-slate-700 w-full mb-4 rounded-none">
       <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Edit3 className="text-cyan" /> Rellenar Formulario Oficial
      </h3>
      <div className="space-y-4">
        <select 
          value={formType}
          onChange={(e) => setFormType(e.target.value)}
          className="w-full bg-slate-900 border border-slate-700 text-white p-3 rounded-none focus:border-cyan outline-none"
        >
          <option value="EX-15">EX-15: NIE</option>
          <option value="EX-11">EX-11: Larga Duración</option>
          <option value="EX-10">EX-10: Arraigo</option>
        </select>
        
        <input 
          type="text" 
          placeholder="Nombre Completo"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full bg-slate-900 border border-slate-700 text-white p-3 rounded-none focus:border-cyan outline-none"
        />

        <button 
          onClick={handleGenerate}
          disabled={loading || !name}
          className="w-full bg-purple-600 text-white px-6 py-3 font-bold hover:bg-purple-500 transition-colors disabled:opacity-50 rounded-none flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="animate-spin" /> : "Generar PDF Listo para Imprimir"}
        </button>

        {downloadUrl && (
          <a href={downloadUrl} target="_blank" rel="noreferrer" className="mt-4 block text-center text-cyan hover:underline flex items-center justify-center gap-2">
            <Download className="w-4 h-4" /> Descargar Formulario Completado
          </a>
        )}
      </div>
    </div>
  );
};

export default FormFillingAssistant;