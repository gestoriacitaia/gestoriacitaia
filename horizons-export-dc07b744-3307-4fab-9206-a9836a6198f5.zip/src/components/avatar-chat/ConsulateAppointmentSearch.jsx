import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Calendar, Search, Loader2 } from 'lucide-react';

const ConsulateAppointmentSearch = () => {
  const [consulate, setConsulate] = useState('Casablanca');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('search-consulate-appointments', {
        body: { consulate }
      });
      if (error) throw error;
      setResults(data.appointments || []);
    } catch (e) {
      console.error(e);
      alert("Error al buscar citas.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-800 p-6 border border-slate-700 w-full mb-4 rounded-none">
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <Calendar className="text-cyan" /> Buscar Cita Consular (Marruecos)
      </h3>
      <div className="flex gap-4 mb-6">
        <select 
          value={consulate}
          onChange={(e) => setConsulate(e.target.value)}
          className="bg-slate-900 border border-slate-700 text-white p-3 flex-1 rounded-none focus:border-cyan outline-none"
        >
          <option value="Casablanca">Casablanca</option>
          <option value="Fez">Fez</option>
          <option value="Tánger">Tánger</option>
          <option value="Rabat">Rabat</option>
          <option value="Marrakech">Marrakech</option>
        </select>
        <button 
          onClick={handleSearch}
          disabled={loading}
          className="bg-cyan text-navy px-6 py-3 font-bold hover:bg-cyan-light transition-colors rounded-none flex items-center gap-2"
        >
          {loading ? <Loader2 className="animate-spin" /> : <Search />} Buscar
        </button>
      </div>

      {results.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm text-slate-400">Citas Disponibles:</h4>
          {results.map((res, i) => (
            <div key={i} className="bg-slate-900 p-3 border border-slate-700 flex justify-between items-center rounded-none">
              <div>
                <p className="font-bold text-white">{res.date}</p>
                <p className="text-xs text-slate-400">{res.consulate}</p>
              </div>
              <span className="text-cyan font-mono bg-cyan/10 px-3 py-1 border border-cyan/20">
                {res.time}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ConsulateAppointmentSearch;