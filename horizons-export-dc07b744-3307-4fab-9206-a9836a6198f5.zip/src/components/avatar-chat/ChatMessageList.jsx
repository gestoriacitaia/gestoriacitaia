import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Bot, Play, Pause } from 'lucide-react';

const ChatMessageList = ({ messages }) => {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[300px] max-h-[500px] bg-slate-900/50 rounded-lg scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-transparent">
      <AnimatePresence>
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-500 space-y-4 opacity-50 py-12">
            <Bot className="w-16 h-16" />
            <p className="text-sm">Selecciona un avatar e inicia una conversación...</p>
          </div>
        ) : (
          messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`flex items-end gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div 
                className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg ${
                  msg.role === 'user' ? 'bg-cyan text-navy' : 'bg-purple text-white'
                }`}
              >
                {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>
              
              <div 
                className={`flex flex-col max-w-[80%] ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div 
                  className={`p-3.5 rounded-2xl text-sm leading-relaxed shadow-md ${
                    msg.role === 'user' 
                      ? 'bg-cyan text-navy rounded-tr-none' 
                      : 'bg-slate-700 text-slate-100 rounded-tl-none border border-slate-600'
                  }`}
                >
                  {msg.content}
                  
                  {msg.audioUrl && (
                    <div className="mt-2 pt-2 border-t border-white/10 flex items-center gap-2">
                       <button className="p-1.5 rounded-full bg-white/20 hover:bg-white/30 transition-colors">
                         <Play className="w-3 h-3 text-white" />
                       </button>
                       <div className="h-1 bg-white/20 rounded-full w-24"></div>
                       <span className="text-[10px] opacity-70">Audio</span>
                    </div>
                  )}
                </div>
                
                <span className="text-[10px] text-slate-500 mt-1 px-1">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </motion.div>
          ))
        )}
      </AnimatePresence>
      <div ref={bottomRef} />
    </div>
  );
};

export default ChatMessageList;