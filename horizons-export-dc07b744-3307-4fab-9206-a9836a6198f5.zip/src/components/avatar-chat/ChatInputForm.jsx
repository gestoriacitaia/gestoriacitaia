import React, { useState, useRef } from 'react';
import { Send, Paperclip, Mic, X, File, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ChatInputForm = ({ onSend, isLoading }) => {
  const [text, setText] = useState('');
  const [file, setFile] = useState(null);
  const fileInputRef = useRef(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!text.trim() && !file) return;
    
    onSend(text, file);
    setText('');
    setFile(null);
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (selectedFile.type === 'application/pdf') {
        setFile(selectedFile);
      } else {
        alert('Por favor sube solo archivos PDF válidos.');
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 bg-slate-800 rounded-b-2xl border-t border-slate-700">
      {file && (
        <div className="flex items-center gap-2 mb-3 bg-slate-900 p-2 rounded-lg border border-slate-700 w-fit animate-in fade-in slide-in-from-bottom-2">
          <File className="w-4 h-4 text-cyan" />
          <div className="flex flex-col">
            <span className="text-xs text-slate-300 font-medium truncate max-w-[200px]">{file.name}</span>
            <span className="text-[10px] text-slate-500">{(file.size / 1024).toFixed(0)} KB • PDF</span>
          </div>
          <button 
            type="button" 
            onClick={() => setFile(null)}
            className="ml-2 text-slate-500 hover:text-red-400 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-3 text-slate-400 hover:text-cyan hover:bg-slate-700/50 rounded-xl transition-all"
          disabled={isLoading}
          title="Subir documento PDF"
        >
          <Paperclip className="w-5 h-5" />
        </button>
        <input 
          type="file"
          ref={fileInputRef}
          className="hidden"
          accept=".pdf"
          onChange={handleFileChange}
        />

        <div className="flex-1 relative">
          <input
            type="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={isLoading ? "Procesando..." : "Escribe tu consulta aquí..."}
            disabled={isLoading}
            className="w-full bg-slate-900 text-white placeholder-slate-500 border border-slate-700 rounded-xl px-4 py-3 focus:outline-none focus:border-cyan focus:ring-1 focus:ring-cyan text-sm pr-10"
          />
        </div>

        {/* Send Button (Escribir) - Reordered to appear before Mic */}
        <Button
          type="submit"
          disabled={isLoading || (!text.trim() && !file)}
          className={`p-3 h-auto rounded-xl transition-all shadow-lg ${
            isLoading || (!text.trim() && !file)
              ? 'bg-slate-700 text-slate-500 opacity-50 cursor-not-allowed'
              : 'bg-cyan text-navy hover:bg-cyan-light shadow-cyan/20'
          }`}
        >
          {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
        </Button>

        {/* Speak Button (Hablar) */}
        <button
           type="button"
           className="p-3 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl transition-colors"
           title="Hablar (Próximamente)"
        >
           <Mic className="w-5 h-5" />
        </button>
      </div>
    </form>
  );
};

export default ChatInputForm;