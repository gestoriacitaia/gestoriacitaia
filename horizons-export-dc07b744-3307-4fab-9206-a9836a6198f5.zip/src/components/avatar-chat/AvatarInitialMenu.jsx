import React from 'react';
import { FileText, Home, Languages, Calendar } from 'lucide-react';

const AvatarInitialMenu = ({ onSelectFlow }) => {
  const menuItems = [
    {
      id: 'tramites',
      title: 'Todos los trámites de extranjería',
      icon: <FileText className="w-6 h-6" />,
      avatarId: 'mohamad'
    },
    {
      id: 'ayudas',
      title: 'Ayudas económicas y alquiler de casas',
      icon: <Home className="w-6 h-6" />,
      avatarId: 'mohamad'
    },
    {
      id: 'traduccion',
      title: 'Traducción de documentos',
      icon: <Languages className="w-6 h-6" />,
      avatarId: 'khalid'
    },
    {
      id: 'citas',
      title: 'Buscar cita',
      icon: <Calendar className="w-6 h-6" />,
      avatarId: 'miriam'
    }
  ];

  return (
    <div className="flex flex-col gap-4 w-full md:w-64 flex-shrink-0">
      <h3 className="font-bold text-white mb-2">¿En qué te puedo ayudar?</h3>
      {menuItems.map((item) => (
        <button
          key={item.id}
          onClick={() => onSelectFlow(item.id, item.avatarId)}
          className="flex items-center gap-3 p-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-cyan rounded-none transition-all text-left group"
        >
          <div className="text-cyan group-hover:text-white transition-colors">
            {item.icon}
          </div>
          <span className="text-sm font-medium text-slate-200">{item.title}</span>
        </button>
      ))}
    </div>
  );
};

export default AvatarInitialMenu;