import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Upload, FileCheck, Loader2 } from 'lucide-react';

const DocumentVerificationFlow = () => {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleVerify = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('verify-pdf-document', {
        body: { documentType: 'auto', fileName: file.name }
      });
      if (error) throw error;
      setResult(data);
    } catch (e) {
      console.error(e);
      alert("Error verificando documento.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-800 p-6 border border-slate-700 w-full mb-4 rounded-none">
       <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <FileCheck className="text-cyan" /> Verificación de Documentos
      </h3>
      <div className="flex flex-col sm:flex-row gap-4">
        <input 
          type="file" 
          accept=".pdf"
          onChange={(e) => setFile(e.target.files[0])}
          className="bg-slate-900 border border-slate-700 text-white p-2 flex-1 rounded-none file:mr-4 file:py-2 file:px-4 file:rounded-none file:border-0 file:text-sm file:font-semibold file:bg-cyan file:text-navy hover:file:bg-cyan-light cursor-pointer"
        />
        <button 
          onClick={handleVerify}
          disabled={loading || !file}
          className="bg-cyan text-navy px-6 py-3 font-bold hover:bg-cyan-light transition-colors disabled:opacity-50 rounded-none flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="animate-spin" /> : <Upload />} Verificar
        </button>
      </div>

      {result && (
        <div className={`mt-6 p-4 border rounded-none ${result.verified ? 'bg-green-500/10 border-green-500/50' : 'bg-red-500/10 border-red-500/50'}`}>
           <p className={`font-bold ${result.verified ? 'text-green-400' : 'text-red-400'}`}>
             {result.verified ? 'Verificación Exitosa' : 'Atención Requerida'}
           </p>
           <p className="text-slate-300 mt-2 text-sm">{result.feedback}</p>
        </div>
      )}
    </div>
  );
};

export default DocumentVerificationFlow;