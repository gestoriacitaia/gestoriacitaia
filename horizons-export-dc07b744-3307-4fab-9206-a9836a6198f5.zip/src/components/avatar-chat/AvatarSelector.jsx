import React from 'react';
import { motion } from 'framer-motion';
import { Check, User, FileText, Search } from 'lucide-react';

const AvatarSelector = ({ selectedAvatar, onSelect }) => {
  const avatars = [
    {
      id: 'mohamad',
      name: 'Mohamad',
      role: 'Consulta General',
      description: 'Especialista en orientación inicial y dudas básicas de extranjería.',
      image: 'https://img.freepik.com/foto-gratis/hombre-joven-barbudo-gafas-camisa-cuadros_273609-12297.jpg',
      icon: <User className="w-5 h-5" />,
      color: 'bg-blue-500'
    },
    {
      id: 'khalid',
      name: 'Khalid',
      role: 'Trámites y Formularios',
      description: 'Experto en rellenar formularios EX y revisar documentación.',
      image: 'https://img.freepik.com/foto-gratis/retrato-hombre-sonriente-chateando-telefono_23-2148747872.jpg',
      icon: <FileText className="w-5 h-5" />,
      color: 'bg-green-500'
    },
    {
      id: 'miriam',
      name: 'Miriam',
      role: 'Buscar Cita',
      description: 'Asistente dedicada a la búsqueda y alertas de citas previas.',
      image: 'https://img.freepik.com/foto-gratis/retrato-hermosa-mujer-joven-pie-pared-gris_231208-10760.jpg',
      icon: <Search className="w-5 h-5" />,
      color: 'bg-purple-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      {avatars.map((avatar) => (
        <motion.button
          key={avatar.id}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onSelect(avatar)}
          className={`relative p-4 rounded-xl border-2 transition-all flex flex-col items-center text-center gap-3 ${
            selectedAvatar?.id === avatar.id
              ? 'border-cyan bg-cyan/10 ring-2 ring-cyan/20'
              : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
          }`}
        >
          <div className="relative w-20 h-20 rounded-full overflow-hidden border-2 border-slate-600 shadow-lg mb-2">
            <img 
              src={avatar.image} 
              alt={avatar.name} 
              className="w-full h-full object-cover"
            />
            <div className={`absolute bottom-0 right-0 p-1 rounded-tl-lg ${avatar.color} text-white`}>
              {avatar.icon}
            </div>
          </div>
          
          <div>
            <h3 className={`font-bold text-lg ${selectedAvatar?.id === avatar.id ? 'text-cyan' : 'text-white'}`}>
              {avatar.name}
            </h3>
            <p className="text-sm font-medium text-slate-300 mb-1">{avatar.role}</p>
            <p className="text-xs text-slate-400 leading-relaxed max-w-[200px] mx-auto">
              {avatar.description}
            </p>
          </div>

          {selectedAvatar?.id === avatar.id && (
            <div className="absolute top-3 right-3 bg-cyan text-navy rounded-full p-1 shadow-sm">
              <Check className="w-4 h-4" />
            </div>
          )}
        </motion.button>
      ))}
    </div>
  );
};

export default AvatarSelector;