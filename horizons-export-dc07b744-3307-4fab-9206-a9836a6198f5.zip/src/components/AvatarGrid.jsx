import React, { useState } from 'react';
import { motion } from 'framer-motion';
import SimpleAvatarCard from './SimpleAvatarCard';
import { getAvatars } from '../services/immigrationService';

const AvatarGrid = ({ onAvatarClick }) => {
  const [avatars] = useState(getAvatars());

  return (
    <section className="w-full py-4 md:py-12 px-2 md:px-4 bg-navy">
      <div className="max-w-6xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-3 gap-2 md:gap-8 justify-items-center"
        >
          {avatars.map((avatar, index) => (
            <motion.div 
              key={avatar.id || index} 
              className="w-full min-w-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <SimpleAvatarCard
                name={avatar.name}
                image={avatar.image}
                specialty={avatar.specialty}
                imageStyle={avatar.imageStyle}
                onClick={() => onAvatarClick && onAvatarClick(avatar)}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default AvatarGrid;