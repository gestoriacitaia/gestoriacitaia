import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Gift, X } from 'lucide-react';

const ReferralRewardNotification = ({ isOpen, onClose, planName = "Plan Estándar" }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className="bg-navy-light border border-yellow-500/50 rounded-2xl shadow-2xl p-8 max-w-sm w-full text-center relative overflow-hidden"
        >
          {/* Confetti effect background simplified */}
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent pointer-events-none" />
          
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", delay: 0.2 }}
            className="w-20 h-20 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full mx-auto flex items-center justify-center mb-6 shadow-lg shadow-yellow-500/30"
          >
            <Gift className="w-10 h-10 text-white" />
          </motion.div>

          <h2 className="text-2xl font-bold text-white mb-2">¡Felicidades! 🎉</h2>
          <p className="text-gray-300 mb-6">
            Has alcanzado 3 referidos y ganado <span className="text-yellow-400 font-bold">1 mes gratis</span> de {planName}.
          </p>

          <button 
            onClick={onClose}
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-navy font-bold py-3 rounded-xl transition-all shadow-lg"
          >
            Aceptar Recompensa
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ReferralRewardNotification;