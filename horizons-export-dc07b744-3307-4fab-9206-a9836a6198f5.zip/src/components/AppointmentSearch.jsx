import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Loader2, Calendar, MapPin, Clock, Check } from 'lucide-react';
import { MOCK_LOCATIONS } from '../config/paymentPlans';
import WhatsAppNotification from './WhatsAppNotification';

const AppointmentSearch = ({ userData }) => {
  const [searchStatus, setSearchStatus] = useState('searching'); // searching, found, confirmed
  const [appointment, setAppointment] = useState(null);

  useEffect(() => {
    // Simulate searching process
    const timer = setTimeout(() => {
      // Generate random date within next 7 days
      const date = new Date();
      date.setDate(date.getDate() + Math.floor(Math.random() * 7) + 1);
      
      const foundAppointment = {
        date: date.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' }),
        time: `${Math.floor(Math.random() * (17 - 9) + 9)}:${Math.random() < 0.5 ? '00' : '30'}`,
        location: MOCK_LOCATIONS[Math.floor(Math.random() * MOCK_LOCATIONS.length)],
        serviceType: userData.serviceType || 'Trámite de Extranjería'
      };
      
      setAppointment(foundAppointment);
      setSearchStatus('found');
    }, 3000);

    return () => clearTimeout(timer);
  }, [userData]);

  const handleConfirm = () => {
    setSearchStatus('confirmed');
  };

  if (searchStatus === 'searching') {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="relative mb-6">
          <div className="absolute inset-0 bg-cyan/20 rounded-full animate-ping"></div>
          <div className="relative bg-navy-light p-4 rounded-full border border-cyan/30">
            <Loader2 className="w-12 h-12 text-cyan animate-spin" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Buscando citas disponibles...</h2>
        <p className="text-gray-400 max-w-md">
          Conectando con la sede electrónica. Por favor, espera unos segundos mientras escaneamos las oficinas disponibles.
        </p>
      </div>
    );
  }

  if (searchStatus === 'found' && appointment) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md mx-auto bg-navy-light border border-cyan/30 rounded-2xl overflow-hidden shadow-2xl shadow-cyan/10"
      >
        <div className="bg-gradient-to-r from-cyan/20 to-navy-light p-6 border-b border-cyan/20">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-cyan rounded-lg text-white">
              <Calendar className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-white">¡Cita Encontrada!</h2>
          </div>
          <p className="text-cyan-light font-medium">Hemos reservado temporalmente este hueco para ti.</p>
        </div>

        <div className="p-6 space-y-4">
          <div className="flex items-start gap-4">
            <div className="mt-1">
               <Clock className="w-5 h-5 text-gray-400" />
            </div>
            <div>
               <p className="text-sm text-gray-400">Fecha y Hora</p>
               <p className="text-lg font-semibold text-white capitalize">{appointment.date}</p>
               <p className="text-lg font-bold text-cyan">{appointment.time}</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="mt-1">
               <MapPin className="w-5 h-5 text-gray-400" />
            </div>
            <div>
               <p className="text-sm text-gray-400">Ubicación</p>
               <p className="text-white">{appointment.location}</p>
            </div>
          </div>

          <div className="pt-4">
            <button
              onClick={handleConfirm}
              className="w-full bg-cyan hover:bg-cyan-light text-navy-dark font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5" /> Confirmar Cita
            </button>
            <p className="text-center text-xs text-gray-500 mt-3">
              Al confirmar, te enviaremos los detalles por WhatsApp.
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  if (searchStatus === 'confirmed') {
    return (
      <WhatsAppNotification 
        appointment={appointment} 
        userData={userData} 
      />
    );
  }

  return null;
};

export default AppointmentSearch;