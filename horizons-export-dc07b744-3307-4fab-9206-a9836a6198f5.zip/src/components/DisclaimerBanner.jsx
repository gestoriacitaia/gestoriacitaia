import React from 'react';
import { AlertTriangle, Info } from 'lucide-react';

const DisclaimerBanner = () => {
  return (
    <div className="bg-amber-500/10 border-l-4 border-amber-500 p-4 rounded-r-lg my-6">
      <div className="flex items-start gap-3">
        <AlertTriangle className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1" />
        <div className="text-sm text-slate-300 space-y-2">
          <p className="font-medium text-amber-500">Aviso Importante</p>
          <p>
            GestoríaCitaIA ofrece orientación y soporte tecnológico, pero la responsabilidad final de los trámites y la asistencia a citas corresponde exclusivamente al usuario. 
          </p>
          <ul className="list-disc list-inside space-y-1 text-slate-400 pl-1">
            <li>Toda la información es orientativa y <strong>no sustituye asesoramiento legal profesional</strong>.</li>
            <li>NO garantizamos la aprobación de trámites ni la obtención de citas (depende de la disponibilidad oficial).</li>
            <li>NO automatizamos el envío de solicitudes a la administración pública sin supervisión.</li>
            <li>NO ofrecemos servicios ilegales, NO manipulamos sistemas informáticos gubernamentales y NO vendemos citas ni documentos falsos.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DisclaimerBanner;