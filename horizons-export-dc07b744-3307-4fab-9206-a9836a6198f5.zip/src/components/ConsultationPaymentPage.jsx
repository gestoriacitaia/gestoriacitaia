import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { loadStripe } from '@stripe/stripe-js';
import { Check, CreditCard, User, Mail, ShieldCheck, AlertCircle, Loader2 } from 'lucide-react';
import GestoriaHeader from './GestoriaHeader';
import Footer from './Footer';
import { useToast } from './ui/use-toast';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const ConsultationPaymentPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState('miriam');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    amount: 9.99
  });

  const avatars = [
    { id: 'miriam', name: 'Miriam', role: 'Immigration Expert', desc: 'Specialist in documentation and procedures.' },
    { id: 'mohammad', name: 'Mohammad', role: 'Appointment Finder', desc: 'Expert in securing Cita Previa slots.' },
    { id: 'khalid', name: 'Khalid', role: 'Legal Advisor', desc: 'Knowledgeable in residency laws and appeals.' }
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('create-stripe-checkout', {
        body: {
          avatarId: selectedAvatar,
          amount: formData.amount,
          customerEmail: formData.email,
          customerName: formData.name,
          origin: window.location.origin
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      if (data?.sessionId) {
        const stripe = await stripePromise;
        const result = await stripe.redirectToCheckout({
          sessionId: data.sessionId,
        });

        if (result.error) {
          throw new Error(result.error.message);
        }
      }
    } catch (err) {
      console.error('Payment Error:', err);
      toast({
        title: "Payment Initialization Failed",
        description: err.message || "Could not connect to payment provider.",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col font-sans">
      <GestoriaHeader />
      
      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-2 text-center text-white">Book Your AI Consultation</h1>
          <p className="text-center text-slate-400 mb-12">Select your specialist and secure your session instantly.</p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            
            {/* Left Column: Avatar Selection */}
            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <span className="bg-cyan/10 text-cyan px-2 py-1 rounded text-sm">Step 1</span> Select Specialist
              </h3>
              <div className="space-y-4">
                {avatars.map(avatar => (
                  <div 
                    key={avatar.id}
                    onClick={() => setSelectedAvatar(avatar.id)}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex items-center gap-4 ${
                      selectedAvatar === avatar.id 
                      ? 'border-cyan bg-cyan/5 shadow-lg shadow-cyan/10' 
                      : 'border-slate-800 bg-slate-900 hover:border-slate-600'
                    }`}
                  >
                    <div className="w-16 h-16 rounded-full bg-slate-800 overflow-hidden flex-shrink-0">
                      <img 
                        src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${avatar.id}`} 
                        alt={avatar.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <h4 className="font-bold text-lg">{avatar.name}</h4>
                        {selectedAvatar === avatar.id && <Check className="w-5 h-5 text-cyan" />}
                      </div>
                      <p className="text-cyan text-sm mb-1">{avatar.role}</p>
                      <p className="text-slate-400 text-xs">{avatar.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Column: Payment Form */}
            <div>
              <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <span className="bg-cyan/10 text-cyan px-2 py-1 rounded text-sm">Step 2</span> Your Details
              </h3>
              
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <input
                        type="text"
                        required
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-cyan focus:ring-1 focus:ring-cyan transition-colors"
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <input
                        type="email"
                        required
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-10 pr-4 py-3 text-white focus:outline-none focus:border-cyan focus:ring-1 focus:ring-cyan transition-colors"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-800">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-slate-300">Total Amount</span>
                      <span className="text-2xl font-bold text-white">{formData.amount}€</span>
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-cyan hover:bg-cyan/90 text-navy font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02] disabled:opacity-70 disabled:cursor-not-allowed"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <CreditCard className="w-5 h-5" />
                          Pay Securely with Stripe
                        </>
                      )}
                    </button>
                    
                    <div className="flex justify-center items-center gap-2 mt-4 text-xs text-slate-500">
                      <ShieldCheck className="w-3 h-3" />
                      Secure SSL Payment encrypted by Stripe
                    </div>
                  </div>
                </form>
              </div>
            </div>

          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ConsultationPaymentPage;