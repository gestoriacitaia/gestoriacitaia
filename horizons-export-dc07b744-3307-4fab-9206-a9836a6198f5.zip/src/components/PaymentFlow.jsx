import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Check, Loader2, CreditCard, AlertCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePayment } from '@/contexts/PaymentContext';
import { useConsultation } from '@/contexts/ConsultationContext';
import { CONSULTATION_PLANS, createConsultationCheckout } from '@/services/stripeService';
import { useToast } from './ui/use-toast';
import { paymentDebugService } from '@/services/paymentDebugService';

const PaymentFlow = ({ onPaymentSuccess }) => {
  const { language } = useLanguage();
  const { isProcessing, setIsProcessing } = usePayment();
  const { selectedAvatar } = useConsultation(); 
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [customerData, setCustomerData] = useState({
    name: '',
    email: '',
    phone: '',
  });

  // Automatically bypass if avatar is free - Double safety check
  useEffect(() => {
    if (selectedAvatar?.isFree) {
        console.log("Bypassing payment for free avatar:", selectedAvatar.id);
        onPaymentSuccess({ 
            planId: 'free', 
            customerData: { email: 'guest@free.tier' } 
        });
    }
  }, [selectedAvatar, onPaymentSuccess]);

  const handlePlanSelect = (planId) => {
    setSelectedPlan(planId);
  };

  const handleInputChange = (field, value) => {
    setCustomerData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateForm = () => {
    if (!customerData.name.trim()) {
      toast({
        variant: 'destructive',
        title: language === 'es' ? 'Nombre requerido' : 'الاسم مطلوب',
        description: language === 'es' ? 'Por favor, ingresa tu nombre.' : 'الرجاء إدخال اسمك.',
      });
      return false;
    }

    if (!customerData.email.trim() || !customerData.email.includes('@')) {
      toast({
        variant: 'destructive',
        title: language === 'es' ? 'Email requerido' : 'البريد الإلكتروني مطلوب',
        description: language === 'es' ? 'Por favor, ingresa un email válido.' : 'الرجاء إدخال بريد إلكتروني صحيح.',
      });
      return false;
    }

    if (!selectedPlan) {
      toast({
        variant: 'destructive',
        title: language === 'es' ? 'Plan requerido' : 'الخطة مطلوبة',
        description: language === 'es' ? 'Por favor, selecciona un plan.' : 'الرجاء اختيار خطة.',
      });
      return false;
    }

    return true;
  };

  const handlePayment = async () => {
    if (!validateForm()) return;

    setIsProcessing(true);
    paymentDebugService.logStep('PaymentFlow', 'Starting Payment', { plan: selectedPlan });

    try {
      // 1. Create Checkout Session
      const session = await createConsultationCheckout(selectedPlan, customerData);

      // 2. Redirect
      if (session && session.url) {
        paymentDebugService.logStep('PaymentFlow', 'Redirecting', session.url);
        
        toast({
            title: language === 'es' ? 'Redirigiendo...' : 'جاري التوجيه...',
            description: language === 'es' ? 'Conectando con Stripe.' : 'جاري الاتصال بـ Stripe.',
        });

        setTimeout(() => {
             window.location.href = session.url;
        }, 1000);

      } else {
        throw new Error('Invalid session URL');
      }

    } catch (error) {
      paymentDebugService.logError('PaymentFlow:Error', error);
      toast({
        variant: 'destructive',
        title: language === 'es' ? 'Error de pago' : 'خطأ في الدفع',
        description: language === 'es' 
          ? 'No se pudo procesar la solicitud. Inténtalo de nuevo.' 
          : 'فشلت معالجة الطلب. حاول مرة أخرى.',
      });
      setIsProcessing(false);
    }
  };

  if (selectedAvatar?.isFree) {
      return (
          <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="w-10 h-10 text-cyan animate-spin mb-4" />
              <p className="text-gray-400">Loading free session...</p>
          </div>
      );
  }

  // Convert object to array for mapping
  const plans = Object.values(CONSULTATION_PLANS);

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-12">
      
      {/* Header */}
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
          {language === 'es' ? 'Elige tu Plan' : 'اختر خطتك'}
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          {language === 'es' 
            ? 'Para consultar con nuestros expertos premium, selecciona un plan.'
            : 'للتشاور مع خبرائنا المتميزين، اختر خطة.'
          }
        </p>
      </div>

      {/* Pricing Plans */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        {plans.map((plan, index) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            onClick={() => handlePlanSelect(plan.id)}
            className={`relative bg-navy-light border-2 rounded-2xl p-6 cursor-pointer transition-all hover:scale-105 ${
              selectedPlan === plan.id
                ? 'border-cyan shadow-lg shadow-cyan/20'
                : 'border-navy-lighter hover:border-cyan/50'
            } ${plan.id === 'pro' ? 'md:scale-105 bg-gradient-to-b from-navy-light to-navy' : ''}`}
          >
            {plan.id === 'pro' && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-cyan text-white text-xs font-bold px-3 py-1 rounded-full">
                {language === 'es' ? 'Recomendado' : 'موصى به'}
              </div>
            )}

            {selectedPlan === plan.id && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-4 right-4 bg-cyan rounded-full p-1"
              >
                <Check className="w-5 h-5 text-white" />
              </motion.div>
            )}

            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-white mb-2">
                {plan.name[language]}
              </h3>
              <div className="flex items-baseline justify-center gap-1">
                <span className="text-4xl font-bold text-cyan">€{plan.price}</span>
              </div>
              <p className="text-gray-400 text-sm mt-2">
                {language === 'es' ? 'Pago único' : 'دفع لمرة واحدة'}
              </p>
            </div>

            <ul className="space-y-3">
              {plan.features[language].map((feature, i) => (
                <li key={i} className="flex items-start gap-2 text-gray-300 text-sm">
                  <Check className="w-5 h-5 text-cyan flex-shrink-0 mt-0.5" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        ))}
      </div>

      {/* Customer Information Form */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-navy-light border border-navy-lighter rounded-2xl p-8 max-w-2xl mx-auto"
      >
        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
          <CreditCard className="w-6 h-6 text-cyan" />
          {language === 'es' ? 'Información de Contacto' : 'معلومات الاتصال'}
        </h3>

        <div className="space-y-4">
          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              {language === 'es' ? 'Nombre completo' : 'الاسم الكامل'}
            </label>
            <input
              type="text"
              value={customerData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder={language === 'es' ? 'Tu nombre' : 'اسمك'}
              disabled={isProcessing}
              className="w-full bg-navy border border-navy-lighter rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan disabled:opacity-50"
            />
          </div>

          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              {language === 'es' ? 'Email' : 'البريد الإلكتروني'}
            </label>
            <input
              type="email"
              value={customerData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder={language === 'es' ? 'tu@email.com' : 'your@email.com'}
              disabled={isProcessing}
              className="w-full bg-navy border border-navy-lighter rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan disabled:opacity-50"
            />
          </div>

          <div>
            <label className="block text-gray-300 text-sm font-medium mb-2">
              {language === 'es' ? 'Teléfono (opcional)' : 'الهاتف (اختياري)'}
            </label>
            <input
              type="tel"
              value={customerData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder={language === 'es' ? '+34 600 000 000' : '+34 600 000 000'}
              disabled={isProcessing}
              className="w-full bg-navy border border-navy-lighter rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan disabled:opacity-50"
            />
          </div>

          <button
            onClick={handlePayment}
            disabled={isProcessing || !selectedPlan}
            className="w-full bg-gradient-to-r from-cyan to-cyan-dark hover:from-cyan-light hover:to-cyan text-white font-bold py-4 rounded-lg transition-all shadow-lg shadow-cyan/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transform hover:-translate-y-0.5 active:translate-y-0"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                {language === 'es' ? 'Procesando...' : 'جاري المعالجة...'}
              </>
            ) : (
              <>
                {language === 'es' ? 'Proceder al Pago' : 'متابعة إلى الدفع'}
                {selectedPlan && ` - €${CONSULTATION_PLANS[selectedPlan].price}`}
              </>
            )}
          </button>

          <p className="text-gray-400 text-xs text-center">
            {language === 'es' 
              ? '🔒 Pago seguro procesado por Stripe. Tus datos están protegidos.' 
              : '🔒 دفع آمن معالج بواسطة Stripe. بياناتك محمية.'
            }
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default PaymentFlow;