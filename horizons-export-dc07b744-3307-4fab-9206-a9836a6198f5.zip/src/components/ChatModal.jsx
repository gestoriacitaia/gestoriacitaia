import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Mic, FileUp, Play } from 'lucide-react';
import { Button } from './ui/button';
import { useToast } from './ui/use-toast';
import { useLanguage } from '../contexts/LanguageContext';

const ChatModal = ({ isOpen, onClose, specialistName }) => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const { toast } = useToast();
  const { language } = useLanguage();

  const translations = {
    es: {
      title: `Chat con ${specialistName}`,
      placeholder: 'Escribe tu mensaje...',
      videoPlaceholder: 'Video del asistente IA',
      voiceFeature: 'Función de voz disponible próximamente',
      uploadFeature: 'Función de carga de documentos disponible próximamente',
    },
    ar: {
      title: `Tihwari ma ${specialistName}`,
      placeholder: 'Kteb tamazirt-nnek...',
      videoPlaceholder: 'Fidyu n AI',
      voiceFeature: 'Tazzart n tsawt taqrib ad tili',
      uploadFeature: 'Tazzart n usali n isefra taqrib ad tili',
    }
  };

  const t = translations[language];

  const handleSend = () => {
    if (!message.trim()) return;

    setMessages([...messages, { type: 'user', text: message }]);
    setMessage('');

    // Simulate AI response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        type: 'ai',
        text: language === 'es'
          ? '¡Gracias por tu mensaje! Esta es una demostración. La funcionalidad completa estará disponible pronto.'
          : 'Tanmmirt f tmazirt-nnek! Wagi d umdayal. Tazzart tamaynut ad tili taqrib.'
      }]);
    }, 1000);
  };

  const handleVoice = () => {
    toast({
      title: "🎤 " + (language === 'es' ? 'Próximamente' : 'Taqrib'),
      description: t.voiceFeature,
      duration: 3000,
    });
  };

  const handleUpload = () => {
    toast({
      title: "📄 " + (language === 'es' ? 'Próximamente' : 'Taqrib'),
      description: t.uploadFeature,
      duration: 3000,
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', duration: 0.5 }}
            className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-4xl md:h-[600px] bg-white rounded-2xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 flex items-center justify-between">
              <h2 className="text-white text-xl font-bold">{t.title}</h2>
              <Button
                onClick={onClose}
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="flex-1 flex overflow-hidden">
              {/* Video Section */}
              <div className="w-full md:w-1/3 bg-gray-900 flex items-center justify-center p-4">
                <div className="relative w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
                  <Play className="w-16 h-16 text-gray-600" />
                  <p className="absolute bottom-4 text-gray-400 text-sm">{t.videoPlaceholder}</p>
                </div>
              </div>

              {/* Chat Section */}
              <div className="flex-1 flex flex-col">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-gray-400">
                      <p>{language === 'es' ? 'Inicia la conversación' : 'Bdda tihwari'}</p>
                    </div>
                  ) : (
                    messages.map((msg, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[80%] p-3 rounded-lg ${
                            msg.type === 'user'
                              ? 'bg-blue-600 text-white'
                              : 'bg-gray-200 text-gray-900'
                          }`}
                        >
                          {msg.text}
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>

                {/* Input Area */}
                <div className="p-4 border-t border-gray-200">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                      placeholder={t.placeholder}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900 placeholder:text-gray-400"
                    />
                    <Button
                      onClick={handleVoice}
                      variant="outline"
                      size="icon"
                      className="border-gray-300 hover:bg-gray-100"
                    >
                      <Mic className="w-5 h-5 text-gray-600" />
                    </Button>
                    <Button
                      onClick={handleUpload}
                      variant="outline"
                      size="icon"
                      className="border-gray-300 hover:bg-gray-100"
                    >
                      <FileUp className="w-5 h-5 text-gray-600" />
                    </Button>
                    <Button
                      onClick={handleSend}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <Send className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default ChatModal;