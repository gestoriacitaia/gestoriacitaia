import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';

const LanguageSelector = () => {
  const { language, switchLanguage } = useLanguage();

  return (
    <div className="w-full flex justify-center items-center gap-4 py-4 px-4 bg-[#1a2a4a]">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => switchLanguage('es')}
        className={`px-6 py-2 rounded-full font-bold text-sm md:text-base shadow-lg transition-colors duration-300 ${
          language === 'es'
            ? 'bg-blue-600 text-white ring-2 ring-white/20'
            : 'bg-blue-900/50 text-blue-200 hover:bg-blue-800'
        }`}
      >
        Castellano
      </motion.button>
      
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => switchLanguage('ar')}
        className={`px-6 py-2 rounded-full font-bold text-sm md:text-base shadow-lg transition-colors duration-300 ${
          language === 'ar'
            ? 'bg-orange-600 text-white ring-2 ring-white/20'
            : 'bg-orange-900/50 text-orange-200 hover:bg-orange-800'
        }`}
      >
        Darija
      </motion.button>
    </div>
  );
};

export default LanguageSelector;