import React, { useEffect, useRef, useState } from 'react';
import { didVideoService } from '@/services/DIDVideoService';
import { Mic, Video, VideoOff, Volume2, VolumeX, PhoneOff, Loader2, MessageSquare, Download } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

const RealTimeConsultationSession = ({ avatarId = 'miriam', onEndSession, isSpeaking }) => {
  const videoRef = useRef(null);
  const [status, setStatus] = useState('initializing'); // initializing, ready, error
  const [isMuted, setIsMuted] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const initSession = async () => {
      try {
        setStatus('initializing');
        await didVideoService.createSession(videoRef.current, avatarId);
        setStatus('ready');
      } catch (error) {
        console.error("Session Init Error:", error);
        setStatus('error');
      }
    };

    if (videoRef.current) {
      initSession();
    }

    return () => {
      // Cleanup is handled by manager or parent usually, but we ensure disconnect here too
    };
  }, [avatarId]);

  const handleUnimplemented = () => {
    toast({
      title: "Próximamente",
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
      duration: 3000,
    });
  };

  const buttonBaseClass = "px-6 py-4 sm:px-8 sm:py-4 text-base sm:text-lg rounded-none font-bold text-white flex items-center justify-center gap-3 transition-all duration-200 hover:scale-105 hover:shadow-xl shadow-lg w-full sm:w-auto min-w-[160px]";

  return (
    <div className="relative w-full h-full bg-slate-900 rounded-none overflow-hidden shadow-2xl border border-slate-800">
      
      {/* Video Display */}
      <video 
        ref={videoRef}
        autoPlay 
        playsInline 
        muted={isMuted}
        className={`w-full h-full object-cover transition-opacity duration-700 ${status === 'ready' ? 'opacity-100' : 'opacity-0'}`}
      />

      {/* Loading Overlay */}
      {status === 'initializing' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 z-10">
          <Loader2 className="w-12 h-12 text-green-500 animate-spin mb-4" />
          <p className="text-green-400 font-mono text-base tracking-widest uppercase">Connecting Neural Interface...</p>
        </div>
      )}

      {/* Error Overlay */}
      {status === 'error' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 z-10">
          <VideoOff className="w-12 h-12 text-red-500 mb-4" />
          <p className="text-red-400 font-mono text-base">Connection Failed</p>
        </div>
      )}

      {/* Controls Overlay */}
      <div className="absolute bottom-6 left-0 w-full px-4 flex flex-wrap items-center justify-center gap-4 sm:gap-6 z-20">
        
        <button 
          onClick={() => setIsMuted(!isMuted)}
          className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
        >
          {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
          {isMuted ? 'Unmute' : 'Mute'}
        </button>

        <button 
          onClick={handleUnimplemented}
          className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
        >
          <MessageSquare className="w-6 h-6" />
          Chat
        </button>

        <button 
          onClick={handleUnimplemented}
          className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
        >
          <Download className="w-6 h-6" />
          PDF
        </button>

        <button 
          onClick={onEndSession}
          className={`${buttonBaseClass} bg-red-600 hover:bg-red-700`}
        >
          <PhoneOff className="w-6 h-6" />
          End
        </button>
      </div>

      {/* Speaking Indicator */}
      {isSpeaking && (
        <div className="absolute top-6 right-6 z-20">
           <span className="flex h-3 w-3 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-none bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-none h-3 w-3 bg-green-500"></span>
          </span>
        </div>
      )}

    </div>
  );
};

export default RealTimeConsultationSession;