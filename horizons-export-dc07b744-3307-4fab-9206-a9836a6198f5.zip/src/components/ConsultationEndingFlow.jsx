import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Loader2, CheckCircle } from 'lucide-react';
import DocumentDownloadPanel from './DocumentDownloadPanel';
import { useConsultationDocuments } from '@/hooks/useConsultationDocuments';

const ConsultationEndingFlow = ({ 
  citaId, 
  clienteId, 
  avatarId, 
  conversationHistory, 
  onClose,
  isActive 
}) => {
  const { 
    isGenerating, 
    generatedDocs, 
    generateDocuments, 
    downloadAllDocuments 
  } = useConsultationDocuments();

  useEffect(() => {
    if (isActive && !generatedDocs && !isGenerating) {
      generateDocuments({
        citaId,
        clienteId,
        avatarId,
        conversationHistory,
        paymentData: { amount: 9.99, id: 'stripe_mock' }
      });
    }
  }, [isActive]);

  if (!isActive) return null;

  return (
    <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl"
      >
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-white mb-2">Resumen de la Sesión</h2>
          <p className="text-slate-400">Gracias por confiar en Gestoria Cita IA.</p>
        </div>

        {isGenerating ? (
          <div className="flex flex-col items-center justify-center py-8">
            <Loader2 className="w-12 h-12 text-cyan animate-spin mb-4" />
            <p className="text-cyan font-mono animate-pulse">GENERANDO DOCUMENTOS...</p>
            <p className="text-xs text-slate-500 mt-2">Creando resumen y recomendaciones...</p>
          </div>
        ) : generatedDocs ? (
          <div>
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mb-6 flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-500" />
              <div className="text-left">
                <p className="text-sm font-bold text-green-500">Documentos Listos</p>
                <p className="text-xs text-slate-400">Se han guardado en tu perfil.</p>
              </div>
            </div>

            <DocumentDownloadPanel 
              documents={generatedDocs} 
              onDownloadAll={downloadAllDocuments} 
            />

            <button 
              onClick={onClose}
              className="mt-6 text-slate-400 hover:text-white text-sm w-full py-2"
            >
              Cerrar y Volver al Inicio
            </button>
          </div>
        ) : (
          <div className="text-center text-red-400">
            <p>Hubo un error al generar los documentos.</p>
            <button onClick={onClose} className="mt-4 text-white underline">Cerrar</button>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default ConsultationEndingFlow;