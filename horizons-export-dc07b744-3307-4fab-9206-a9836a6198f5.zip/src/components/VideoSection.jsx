import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Zap } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const VideoSection = () => {
  const { t } = useLanguage();
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <section className="w-full py-12 px-4 bg-navy-light/30 border-y border-navy-light">
      <div className="max-w-6xl mx-auto flex flex-col gap-8">
        
        {/* Title */}
        <h2 className="text-2xl md:text-3xl font-bold text-white text-center flex items-center justify-center gap-3">
          <Zap className="w-6 h-6 text-purple" />
          {t.videoTitle}
        </h2>

        {/* Video Player Container */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="relative w-full aspect-video max-w-5xl mx-auto bg-black rounded-2xl overflow-hidden border border-navy-lighter shadow-2xl shadow-cyan/5"
        >
          <img 
            src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=1200"
            alt="Video Preview"
            className={`w-full h-full object-cover transition-opacity duration-300 ${isPlaying ? 'opacity-20' : 'opacity-60'}`}
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-navy/90 via-transparent to-transparent" />

          {!isPlaying && (
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsPlaying(true)}
                className="w-20 h-20 bg-cyan/90 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(6,182,212,0.4)] backdrop-blur-sm group hover:bg-cyan"
              >
                <Play className="w-8 h-8 text-white ml-1 fill-white" />
              </motion.button>
            </div>
          )}

          {isPlaying && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex flex-col items-center gap-4">
                 <div className="w-12 h-12 border-4 border-cyan border-t-transparent rounded-full animate-spin"></div>
                 <div className="text-cyan font-bold text-lg animate-pulse">Conectando IA...</div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
};

export default VideoSection;