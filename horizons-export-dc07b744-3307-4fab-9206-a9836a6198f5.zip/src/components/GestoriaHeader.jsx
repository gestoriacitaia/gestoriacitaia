import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';
import { Menu, X, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const GestoriaHeader = () => {
  const { language, switchLanguage } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleNavClick = (path) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <header className="w-full bg-navy border-b border-navy-light sticky top-0 z-50 shadow-lg">
      <div className="max-w-[1800px] mx-auto px-4 h-20 flex items-center justify-between">
        
        {/* Branding */}
        <div 
          className="flex items-center gap-2 cursor-pointer flex-shrink-0 mr-8" 
          onClick={() => navigate('/')}
        >
          <div className="w-10 h-10 bg-cyan flex items-center justify-center font-bold text-navy shadow-lg shadow-cyan/20 rounded-none">
            IA
          </div>
          <span className="text-xl font-bold text-white tracking-tight hidden lg:block">
            gestoria<span className="text-cyan">cita</span>ia
          </span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden xl:flex items-center gap-6 flex-1 justify-end mr-6">
          <button
            onClick={() => handleNavClick('/')}
            className="px-4 py-2 text-[16px] font-bold text-gray-300 hover:text-white transition-colors"
          >
            {language === 'es' ? 'Inicio' : 'البداية'}
          </button>
          
          <button
            onClick={() => handleNavClick('/buscar-cita-checkout')}
            className="w-[250px] py-3 text-[16px] font-bold text-white bg-green-500 hover:bg-green-600 transition-all rounded-lg shadow-lg flex items-center justify-center whitespace-nowrap transform hover:-translate-y-0.5"
          >
            {language === 'es' ? 'Citas' : 'مواعيد'}
          </button>
        </nav>

        {/* Desktop Actions */}
        <div className="hidden xl:flex items-center gap-4">
          {/* Language Selector */}
          <div className="flex items-center bg-navy-light p-1 border border-navy-lighter rounded-none">
            <button
              onClick={() => switchLanguage('es')}
              className={`px-3 py-1 text-xs font-bold transition-all rounded-none ${
                language === 'es' ? 'bg-cyan text-navy' : 'text-gray-400 hover:text-white'
              }`}
            >
              ES
            </button>
            <button
              onClick={() => switchLanguage('ar')}
              className={`px-3 py-1 text-xs font-bold transition-all rounded-none ${
                language === 'ar' ? 'bg-cyan text-navy' : 'text-gray-400 hover:text-white'
              }`}
            >
              AR
            </button>
          </div>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="xl:hidden p-2 text-white hover:text-cyan transition-colors"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 xl:hidden bg-navy flex flex-col pt-20"
          >
            <button 
              className="absolute top-6 right-6 p-2 text-white"
              onClick={() => setIsMenuOpen(false)}
            >
              <X className="w-8 h-8" />
            </button>

            <div className="flex flex-col p-6 gap-4">
              <button
                onClick={() => handleNavClick('/')}
                className="w-full p-4 text-left text-lg font-bold text-white border-b border-navy-light hover:bg-navy-light flex items-center gap-4 rounded-none"
              >
                {language === 'es' ? 'Inicio' : 'البداية'}
              </button>
              
              <button
                onClick={() => handleNavClick('/buscar-cita-checkout')}
                className="w-full p-4 text-center text-lg font-bold text-white bg-green-500 hover:bg-green-600 transition-all rounded-lg shadow-lg transform hover:-translate-y-0.5"
              >
                {language === 'es' ? 'Citas' : 'مواعيد'}
              </button>
              
              <div className="mt-8 flex items-center justify-between bg-navy-light p-4 border border-navy-lighter rounded-none">
                <span className="text-gray-400 text-sm font-bold flex items-center gap-2">
                  <Globe className="w-4 h-4 text-cyan" /> {language === 'es' ? 'Idioma' : 'اللغة'}
                </span>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => switchLanguage('es')}
                    className={`px-6 py-2 font-bold rounded-none ${language === 'es' ? 'bg-cyan text-navy' : 'text-gray-400'}`}
                  >
                    ES
                  </button>
                  <button 
                    onClick={() => switchLanguage('ar')}
                    className={`px-6 py-2 font-bold rounded-none ${language === 'ar' ? 'bg-cyan text-navy' : 'text-gray-400'}`}
                  >
                    AR
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default GestoriaHeader;