import React from 'react';
import { motion } from 'framer-motion';
import PricingCard from './PricingCard';
import { useLanguage } from '../contexts/LanguageContext';

const PricingSection = () => {
  const { language } = useLanguage();

  const translations = {
    es: {
      title: 'Planes y Precios',
      subtitle: 'Elige el plan que mejor se adapte a tus necesidades',
      plans: [
        {
          planName: 'Plan Básico',
          price: '9.99',
          features: [
            '15 min Consulta',
            'Dudas Extranjería',
            'Chat IA',
            'Soporte en Castellano y Darija',
          ],
          isMonthly: false
        },
        {
          planName: 'Plan Estándar',
          price: '14.99',
          features: [
            'Todo lo del Plan Básico',
            'Verificación Docs',
            'Revisión NIE/Pasaporte',
            '3 Consultas/mes',
          ],
          isMonthly: false
        },
        {
          planName: 'Plan Búsqueda de Citas',
          price: '12.99',
          features: [
            'Buscar citas',
            'Mandar WhatsApp al cliente',
            'Acompañamiento del proceso',
            'Videollamada en vivo paso a paso'
          ],
          isMonthly: false
        },
        {
          planName: 'Plan Pro',
          price: '27.99',
          features: [
            'Todo lo del Plan Estándar',
            'Cita Extranjería',
            'Gestión Completa',
            'Soporte Prioritario',
            'Abonne cada mes'
          ],
          isMonthly: true
        },
      ],
    },
    ar: {
      title: 'Isuman d Isuman',
      subtitle: 'Ffer asirem i yesɛan ufaris s isebdaden-nnek',
      plans: [
        {
          planName: 'الخطة الأساسية',
          price: '9.99',
          features: [
            'استشارة 15 دقيقة',
            'أسئلة الهجرة',
            'دردشة الذكاء الاصطناعي',
            'دعم بالإسبانية والدارجة',
          ],
          isMonthly: false
        },
        {
          planName: 'الخطة القياسية',
          price: '14.99',
          features: [
            'كل ما في الخطة الأساسية',
            'التحقق من الوثائق',
            'مراجعة NIE / جواز السفر',
            '3 استشارات / شهر',
          ],
          isMonthly: false
        },
        {
          planName: 'خطة بحث المواعيد',
          price: '12.99',
          features: [
            'بحث المواعيد',
            'إرسال واتساب للعميل',
            'مرافقة العملية',
            'مكالمة فيديو مباشرة خطوة بخطوة'
          ],
          isMonthly: false
        },
        {
          planName: 'خطة المحترفين',
          price: '27.99',
          features: [
            'كل ما في الخطة القياسية',
            'موعد الهجرة',
            'إدارة كاملة',
            'دعم ذو أولوية',
            'اشتراك شهري'
          ],
          isMonthly: true
        },
      ],
    },
  };

  const t = translations[language] || translations.es;

  return (
    <section id="pricing" className="py-20 bg-gradient-to-b from-white to-blue-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            {t.title}
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {t.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {t.plans.map((plan, index) => (
            <PricingCard
              key={index}
              planName={plan.planName}
              price={plan.price}
              features={plan.features}
              highlighted={index === 3}
              recommended={index === 3}
              isMonthly={plan.isMonthly}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;