import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../contexts/LanguageContext';

const CompanyMessage = () => {
  const { t, language } = useLanguage();

  return (
    <section className="w-full py-16 md:py-24 bg-sky-bg relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto relative"
        >
          {/* Decorative Borders */}
          <div className="absolute -top-6 -left-6 w-24 h-24 border-t-4 border-l-4 border-sky-300 rounded-tl-[40px] opacity-50" />
          <div className="absolute -bottom-6 -right-6 w-24 h-24 border-b-4 border-r-4 border-sky-300 rounded-br-[40px] opacity-50" />
          
          <div className="bg-white border border-sky-100 p-8 md:p-12 rounded-[32px] shadow-xl relative z-10 text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-sky-500 mb-6 uppercase tracking-wider">
              {t.companyMessageTitle}
            </h2>
            <p 
              className="text-lg md:text-2xl text-navy font-medium leading-relaxed"
              dir={language === 'ar' ? 'rtl' : 'ltr'}
            >
              {t.companyMessageBody}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CompanyMessage;