import React from 'react';
import { motion } from 'framer-motion';
import { Check, Star, Shield, Zap } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const SubscriptionPlansDisplay = ({ onSelectPlan }) => {
  const { language } = useLanguage();

  const plans = [
    {
      id: 'basic',
      name: language === 'es' ? 'Plan Básico' : 'الخطة الأساسية',
      price: '9.99',
      features: language === 'es' 
        ? ['Consulta IA 15 min', 'Respuesta con videollamada en tiempo real']
        : ['استشارة الذكاء الاصطناعي 15 دقيقة', 'رد عبر مكالمة فيديو في الوقت الفعلي'],
      icon: Shield,
      color: 'from-blue-400 to-blue-600',
      popular: false,
      isMonthly: false
    },
    {
      id: 'standard',
      name: language === 'es' ? 'Plan Estándar' : 'الخطة القياسية',
      price: '14.99',
      features: language === 'es'
        ? [
            'Consulta IA',
            'Videollamada 5 veces al mes',
            'Verificación de documentos PDF',
            'Prioridad en respuesta',
            'Historial de chats guardado'
          ]
        : [
            'استشارة الذكاء الاصطناعي',
            'مكالمة فيديو 5 مرات في الشهر',
            'التحقق من وثائق PDF',
            'الأولوية في الرد',
            'سجل الدردشة المحفوظ'
          ],
      icon: Star,
      color: 'from-cyan to-cyan-dark',
      popular: true,
      isMonthly: false
    },
    {
      id: 'appointments',
      name: language === 'es' ? 'Plan Búsqueda de Citas' : 'خطة بحث المواعيد',
      price: '12.99',
      features: language === 'es'
        ? [
            'Buscar citas',
            'Mandar WhatsApp al cliente',
            'Acompañamiento del proceso',
            'Videollamada en vivo paso a paso'
          ]
        : [
            'بحث المواعيد',
            'إرسال واتساب للعميل',
            'مرافقة العملية',
            'مكالمة فيديو مباشرة خطوة بخطوة'
          ],
      icon: Zap,
      color: 'from-purple-500 to-indigo-600',
      popular: false,
      isMonthly: false
    },
    {
      id: 'pro',
      name: language === 'es' ? 'Plan Pro' : 'خطة المحترفين',
      price: '27.99',
      features: language === 'es'
        ? [
            'Todo ilimitado en el sitio web',
            'Abonne cada mes',
            'Todo incluido'
          ]
        : [
            'كل شيء غير محدود على الموقع',
            'اشتراك شهري',
            'شامل كلياً'
          ],
      icon: Zap,
      color: 'from-emerald-500 to-teal-600',
      popular: false,
      isMonthly: true
    }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan, index) => {
          const Icon = plan.icon;
          return (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative bg-navy-light/50 backdrop-blur-sm rounded-2xl border ${
                plan.popular ? 'border-cyan shadow-lg shadow-cyan/20' : 'border-navy-lighter'
              } p-6 flex flex-col hover:transform hover:-translate-y-2 transition-all duration-300`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-cyan text-white text-xs font-bold px-4 py-1 rounded-full shadow-lg whitespace-nowrap">
                  {language === 'es' ? 'Más Popular' : 'الأكثر شعبية'}
                </div>
              )}

              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4 text-white shadow-lg`}>
                <Icon className="w-6 h-6" />
              </div>

              <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-bold text-white">{plan.price}€</span>
                {plan.isMonthly && (
                  <span className="text-gray-400">/{language === 'es' ? 'mes' : 'شهر'}</span>
                )}
              </div>

              <div className="flex-1 space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="mt-1 bg-navy-dark rounded-full p-1 shrink-0">
                      <Check className="w-3 h-3 text-cyan" />
                    </div>
                    <span className="text-gray-300 text-sm leading-relaxed">{feature}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => onSelectPlan(plan.id)}
                className={`w-full py-4 rounded-xl font-bold transition-all shadow-lg ${
                  plan.popular 
                    ? 'bg-gradient-to-r from-cyan to-cyan-dark hover:from-cyan-light hover:to-cyan text-white shadow-cyan/20' 
                    : 'bg-navy-dark hover:bg-navy border border-navy-lighter hover:border-cyan text-white'
                }`}
              >
                {language === 'es' ? 'Elegir Plan' : 'اختر الخطة'}
              </button>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default SubscriptionPlansDisplay;