import React, { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { stripeSubscriptionService } from '@/services/stripeSubscriptionService';
import { usePayment } from '@/contexts/PaymentContext';
import { Loader2, ShieldCheck, Mail, Phone, User, AlertTriangle, RefreshCw, ArrowLeft } from 'lucide-react';
import CountryCodeSelect from './ui/CountryCodeSelect';
import { useToast } from './ui/use-toast';
import { paymentDebugService } from '@/services/paymentDebugService';

const SubscriptionPaymentForm = ({ plan = 'basic', onBack }) => {
  const { language } = useLanguage();
  const { toast } = useToast();
  const { setIsProcessing, isProcessing } = usePayment();

  const [errorMessage, setErrorMessage] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    countryCode: '+34'
  });

  const plans = {
    basic: {
      name: language === 'es' ? 'Plan Básico' : 'الخطة الأساسية',
      price: '9.99',
      description: language === 'es' ? 'Consulta IA 15 min + Respuesta con videollamada en tiempo real' : 'استشارة الذكاء الاصطناعي 15 دقيقة + رد عبر مكالمة فيديو في الوقت الفعلي',
      isMonthly: false
    },
    standard: {
      name: language === 'es' ? 'Plan Estándar' : 'الخطة القياسية',
      price: '14.99',
      description: language === 'es' ? 'Consulta IA + Videollamada 5 veces al mes + Verificación PDF + Prioridad' : 'استشارة الذكاء الاصطناعي + مكالمة فيديو 5 مرات في الشهر + التحقق من PDF + الأولوية',
      isMonthly: false
    },
    appointments: {
      name: language === 'es' ? 'Plan Búsqueda de Citas' : 'خطة بحث المواعيد',
      price: '12.99',
      description: language === 'es' ? 'Buscar citas + Mandar WhatsApp al cliente + Acompañamiento del proceso + Videollamada en vivo paso a paso' : 'بحث المواعيد + إرسال واتساب للعميل + مرافقة العملية + مكالمة فيديو مباشرة خطوة بخطوة',
      isMonthly: false
    },
    pro: {
      name: language === 'es' ? 'Plan Pro' : 'خطة المحترفين',
      price: '27.99',
      description: language === 'es' ? 'Todo ilimitado en el sitio web + Abonne cada mes + Todo incluido' : 'كل شيء غير محدود على الموقع + اشتراك شهري + شامل كلياً',
      isMonthly: true
    }
  };

  const selectedPlan = plans[plan] || plans.basic;

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    if (errorMessage) setErrorMessage('');
  };

  const handleCountryChange = (code) => {
      setFormData(prev => ({ ...prev, countryCode: code }));
  };

  const validateForm = () => {
    paymentDebugService.logStep('SubscriptionForm', 'Validating', formData);
    
    if (!formData.name.trim()) {
       setErrorMessage(language === 'es' ? 'Por favor, introduce tu nombre.' : 'يرجى إدخال اسمك.');
       return false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || !emailRegex.test(formData.email)) {
      setErrorMessage(language === 'es' ? 'Por favor, introduce un email válido.' : 'يرجى إدخال بريد إلكتروني صالح.');
      return false;
    }
    
    const phoneClean = formData.phone.replace(/[\s-]/g, '');
    if (!formData.phone || phoneClean.length < 6) {
      setErrorMessage(language === 'es' ? 'Por favor, introduce un teléfono válido.' : 'يرجى إدخال رقم هاتف صالح.');
      return false;
    }
    
    return true;
  };

  const handleSubscribe = async (e) => {
    if (e) e.preventDefault();
    setErrorMessage('');
    
    if (!validateForm()) return;

    setIsProcessing(true);
    paymentDebugService.logStep('SubscriptionForm', 'Initiating Checkout');
    
    try {
      const result = await stripeSubscriptionService.createCheckoutSession(
        formData.email,
        plan
      );

      if (result.error) {
        throw new Error(result.error);
      }

      if (!result.url) {
        throw new Error('No redirect URL received from payment service');
      }

      paymentDebugService.logStep('SubscriptionForm', 'Redirecting', result.url);
      
      toast({
        title: language === 'es' ? 'Redirigiendo...' : 'جاري التوجيه...',
        description: language === 'es' ? 'Conectando con la pasarela de pago segura.' : 'الاتصال ببوابة الدفع الآمنة.'
      });

      setTimeout(() => {
        window.location.href = result.url;
      }, 1000);

    } catch (err) {
      paymentDebugService.logError('SubscriptionForm:Submit', err);
      
      let displayMessage = language === 'es' ? 'Error al iniciar el pago.' : 'خطأ في بدء الدفع.';
      if (err.message.includes('timeout')) {
        displayMessage = language === 'es' ? 'Tiempo de espera agotado.' : 'انتهى وقت الانتظار.';
      }

      setErrorMessage(`${displayMessage} ${err.message}`);
      setIsProcessing(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {onBack && (
        <button 
          onClick={onBack}
          type="button"
          className="mb-4 flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          {language === 'es' ? 'Cambiar plan' : 'تغيير الخطة'}
        </button>
      )}

      <div className="bg-navy-light border border-navy-lighter rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan/5 rounded-full blur-3xl -mr-10 -mt-10" />

        <div className="relative z-10 text-center mb-6 border-b border-navy-lighter pb-6">
          <h3 className="text-xl font-bold text-white mb-1">{selectedPlan.name}</h3>
          <p className="text-gray-400 text-xs mb-3 italic px-4">{selectedPlan.description}</p>
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-4xl font-bold text-cyan">{selectedPlan.price}€</span>
            {selectedPlan.isMonthly && (
              <span className="text-gray-400">/ {language === 'es' ? 'mes' : 'شهر'}</span>
            )}
          </div>
        </div>

        <div className="space-y-4 mb-8">
          <div className="space-y-1">
            <label className="text-xs text-gray-400 ml-1 uppercase tracking-wide">
               {language === 'es' ? 'Nombre Completo' : 'الاسم الكامل'}
            </label>
            <div className="relative group">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-cyan transition-colors" />
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                disabled={isProcessing}
                placeholder={language === 'es' ? 'Ej. Juan Pérez' : 'الاسم'}
                className="w-full bg-navy border border-navy-lighter rounded-xl py-3 pl-10 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-cyan disabled:opacity-50 transition-all"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-gray-400 ml-1 uppercase tracking-wide">Email</label>
            <div className="relative group">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-cyan transition-colors" />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                disabled={isProcessing}
                placeholder="tu@email.com"
                className="w-full bg-navy border border-navy-lighter rounded-xl py-3 pl-10 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-cyan disabled:opacity-50 transition-all"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs text-gray-400 ml-1 uppercase tracking-wide">
              {language === 'es' ? 'Teléfono Móvil' : 'رقم الهاتف المحمول'}
            </label>
            <div className="flex gap-2 h-[48px]">
              <div className="relative w-1/3 h-full">
                <CountryCodeSelect
                   value={formData.countryCode}
                   onChange={handleCountryChange}
                   className={`h-full ${isProcessing ? 'opacity-50 pointer-events-none' : ''}`}
                />
              </div>
              <div className="relative w-2/3 h-full group">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-cyan transition-colors" />
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  disabled={isProcessing}
                  placeholder="612 345 678"
                  className="w-full h-full bg-navy border border-navy-lighter rounded-xl pl-10 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-cyan disabled:opacity-50 transition-all"
                />
              </div>
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-400 text-sm p-3 rounded-lg mb-4 flex items-start gap-2 animate-in fade-in slide-in-from-top-1">
            <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        <button
          onClick={handleSubscribe}
          disabled={isProcessing}
          type="button"
          className="w-full bg-gradient-to-r from-cyan to-cyan-dark hover:from-cyan-light hover:to-cyan text-white font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed shadow-lg shadow-cyan/20 transform hover:-translate-y-0.5 active:translate-y-0"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              {language === 'es' ? 'Procesando...' : 'جاري المعالجة...'}
            </>
          ) : errorMessage ? (
            <>
              <RefreshCw className="w-5 h-5" />
              {language === 'es' ? 'Reintentar Pago' : 'إعادة المحاولة'}
            </>
          ) : (
            <>
              <ShieldCheck className="w-5 h-5" />
              {language === 'es' ? 'Pagar y Suscribirse' : 'ادفع واشترك'}
            </>
          )}
        </button>
        
        <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-gray-500">
          <ShieldCheck className="w-3 h-3" />
          <span>Secured by Stripe • 256-bit Encryption</span>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPaymentForm;