import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PricingPlansSection = () => {
  const navigate = useNavigate();

  const handleSelectPlan = (planId) => {
    navigate(`/subscription-checkout?plan=${planId}`);
  };

  const plans = [
    {
      id: 'basic',
      name: 'Plan Básico',
      price: '9.99',
      features: [
        'Consulta IA 15 min',
        'Respuesta con videollamada en tiempo real'
      ],
      color: 'from-blue-500 to-cyan-400',
      buttonStyle: 'bg-blue-600 hover:bg-blue-700 text-white',
      isMonthly: false
    },
    {
      id: 'standard',
      name: 'Plan Estándar',
      price: '14.99',
      features: [
        'Consulta IA',
        'Videollamada 5 veces al mes',
        'Verificación de documentos PDF',
        'Prioridad en respuesta',
        'Historial de chats guardado'
      ],
      color: 'from-purple-500 to-indigo-400',
      buttonStyle: 'bg-purple-600 hover:bg-purple-700 text-white',
      popular: true,
      isMonthly: false
    },
    {
      id: 'appointments',
      name: 'Plan Búsqueda de Citas',
      price: '12.99',
      features: [
        'Buscar citas',
        'Mandar WhatsApp al cliente',
        'Acompañamiento del proceso',
        'Videollamada en vivo paso a paso'
      ],
      color: 'from-emerald-500 to-teal-400',
      buttonStyle: 'bg-emerald-600 hover:bg-emerald-700 text-white',
      isMonthly: false
    },
    {
      id: 'pro',
      name: 'Plan Pro',
      price: '27.99',
      features: [
        'Todo ilimitado en el sitio web',
        'Abonne cada mes',
        'Todo incluido'
      ],
      color: 'from-orange-500 to-amber-400',
      buttonStyle: 'bg-orange-600 hover:bg-orange-700 text-white',
      isMonthly: true
    }
  ];

  return (
    <section className="py-20 px-4 bg-navy relative overflow-hidden" id="planes">
      <div className="absolute inset-0 bg-gradient-to-b from-navy to-navy-light opacity-50"></div>
      
      <div className="max-w-[1400px] mx-auto relative z-10">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold text-white mb-6"
          >
            Nuestros <span className="text-cyan">Planes</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-gray-300 text-lg max-w-2xl mx-auto"
          >
            Elige el plan de suscripción que mejor se adapte a tus necesidades de extranjería y gestoría.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`relative bg-navy-light rounded-xl shadow-lg border border-navy-lighter hover:border-gray-600 transition-all duration-300 flex flex-col overflow-hidden ${
                plan.popular ? 'transform scale-105 shadow-cyan/20 border-cyan/50' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-cyan to-blue-500"></div>
              )}
              
              <div className="p-6 flex-1 flex flex-col">
                {plan.popular && (
                  <span className="bg-cyan/20 text-cyan text-xs font-bold px-3 py-1 rounded-full w-max mb-4">
                    MÁS POPULAR
                  </span>
                )}
                
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-4xl font-extrabold text-white">${plan.price}</span>
                  {plan.isMonthly && <span className="text-gray-400">/mes</span>}
                </div>
                
                <ul className="space-y-4 mb-8 flex-1">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-cyan flex-shrink-0 mt-0.5" />
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleSelectPlan(plan.id)}
                  className={`w-full py-3 px-4 rounded-lg font-bold transition-all transform hover:scale-105 shadow-lg ${plan.buttonStyle}`}
                >
                  Seleccionar Plan
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingPlansSection;