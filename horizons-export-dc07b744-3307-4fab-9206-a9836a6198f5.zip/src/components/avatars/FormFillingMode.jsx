import React, { useState } from 'react';
import { Check, ChevronRight, FileEdit } from 'lucide-react';

const FormFillingMode = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});

  const steps = [
    { id: 1, title: "Datos Personales", fields: ["Nombre", "Apellidos", "NIE"] },
    { id: 2, title: "Domicilio", fields: ["Dirección", "Código Postal", "Provincia"] },
    { id: 3, title: "Contacto", fields: ["Email", "Teléfono"] }
  ];

  const handleNext = () => {
    if (step < steps.length) setStep(step + 1);
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">
               Formulario EX-10
            </span>
            <span className="text-xs text-slate-400">Paso {step} de {steps.length}</span>
        </div>
        <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 transition-all duration-300" 
              style={{ width: `${(step / steps.length) * 100}%` }}
            ></div>
        </div>
      </div>

      <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <FileEdit className="w-5 h-5 text-blue-400" />
            {steps[step - 1].title}
          </h3>

          <div className="space-y-4">
             {steps[step - 1].fields.map(field => (
                <div key={field}>
                   <label className="text-xs text-slate-400 block mb-1.5 ml-1">{field}</label>
                   <input 
                     className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2.5 text-sm text-white focus:border-blue-500 outline-none transition-colors"
                     placeholder={`Ingresa tu ${field.toLowerCase()}`}
                     value={formData[field] || ''}
                     onChange={(e) => handleChange(field, e.target.value)}
                   />
                </div>
             ))}
          </div>

          <button 
            onClick={handleNext}
            className="w-full mt-6 bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-lg font-medium flex items-center justify-center gap-2 transition-colors"
          >
             {step === steps.length ? 'Finalizar y Guardar' : 'Siguiente'}
             {step === steps.length ? <Check className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
      </div>

      <p className="text-[10px] text-slate-500 text-center mt-4">
         🔒 Tus datos están encriptados y seguros según RGPD.
      </p>
    </div>
  );
};

export default FormFillingMode;