import React from 'react';
import { Check, Star, Zap, Crown } from 'lucide-react';
import { useAvatarSystem } from '@/contexts/AvatarSystemContext';

const plans = [
    {
        id: 'basic',
        name: 'Básico',
        price: '9.99€',
        icon: Star,
        color: 'text-slate-400',
        features: ['15 min con Khalid', 'Chat IA Básico', 'Sin verificación de docs']
    },
    {
        id: 'standard',
        name: 'Estándar',
        price: '19.99€',
        icon: Zap,
        color: 'text-blue-400',
        popular: true,
        features: ['30 min con Avatars', 'Verificación Docs (Miriam)', 'Guía Citas (Mohammad)']
    },
    {
        id: 'pro',
        name: 'Pro',
        price: '29.99€',
        icon: Crown,
        color: 'text-amber-400',
        features: ['Tiempo Ilimitado', 'Soporte Prioritario', 'Alertas de Citas VIP', 'Gestión Completa']
    }
];

const SubscriptionPlansForAvatars = () => {
  const { updateSubscription, subscriptionTier } = useAvatarSystem();

  return (
    <div className="w-full py-6">
       <h3 className="text-center text-white text-lg font-bold mb-6">Elige tu Plan de Asistencia</h3>
       <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto px-4">
          {plans.map(plan => {
             const Icon = plan.icon;
             const isCurrent = subscriptionTier === plan.id;
             return (
                <div 
                   key={plan.id}
                   className={`relative bg-slate-900/80 border rounded-xl p-6 flex flex-col transition-all hover:scale-105 ${
                       plan.popular ? 'border-blue-500 shadow-lg shadow-blue-500/20' : 'border-slate-700'
                   }`}
                >
                   {plan.popular && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                          Recomendado
                      </div>
                   )}
                   
                   <div className="flex justify-between items-start mb-4">
                      <div>
                          <h4 className={`font-bold ${plan.color}`}>{plan.name}</h4>
                          <span className="text-2xl font-bold text-white">{plan.price}</span>
                          <span className="text-xs text-slate-500">/mes</span>
                      </div>
                      <Icon className={`w-6 h-6 ${plan.color}`} />
                   </div>

                   <ul className="space-y-3 mb-6 flex-1">
                      {plan.features.map((feat, i) => (
                          <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                             <Check className="w-3.5 h-3.5 text-green-500 shrink-0 mt-0.5" />
                             {feat}
                          </li>
                      ))}
                   </ul>

                   <button 
                      onClick={() => updateSubscription(plan.id)}
                      disabled={isCurrent}
                      className={`w-full py-2.5 rounded-lg text-sm font-semibold transition-all ${
                          isCurrent 
                          ? 'bg-slate-800 text-slate-500 cursor-default'
                          : plan.popular 
                            ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/20'
                            : 'bg-slate-700 hover:bg-slate-600 text-white'
                      }`}
                   >
                      {isCurrent ? 'Plan Actual' : 'Seleccionar'}
                   </button>
                </div>
             );
          })}
       </div>
    </div>
  );
};

export default SubscriptionPlansForAvatars;