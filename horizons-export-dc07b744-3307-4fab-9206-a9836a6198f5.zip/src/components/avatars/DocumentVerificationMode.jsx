import React, { useState } from 'react';
import { Upload, CheckCircle, AlertTriangle, FileText, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

const DocumentVerificationMode = ({ onVerificationComplete }) => {
  const [dragActive, setDragActive] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [result, setResult] = useState(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      verifyFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      verifyFile(e.target.files[0]);
    }
  };

  const verifyFile = async (file) => {
    setVerifying(true);
    setResult(null);
    
    // Simulate Verification Service
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    setVerifying(false);
    // Mock result logic
    const isSuccess = Math.random() > 0.3; 
    
    setResult({
      success: isSuccess,
      fileName: file.name,
      message: isSuccess 
        ? "Documento válido. Fecha de caducidad: 12/2025." 
        : "Documento ilegible o caducado. Por favor sube una imagen más clara."
    });
    
    if (onVerificationComplete && isSuccess) onVerificationComplete(file);
  };

  return (
    <div className="w-full max-w-md mx-auto bg-slate-800/50 rounded-xl p-6 border border-slate-700">
      <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
        <FileText className="text-purple-400 w-5 h-5" />
        Verificación Documental
      </h3>
      
      <div 
        className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all ${
           dragActive ? 'border-purple-500 bg-purple-500/10' : 'border-slate-600 hover:border-slate-500'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input 
          type="file" 
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          onChange={handleChange}
          accept=".pdf,.jpg,.png"
        />
        
        {verifying ? (
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
            <p className="text-sm text-slate-300">Analizando documento...</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 text-slate-400">
            <Upload className="w-8 h-8 mb-2" />
            <p className="text-sm">Arrastra tu NIE o Pasaporte aquí</p>
            <p className="text-xs text-slate-500">PDF o JPG (Máx 5MB)</p>
          </div>
        )}
      </div>

      {result && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`mt-4 p-4 rounded-lg flex items-start gap-3 ${
            result.success ? 'bg-green-900/20 border border-green-800' : 'bg-red-900/20 border border-red-800'
          }`}
        >
          {result.success ? (
            <CheckCircle className="w-5 h-5 text-green-400 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          )}
          <div>
             <p className={`text-sm font-medium ${result.success ? 'text-green-300' : 'text-red-300'}`}>
               {result.success ? 'Verificado Correctamente' : 'Error de Verificación'}
             </p>
             <p className="text-xs text-slate-400 mt-1">{result.message}</p>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default DocumentVerificationMode;