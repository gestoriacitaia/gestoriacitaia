import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mic, MicOff, MessageCircle, Signal } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAvatarSystem } from '@/contexts/AvatarSystemContext';
import DocumentUpload from '../DocumentUpload';
import ChatInterface from '../ChatInterface';
import { AVATAR_DEFINITIONS } from '@/services/AvatarSystemService';
import AnimatedAvatarPlayer from '@/components/AnimatedAvatarPlayer';

const RealTimeAvatarInterface = () => {
  const { language } = useLanguage();
  const { isRecording, toggleRecording } = useAvatarSystem();
  
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [avatarTrigger, setAvatarTrigger] = useState(null);

  // Default to Khalid for the single avatar view
  const avatar = AVATAR_DEFINITIONS['khalid'] || {
    name: "Khalid",
    role: "AI Immigration Specialist",
    description: "Expert in Spanish Immigration Law"
  };

  return (
    <div className="w-full h-full flex flex-col relative">
        
        {/* Chat Overlay */}
        <ChatInterface isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />

        {/* Header */}
        <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-10 pointer-events-none">
           <div className="flex items-center gap-3 pointer-events-auto">
              <span className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold px-3 py-1.5 bg-emerald-500/10 rounded-full border border-emerald-500/20 backdrop-blur-md">
                 <Signal className="w-3 h-3" /> 
                 {language === 'es' ? 'EN LÍNEA' : 'ONLINE'}
              </span>
              <div className="flex flex-col bg-black/40 px-3 py-1 rounded-lg backdrop-blur-sm">
                <span className="text-white font-bold text-sm leading-tight">{avatar.name}</span>
                <span className="text-slate-400 text-xs">{avatar.role}</span>
              </div>
           </div>
        </div>

        {/* Main Avatar Display - ANIMATED VERSION */}
        <div className="flex-1 flex flex-col items-center justify-center relative w-full bg-gradient-to-b from-slate-800 to-slate-900 overflow-hidden">
           <div className="absolute inset-0 w-full h-full">
               <AnimatedAvatarPlayer 
                  avatarId="default"
                  triggerSpeak={avatarTrigger}
               />
           </div>
        </div>

        {/* Professional Control Bar */}
        <div className="relative z-10 bg-slate-900/90 backdrop-blur-xl border-t border-slate-800 p-6 md:p-8">
           <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* Button 1: Upload PDF */}
              <DocumentUpload />

              {/* Button 2: Chat */}
              <button 
                onClick={() => setIsChatOpen(!isChatOpen)}
                className={`group flex items-center justify-center gap-3 px-6 py-4 rounded-2xl border transition-all duration-300 hover:scale-[1.02] shadow-lg ${
                    isChatOpen 
                    ? 'bg-blue-900/30 border-blue-500/50 text-blue-100' 
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                }`}
              >
                <div className={`p-2 rounded-lg transition-colors ${isChatOpen ? 'bg-blue-500 text-white' : 'bg-blue-500/10 text-blue-400 group-hover:bg-blue-500/20'}`}>
                    <MessageCircle className="w-5 h-5" />
                </div>
                <span className="font-semibold text-sm">Chat</span>
              </button>

              {/* Button 3: Mic */}
              <button 
                onClick={toggleRecording}
                className={`group flex items-center justify-center gap-3 px-6 py-4 rounded-2xl border transition-all duration-300 hover:scale-[1.02] shadow-lg ${
                    isRecording 
                    ? 'bg-red-900/20 border-red-500/30 text-red-200' 
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                }`}
              >
                <div className={`p-2 rounded-lg transition-colors ${isRecording ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/10 text-blue-400 group-hover:bg-blue-500/20'}`}>
                    {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </div>
                <span className="font-semibold text-sm">
                    {isRecording 
                      ? (language === 'es' ? 'Silenciar' : 'Mute') 
                      : (language === 'es' ? 'Micrófono' : 'Microphone')
                    }
                </span>
              </button>

           </div>
        </div>

    </div>
  );
};

export default RealTimeAvatarInterface;