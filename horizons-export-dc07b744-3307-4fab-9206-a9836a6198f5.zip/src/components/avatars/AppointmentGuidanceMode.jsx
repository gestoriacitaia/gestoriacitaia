import React from 'react';
import { ExternalLink, Calendar, Bell, ShieldAlert } from 'lucide-react';

const AppointmentGuidanceMode = () => {
  return (
    <div className="w-full max-w-md mx-auto space-y-4">
        <div className="bg-amber-900/20 border border-amber-700/50 p-4 rounded-xl flex gap-3">
           <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0" />
           <p className="text-xs text-amber-200">
              Nunca compartas tus datos bancarios para conseguir una cita. La cita previa es un trámite gratuito.
           </p>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
           <div className="p-4 bg-slate-900/50 border-b border-slate-700">
              <h3 className="font-semibold text-white flex items-center gap-2">
                 <Calendar className="w-4 h-4 text-emerald-400" />
                 Sede Electrónica Oficial
              </h3>
           </div>
           
           <div className="p-5 space-y-4">
               <div className="flex gap-4 items-start">
                   <div className="w-6 h-6 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                   <div className="text-sm text-slate-300">
                      Entra en la web oficial de Administraciones Públicas.
                   </div>
               </div>
               <div className="flex gap-4 items-start">
                   <div className="w-6 h-6 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                   <div className="text-sm text-slate-300">
                      Selecciona tu provincia (ej. Madrid, Barcelona).
                   </div>
               </div>
               <div className="flex gap-4 items-start">
                   <div className="w-6 h-6 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</div>
                   <div className="text-sm text-slate-300">
                      Elige "Policía - Toma de Huellas" o "Oficina de Extranjería".
                   </div>
               </div>

               <a 
                 href="https://icp.administracionelectronica.gob.es/icpplus/index.html" 
                 target="_blank" 
                 rel="noopener noreferrer"
                 className="block w-full text-center bg-slate-700 hover:bg-slate-600 text-white py-2.5 rounded-lg text-sm transition-colors mt-2"
               >
                 Abrir Sede Electrónica <ExternalLink className="w-3 h-3 inline ml-1" />
               </a>
           </div>
        </div>

        <div className="bg-blue-900/20 border border-blue-800 rounded-xl p-4 flex items-center justify-between">
           <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-blue-400" />
              <div>
                 <p className="text-sm font-medium text-white">Alertas de Citas</p>
                 <p className="text-xs text-blue-300">Te avisamos por WhatsApp</p>
              </div>
           </div>
           <button className="text-xs bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-md transition-colors">
              Activar
           </button>
        </div>
    </div>
  );
};

export default AppointmentGuidanceMode;