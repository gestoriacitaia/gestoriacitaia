import React from 'react';
import { Globe } from 'lucide-react';

export const COUNTRY_CODES = [
  { code: '+34', country: 'España', flag: '🇪🇸' },
  { code: '+212', country: 'Marruecos', flag: '🇲🇦' },
  { code: '+1', country: 'USA', flag: '🇺🇸' },
  { code: '+44', country: 'UK', flag: '🇬🇧' },
  { code: '+33', country: 'Francia', flag: '🇫🇷' },
  { code: '+39', country: 'Italia', flag: '🇮🇹' },
  { code: '+49', country: 'Alemania', flag: '🇩🇪' },
  { code: '+41', country: 'Suiza', flag: '🇨🇭' },
  { code: '+43', country: 'Austria', flag: '🇦🇹' },
  { code: '+31', country: 'Países Bajos', flag: '🇳🇱' },
];

const CountryCodeSelect = ({ value, onChange, className = "" }) => {
  return (
    <div className={`relative ${className}`}>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-full bg-navy-dark border border-navy-lighter rounded-lg pl-2 pr-1 text-white text-sm appearance-none focus:outline-none focus:border-cyan cursor-pointer flex items-center"
      >
        {COUNTRY_CODES.map((country) => (
          <option key={country.code} value={country.code}>
             {country.flag} {country.code}
          </option>
        ))}
      </select>
    </div>
  );
};

export default CountryCodeSelect;