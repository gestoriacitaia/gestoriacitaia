import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';
import AvatarInitialMenu from '@/components/avatar-chat/AvatarInitialMenu';
import ConsulateAppointmentSearch from '@/components/avatar-chat/ConsulateAppointmentSearch';
import DocumentVerificationFlow from '@/components/avatar-chat/DocumentVerificationFlow';
import FormFillingAssistant from '@/components/avatar-chat/FormFillingAssistant';
import PaymentGateFlow from '@/components/payment/PaymentGateFlow';
import ChatMessageList from '@/components/avatar-chat/ChatMessageList';
import ChatInputForm from '@/components/avatar-chat/ChatInputForm';
import { useAvatarChat } from '@/hooks/useAvatarChat';
import { AVATAR_CONFIG } from '@/config/AvatarSystemConfig';
import { Globe, RefreshCw } from 'lucide-react';

const EnhancedAvatarChatComponent = () => {
  const [activeFlow, setActiveFlow] = useState(null); // 'tramites', 'ayudas', 'traduccion', 'citas'
  const [selectedAvatar, setSelectedAvatar] = useState(null);
  const [language, setLanguage] = useState('es'); 
  
  const {
    messages,
    isLoading,
    sendMessage
  } = useAvatarChat({
    openaiKey: import.meta.env.VITE_OPENAI_API_KEY,
    elevenLabsKey: import.meta.env.VITE_ELEVENLABS_API_KEY,
    didKey: import.meta.env.VITE_DID_API_KEY
  });

  const handleSelectFlow = (flowId, avatarId) => {
    setActiveFlow(flowId);
    setSelectedAvatar(AVATAR_CONFIG[avatarId]);
    // Send initial context message implicitly
    sendMessage(`Hola, he seleccionado la opción: ${flowId}. ¿Cómo empezamos?`, null);
  };

  const handleSend = (text, file) => {
    sendMessage(text, file);
  };

  return (
    <>
      <Helmet>
        <title>Sala de Consulta Ampliada - GestoríaCitaIA</title>
      </Helmet>

      <div className="min-h-screen bg-navy flex flex-col font-sans text-white">
        <GestoriaHeader />

        <main className="flex-1 w-full px-4 py-8 max-w-[1600px] mx-auto">
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 border-b border-slate-700 pb-4">
            <h1 className="text-3xl font-bold text-white">Asistente Virtual Integral</h1>
            <div className="flex items-center gap-2 bg-slate-800 p-1 border border-slate-700">
              <Globe className="w-4 h-4 text-slate-400 ml-2" />
              <button 
                onClick={() => setLanguage('es')}
                className={`px-4 py-2 text-sm font-bold rounded-none transition-colors ${language === 'es' ? 'bg-cyan text-navy' : 'text-slate-400 hover:text-white'}`}
              >
                Castellano
              </button>
              <button 
                onClick={() => setLanguage('darija')}
                className={`px-4 py-2 text-sm font-bold rounded-none transition-colors ${language === 'darija' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'}`}
              >
                Darija
              </button>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-6 items-start">
            
            {/* Left Sidebar Menu */}
            <div className="w-full lg:w-72 flex-shrink-0">
              <AvatarInitialMenu onSelectFlow={handleSelectFlow} />
              
              {selectedAvatar && (
                <div className="mt-6 p-4 bg-slate-800 border border-slate-700 rounded-none text-center">
                  <img src={selectedAvatar.image} alt={selectedAvatar.name} className="w-24 h-24 rounded-full mx-auto mb-3 border-2 border-cyan object-cover" />
                  <h4 className="font-bold text-white text-lg">{selectedAvatar.name}</h4>
                  <p className="text-xs text-slate-400">{selectedAvatar.role}</p>
                  
                  <button onClick={() => {setActiveFlow(null); setSelectedAvatar(null);}} className="mt-4 text-xs flex items-center justify-center gap-1 mx-auto text-slate-500 hover:text-white">
                    <RefreshCw className="w-3 h-3" /> Cambiar Asesor
                  </button>
                </div>
              )}
            </div>

            {/* Main Wide Area */}
            <div className="flex-1 w-full">
              {!activeFlow ? (
                <div className="flex items-center justify-center h-[500px] border-2 border-dashed border-slate-700 text-slate-500">
                  <p>Selecciona una opción del menú izquierdo para comenzar.</p>
                </div>
              ) : (
                <PaymentGateFlow>
                  <div className="flex flex-col xl:flex-row gap-6">
                    
                    {/* Tools Column (Left side of main area) */}
                    <div className="w-full xl:w-1/2 space-y-6">
                       {activeFlow === 'citas' && <ConsulateAppointmentSearch />}
                       {(activeFlow === 'tramites' || activeFlow === 'traduccion') && <DocumentVerificationFlow />}
                       {(activeFlow === 'tramites') && <FormFillingAssistant />}
                       {activeFlow === 'ayudas' && (
                         <div className="bg-slate-800 p-6 border border-slate-700">
                           <h3 className="font-bold text-white mb-2">Información sobre Ayudas</h3>
                           <p className="text-sm text-slate-400">Nuestro asistente especializado te orientará sobre IMV, ayudas de alquiler y prestaciones familiares. Consulta en el chat.</p>
                         </div>
                       )}
                    </div>

                    {/* Chat Interface (Right side of main area, wide) */}
                    <div className="w-full xl:w-1/2 flex flex-col h-[700px] bg-slate-800 border border-slate-700 rounded-none shadow-xl">
                      <div className="bg-slate-900 p-4 border-b border-slate-700">
                        <span className="font-bold text-white">Chat Interactivo - {selectedAvatar?.name}</span>
                      </div>
                      <ChatMessageList messages={messages} />
                      <ChatInputForm onSend={handleSend} isLoading={isLoading} />
                    </div>

                  </div>
                </PaymentGateFlow>
              )}
            </div>

          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default EnhancedAvatarChatComponent;