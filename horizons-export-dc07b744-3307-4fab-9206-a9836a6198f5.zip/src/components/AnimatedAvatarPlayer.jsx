import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RefreshCw, Video, VideoOff } from 'lucide-react';
import { didVideoService } from '@/services/DIDVideoService';
import { didSessionManager } from '@/services/DIDSessionManager';

const AnimatedAvatarPlayer = ({ 
  onSessionReady,
  onError
}) => {
  const videoRef = useRef(null);
  const [status, setStatus] = useState('disconnected'); // disconnected, initializing, ready, error
  const [errorMsg, setErrorMsg] = useState('');

  const initSession = async () => {
    if (!videoRef.current) return;
    
    try {
      setStatus('initializing');
      const session = await didVideoService.createSession(videoRef.current);
      setStatus('ready');
      if (onSessionReady) onSessionReady(session);
    } catch (error) {
      console.error("Avatar Init Error:", error);
      setStatus('error');
      setErrorMsg(error.message || "Failed to connect to Neural Interface");
      if (onError) onError(error);
    }
  };

  useEffect(() => {
    // Start session on mount
    initSession();

    return () => {
      // Cleanup happens in parent or via session manager, but good to ensure
      didSessionManager.closeSession(didVideoService);
    };
  }, []);

  return (
    <div className="relative w-full h-full bg-black/90 rounded-xl overflow-hidden shadow-2xl group">
      
      {/* Background / Placeholder */}
      <AnimatePresence>
        {status !== 'ready' && (
          <motion.div 
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-20 flex items-center justify-center bg-slate-900"
          >
             <div className="text-center p-6">
                {status === 'initializing' ? (
                   <>
                      <RefreshCw className="w-12 h-12 text-cyan animate-spin mx-auto mb-4" />
                      <p className="text-cyan font-mono text-lg tracking-widest uppercase">Initializing Stream</p>
                      <p className="text-white/40 text-xs mt-2">Connecting to D-ID Secure Node...</p>
                   </>
                ) : status === 'error' ? (
                   <>
                      <VideoOff className="w-12 h-12 text-red-500 mx-auto mb-4" />
                      <p className="text-red-400 font-mono text-sm">{errorMsg}</p>
                      <button 
                        onClick={initSession}
                        className="mt-4 px-4 py-2 bg-white/10 hover:bg-white/20 rounded text-white text-xs uppercase"
                      >
                        Retry Connection
                      </button>
                   </>
                ) : (
                   <p className="text-white/50">Standby...</p>
                )}
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Real Video Element */}
      <video 
        ref={videoRef}
        autoPlay 
        playsInline 
        className={`w-full h-full object-cover transition-opacity duration-1000 ${status === 'ready' ? 'opacity-100' : 'opacity-0'}`}
      />
      
      {/* Overlay: Live Indicator */}
      {status === 'ready' && (
         <div className="absolute top-4 left-4 z-30 flex items-center gap-2 bg-red-500/10 border border-red-500/20 px-3 py-1 rounded-full backdrop-blur-md">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-red-400 text-xs font-bold uppercase tracking-wider">Live Feed</span>
         </div>
      )}

    </div>
  );
};

export default AnimatedAvatarPlayer;