import React from 'react';
import { motion } from 'framer-motion';
import { Check, Star, AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from './ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { PAYMENT_PLANS } from '@/config/paymentPlans';

const PricingPlans = () => {
  const { language } = useLanguage();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleContract = (planId) => {
    navigate(`/subscription-checkout?plan=${planId}`);
  };

  return (
    <section className="w-full py-16 px-4 bg-navy">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-4">
          {language === 'es' ? 'Planes de Suscripción' : 'خطط الاشتراك'}
        </h2>
        <p className="text-center text-slate-400 mb-12 max-w-2xl mx-auto">
          {language === 'es' 
            ? 'Elige el nivel de soporte que necesitas para tus trámites de extranjería.' 
            : 'اختر مستوى الدعم الذي تحتاجه لإجراءات الهجرة الخاصة بك.'}
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {PAYMENT_PLANS.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`flex flex-col p-6 rounded-none relative transition-all duration-300 ${
                plan.recommended 
                  ? 'bg-navy-light border-2 border-purple shadow-[0_0_30px_rgba(168,85,247,0.15)] z-10' 
                  : 'bg-navy-light border border-navy-lighter hover:border-cyan/50'
              }`}
            >
              {plan.recommended && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple text-white px-4 py-1 rounded-none text-xs font-bold uppercase tracking-wide flex items-center gap-1 shadow-lg">
                  <Star className="w-3 h-3 fill-white" />
                  {language === 'es' ? 'Recomendado' : 'موصى به'}
                </div>
              )}

              <h3 className={`text-lg font-bold mb-4 uppercase tracking-wider ${plan.recommended ? 'text-purple-light' : 'text-cyan'}`}>
                {plan.name}
              </h3>
              
              <div className="mb-6 pb-6 border-b border-navy-lighter">
                <span className="text-4xl font-bold text-white">${plan.price}</span>
                <span className="text-gray-400 text-sm ml-1">/mes</span>
              </div>

              <div className="flex-1 space-y-4 mb-8">
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className={`mt-1 flex-shrink-0 w-4 h-4 rounded-none flex items-center justify-center ${plan.recommended ? 'bg-purple/20' : 'bg-cyan/20'}`}>
                      <Check className={`w-3 h-3 ${plan.recommended ? 'text-purple' : 'text-cyan'}`} />
                    </div>
                    <p className="text-gray-300 text-sm leading-relaxed">{feature}</p>
                  </div>
                ))}
              </div>

              <div className="mt-auto">
                <button
                  onClick={() => handleContract(plan.id)}
                  className={`w-full py-3 rounded-none font-bold transition-all text-sm uppercase tracking-wide mb-3 ${
                    plan.recommended
                      ? 'bg-purple hover:bg-purple-dark text-white'
                      : 'bg-navy-lighter hover:bg-cyan hover:text-white text-gray-300'
                  }`}
                >
                  {language === 'es' ? 'Contratar Plan' : 'اشترك الآن'}
                </button>
                <div className="flex items-start gap-2 text-xs text-slate-500 justify-center text-center">
                  <AlertCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                  Renovación automática.
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingPlans;