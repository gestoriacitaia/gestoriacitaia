import React from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { LockKeyhole } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ConsultationAuthGuard = ({ children }) => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  if (loading) {
    return <div className="min-h-screen bg-slate-950 flex items-center justify-center text-white">Cargando...</div>;
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center space-y-6">
          <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto">
            <LockKeyhole className="w-8 h-8 text-cyan" />
          </div>
          
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-white">Acceso Restringido</h2>
            <p className="text-slate-400">
              Para acceder a la consulta con nuestros especialistas IA, necesitas iniciar sesión o crear una cuenta.
            </p>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => navigate('/login')} 
              className="w-full bg-cyan hover:bg-cyan/90 text-navy font-bold h-12"
            >
              Iniciar Sesión
            </Button>
            <Button 
              variant="outline"
              onClick={() => navigate('/')} 
              className="w-full border-slate-700 text-slate-300 hover:bg-slate-800 h-12"
            >
              Volver al Inicio
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default ConsultationAuthGuard;