import React from 'react';
import { motion } from 'framer-motion';
import { Clock, ArrowLeft } from 'lucide-react';
import { cn } from '@/lib/utils';

const AppointmentTimeSelector = ({ 
  selectedDate, 
  availableSlots = [], 
  onTimeSelected, 
  onBack,
  selectedTime
}) => {
  if (!selectedDate) return null;

  // Format date for display
  const displayDate = selectedDate.toLocaleDateString('es-ES', { 
    weekday: 'long', 
    day: 'numeric', 
    month: 'long' 
  });

  // Parse ISO strings to just time "HH:MM"
  const timeOptions = availableSlots.map(iso => {
    const d = new Date(iso);
    return d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 w-full h-full flex flex-col animate-in fade-in slide-in-from-right-4">
      <div className="flex items-center gap-2 mb-4 pb-4 border-b border-slate-800">
        <button 
          onClick={onBack}
          className="p-2 hover:bg-slate-800 rounded-full text-slate-400 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h3 className="text-white font-bold text-sm">Select Time</h3>
          <p className="text-xs text-cyan capitalize">{displayDate}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 overflow-y-auto max-h-[300px] pr-2 custom-scrollbar">
        {timeOptions.length > 0 ? (
          timeOptions.map((time) => (
            <motion.button
              key={time}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onTimeSelected(time)}
              className={cn(
                "flex items-center justify-center gap-2 py-3 rounded-lg border text-sm font-medium transition-all",
                selectedTime === time 
                  ? "bg-cyan border-cyan text-navy shadow-lg" 
                  : "bg-slate-950 border-slate-800 text-slate-300 hover:border-cyan/50 hover:text-white"
              )}
            >
              <Clock className="w-4 h-4" />
              {time}
            </motion.button>
          ))
        ) : (
          <div className="col-span-2 text-center py-8 text-slate-500 text-sm">
            No slots available for this date.
          </div>
        )}
      </div>
    </div>
  );
};

export default AppointmentTimeSelector;