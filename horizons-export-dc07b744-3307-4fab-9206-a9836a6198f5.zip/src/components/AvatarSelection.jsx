import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useConsultation } from '@/contexts/ConsultationContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { CheckCircle2, Globe, Sparkles } from 'lucide-react';
import { getAvatars } from '../services/immigrationService';

const AvatarSelection = ({ onAvatarSelected }) => {
  const { selectedAvatar, setSelectedAvatar, consultationLanguage, setConsultationLanguage } = useConsultation();
  const { language } = useLanguage();
  
  // Use shared avatar service
  const [avatars] = useState(getAvatars());

  const handleAvatarClick = (avatar) => {
    setSelectedAvatar(avatar);
  };

  const handleLanguageToggle = (lang) => {
    setConsultationLanguage(lang);
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-12">
      
      {/* Language Selection */}
      <div className="mb-8 flex flex-col items-center gap-4">
        <h2 className="text-3xl md:text-4xl font-bold text-white text-center">
          {language === 'es' ? 'Selecciona tu Asesor' : 'اختر مستشارك'}
        </h2>
        <p className="text-gray-400 text-center max-w-2xl">
          {language === 'es' 
            ? 'Nuestros especialistas IA están listos para ayudarte.'
            : 'متخصصو الذكاء الاصطناعي لدينا مستعدون لمساعدتك.'
          }
        </p>
        
        {/* Language Toggle */}
        <div className="flex items-center gap-3 bg-navy-light rounded-lg p-2 border border-navy-lighter">
          <Globe className="w-5 h-5 text-cyan" />
          <span className="text-gray-400 text-sm">
            {language === 'es' ? 'Idioma de consulta:' : 'لغة الاستشارة:'}
          </span>
          <button
            onClick={() => handleLanguageToggle('es')}
            className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${
              consultationLanguage === 'es' 
                ? 'bg-cyan text-white shadow-lg shadow-cyan/20' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Castellano
          </button>
          <button
            onClick={() => handleLanguageToggle('ar')}
            className={`px-4 py-2 rounded-md text-sm font-bold transition-all ${
              consultationLanguage === 'ar' 
                ? 'bg-cyan text-white shadow-lg shadow-cyan/20' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            دارجة
          </button>
        </div>
      </div>

      {/* Avatar Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {avatars.map((avatar, index) => (
          <motion.div
            key={avatar.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            onClick={() => handleAvatarClick(avatar)}
            className={`relative bg-navy-light border-2 rounded-2xl p-6 cursor-pointer transition-all hover:scale-105 hover:shadow-2xl flex flex-col items-center ${
              selectedAvatar?.id === avatar.id
                ? 'border-cyan shadow-lg shadow-cyan/20'
                : 'border-navy-lighter hover:border-cyan/50'
            }`}
          >
            {/* Selected Indicator */}
            {selectedAvatar?.id === avatar.id && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-4 right-4 bg-cyan rounded-full p-1 z-10"
              >
                <CheckCircle2 className="w-6 h-6 text-white" />
              </motion.div>
            )}

            {/* Avatar Image */}
            <div className="relative w-32 h-32 mb-4">
              <img
                src={avatar.image}
                alt={`${avatar.name}`}
                className="w-full h-full rounded-full object-cover border-4 border-cyan/30"
                style={avatar.imageStyle}
              />
            </div>

            {/* Avatar Info */}
            <div className="text-center flex-1">
              <h3 className="text-xl font-bold text-white mb-1">
                {avatar.name}
              </h3>
              <p className="font-semibold text-xs mb-3 text-cyan uppercase tracking-wider">
                {avatar.specialty}
              </p>
              <p className="text-gray-400 text-sm leading-relaxed mb-4">
                {avatar.description}
              </p>
            </div>

            {/* Language Badges */}
            <div className="flex justify-center gap-1 mt-auto">
              {avatar.languages.map(lang => (
                <span
                  key={lang}
                  className="px-2 py-0.5 bg-navy rounded text-[10px] text-gray-300 border border-navy-lighter"
                >
                  {lang === 'es' ? '🇪🇸' : '🇲🇦'}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Continue Button */}
      {selectedAvatar && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 text-center"
        >
          <button
            onClick={() => onAvatarSelected && onAvatarSelected(selectedAvatar)}
            className="font-bold px-8 py-4 rounded-lg transition-all shadow-lg transform hover:-translate-y-1 bg-gradient-to-r from-cyan to-cyan-dark hover:from-cyan-light hover:to-cyan text-white shadow-cyan/20 flex items-center gap-2 mx-auto"
          >
            <Sparkles className="w-5 h-5" />
            {language === 'es' ? `Hablar con ${selectedAvatar.name}` : `تحدث مع ${selectedAvatar.name}`}
          </button>
        </motion.div>
      )}
    </div>
  );
};

export default AvatarSelection;