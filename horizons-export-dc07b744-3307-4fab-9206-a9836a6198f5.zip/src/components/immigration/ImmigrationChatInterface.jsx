import React, { useState, useRef, useEffect } from 'react';
import { Upload, FileCheck } from 'lucide-react';
import AvatarProfile from './AvatarProfile';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import { getAvatars } from '@/services/immigrationService';
import { getImmigrationAdvice } from '@/services/openaiService';
import { documentVerificationService } from '@/services/documentVerificationService';
import { useToast } from '../ui/use-toast';

const ImmigrationChatInterface = () => {
  const [avatars] = useState(getAvatars());
  const [selectedAvatar, setSelectedAvatar] = useState(avatars[0]);
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [language, setLanguage] = useState('es');
  const [verificationResult, setVerificationResult] = useState(null);
  
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initial greeting when component mounts or avatar changes (if first message)
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: 'init',
        sender: 'assistant',
        content: `¡Hola! Soy ${selectedAvatar.name}. Especialista en ${selectedAvatar.specialty}. ¿En qué trámite puedo ayudarte hoy?`,
        timestamp: new Date().toISOString()
      }]);
    }
  }, []);

  // Update initial message if avatar is changed before chat starts
  useEffect(() => {
    if (messages.length === 1 && messages[0].id === 'init') {
      setMessages([{
        id: 'init',
        sender: 'assistant',
        content: `¡Hola! Soy ${selectedAvatar.name}. Especialista en ${selectedAvatar.specialty}. ¿En qué trámite puedo ayudarte hoy?`,
        timestamp: new Date().toISOString()
      }]);
    }
  }, [selectedAvatar]);

  const handleSendMessage = async (text) => {
    const newUserMsg = {
      id: Date.now().toString(),
      sender: 'user',
      content: text,
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, newUserMsg]);
    setIsLoading(true);

    try {
      const advice = await getImmigrationAdvice(
        text, 
        language, 
        selectedAvatar.specialty,
        verificationResult ? [verificationResult] : []
      );

      const aiMsg = {
        id: (Date.now() + 1).toString(),
        sender: 'assistant',
        content: advice.text,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsg]);
      
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo conectar con el asistente."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast({
        variant: "destructive",
        title: "Formato incorrecto",
        description: "Por favor sube documentos en formato PDF."
      });
      return;
    }

    toast({ description: "Analizando documento..." });
    
    documentVerificationService.verifyDocument(file).then(result => {
      setVerificationResult(result);
      if (result.isValid) {
        toast({
          title: "Documento Verificado",
          description: result.feedback,
          className: "bg-green-50 border-green-200"
        });
        
        setMessages(prev => [...prev, {
          id: Date.now(),
          sender: 'assistant',
          content: `He recibido tu ${result.docType}. Veo que es válido hasta ${result.expirationDate}. ¿Qué consulta tienes sobre este documento?`,
          timestamp: new Date().toISOString()
        }]);
      } else {
        toast({
          variant: "destructive",
          title: "Error de Verificación",
          description: result.feedback
        });
      }
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[800px] max-h-[90vh]">
      
      {/* Sidebar - Avatar Selection */}
      <div className="lg:col-span-4 flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar">
        <h3 className="text-navy font-bold text-lg mb-2 px-1">Selecciona tu Especialista</h3>
        <div className="grid grid-cols-1 gap-3">
          {avatars.map(avatar => (
            <AvatarProfile
              key={avatar.id}
              avatar={avatar}
              isSelected={selectedAvatar.id === avatar.id}
              onClick={() => setSelectedAvatar(avatar)}
            />
          ))}
        </div>

        {/* Document Verification Card */}
        <div className="mt-4 bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h4 className="font-semibold text-navy mb-2 flex items-center gap-2">
            <Upload className="w-4 h-4 text-cyan" />
            Verificación de Documentos
          </h4>
          <p className="text-xs text-gray-500 mb-4">
            Sube tu NIE, Pasaporte o resolución para análisis instantáneo.
          </p>
          
          <input 
            type="file" 
            ref={fileInputRef}
            className="hidden" 
            accept="application/pdf"
            onChange={handleFileUpload}
          />
          
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-2 bg-gray-50 hover:bg-gray-100 text-navy border border-gray-200 border-dashed rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-2"
          >
            {verificationResult?.isValid ? (
              <>
                <FileCheck className="w-4 h-4 text-green-500" />
                Documento Cargado
              </>
            ) : (
              <>
                Subir PDF (DNI/NIE)
              </>
            )}
          </button>
          
          {verificationResult && (
            <div className={`mt-3 text-[10px] p-2 rounded ${verificationResult.isValid ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
              {verificationResult.feedback}
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="lg:col-span-8 flex flex-col bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 relative">
        {/* Chat Header */}
        <div className="p-4 border-b border-gray-100 bg-white/80 backdrop-blur-md z-10 flex items-center justify-between sticky top-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-cyan shadow-sm">
              <img 
                src={selectedAvatar.image} 
                alt={selectedAvatar.name} 
                className="w-full h-full object-cover" 
              />
            </div>
            <div>
              <h2 className="font-bold text-navy text-sm">{selectedAvatar.name}</h2>
              <p className="text-[10px] text-gray-500 flex items-center gap-1 uppercase tracking-wider font-semibold">
                {selectedAvatar.specialty}
              </p>
              <p className="text-[10px] text-green-600 flex items-center gap-1 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                Disponible ahora
              </p>
            </div>
          </div>
          <div className="hidden sm:block text-[10px] font-bold px-3 py-1 bg-cyan/10 text-cyan rounded-full border border-cyan/20">
            ASISTENTE IA CERTIFICADO
          </div>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-6 bg-gray-50/50">
          {messages.map((msg) => (
            <ChatMessage 
              key={msg.id} 
              message={msg} 
              avatarImage={selectedAvatar.image}
            />
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <ChatInput 
          onSend={handleSendMessage}
          onUpload={() => fileInputRef.current?.click()}
          isLoading={isLoading}
          language={language}
          setLanguage={setLanguage}
        />
      </div>
    </div>
  );
};

export default ImmigrationChatInterface;