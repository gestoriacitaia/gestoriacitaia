import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare } from 'lucide-react';
import { cn } from '@/lib/utils';

const AvatarProfile = ({ avatar, isSelected, onClick }) => {
  if (!avatar) return null;

  return (
    <motion.div
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      onClick={onClick}
      className={cn(
        "relative cursor-pointer rounded-xl p-3 transition-all duration-300 flex items-center gap-4 overflow-hidden",
        "border",
        isSelected 
          ? "border-cyan bg-cyan/5 shadow-md" 
          : "border-gray-100 bg-white hover:border-cyan/30 hover:shadow-sm"
      )}
    >
      {/* Avatar Image - Left Side */}
      <div className="relative shrink-0">
        <div className={cn(
          "w-16 h-16 rounded-full overflow-hidden border-2",
          isSelected ? "border-cyan" : "border-gray-100"
        )}>
          <img 
            src={avatar.image || 'https://via.placeholder.com/150'} 
            alt={avatar.name || 'Avatar'}
            className="w-full h-full object-cover"
            style={avatar.imageStyle}
            loading="lazy"
          />
        </div>
      </div>

      {/* Info Content - Right Side */}
      <div className="flex flex-col items-start flex-1 min-w-0">
        <h3 className="font-bold text-navy text-base truncate w-full">{avatar.name || 'Asistente'}</h3>
        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wide truncate w-full mb-2">
          {avatar.specialty || 'Especialista'}
        </p>
        
        <button 
          className={cn(
            "text-[10px] font-bold py-1.5 px-3 rounded-full flex items-center gap-1.5 transition-colors",
            isSelected 
              ? "bg-cyan text-white shadow-sm" 
              : "bg-gray-100 text-gray-600 group-hover:bg-cyan/10 group-hover:text-cyan"
          )}
        >
          <MessageSquare className="w-3 h-3" />
          Hablar Ahora
        </button>
      </div>
    </motion.div>
  );
};

export default AvatarProfile;