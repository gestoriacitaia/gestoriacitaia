import React from 'react';
import { motion } from 'framer-motion';
import { User, Bot } from 'lucide-react';
import { cn } from '@/lib/utils';

const ChatMessage = ({ message, avatarImage }) => {
  const isUser = message.sender === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex w-full gap-4 mb-6",
        isUser ? "flex-row-reverse" : "flex-row"
      )}
    >
      {/* Avatar Circle */}
      <div className={cn(
        "flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center overflow-hidden shadow-sm mt-1",
        isUser ? "bg-cyan" : "bg-white border border-gray-100"
      )}>
        {isUser ? (
          <User className="w-6 h-6 text-white" />
        ) : (
          avatarImage ? (
            <img src={avatarImage} alt="Assistant" className="w-full h-full object-cover" />
          ) : (
            <Bot className="w-6 h-6 text-navy" />
          )
        )}
      </div>

      {/* Message Bubble */}
      <div className={cn(
        "max-w-[80%] rounded-2xl px-5 py-3.5 shadow-sm text-sm leading-relaxed",
        isUser 
          ? "bg-cyan text-white rounded-tr-none" 
          : "bg-white text-gray-700 border border-gray-100 rounded-tl-none"
      )}>
        <p className="whitespace-pre-wrap">{message.content}</p>
        
        {/* Footer Metadata */}
        <div className={cn(
          "flex items-center gap-2 mt-2 text-[10px] opacity-70",
          isUser ? "text-cyan-100 justify-end" : "text-gray-400"
        )}>
          <span>{new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          {message.isTranslated && <span>• Traducido</span>}
        </div>
      </div>
    </motion.div>
  );
};

export default ChatMessage;