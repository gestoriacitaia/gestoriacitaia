import React, { useState } from 'react';
import { Send, Mic, Globe, Paperclip } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useToast } from '../ui/use-toast';

const ChatInput = ({ onSend, onUpload, isLoading, language, setLanguage }) => {
  const [text, setText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const { toast } = useToast();

  const handleSend = () => {
    if (!text.trim() || isLoading) return;
    onSend(text);
    setText('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleVoice = () => {
    if (isListening) {
      setIsListening(false);
    } else {
      setIsListening(true);
      toast({
        description: "Escuchando... (Simulación)",
      });
      // Simulate voice input
      setTimeout(() => {
        setText((prev) => prev + " Hola, necesito ayuda con mi arraigo.");
        setIsListening(false);
      }, 2000);
    }
  };

  return (
    <div className="bg-white border-t border-gray-100 p-4 shadow-lg shadow-gray-100/50">
      <div className="flex items-center gap-2 mb-3">
        {/* Language Toggle */}
        <button
          onClick={() => setLanguage(language === 'es' ? 'ar' : 'es')}
          className="flex items-center gap-2 text-xs font-medium text-gray-500 hover:text-cyan transition-colors bg-gray-50 px-3 py-1.5 rounded-full"
        >
          <Globe className="w-3.5 h-3.5" />
          {language === 'es' ? 'Español' : 'Darija (Moroccan)'}
        </button>
        
        <span className="text-xs text-gray-300 ml-auto">
          {text.length} caracteres
        </span>
      </div>

      <div className="flex items-end gap-2 bg-gray-50 rounded-xl p-2 border border-gray-200 focus-within:ring-2 focus-within:ring-cyan/20 focus-within:border-cyan transition-all">
        {/* Upload Button */}
        <button 
          onClick={onUpload}
          className="p-2 text-gray-400 hover:text-cyan hover:bg-white rounded-lg transition-all"
          title="Subir documento"
        >
          <Paperclip className="w-5 h-5" />
        </button>

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={language === 'es' ? "Escribe tu consulta..." : "كتب السؤال ديالك..."}
          className="flex-1 bg-transparent border-none resize-none focus:ring-0 max-h-32 min-h-[44px] py-2.5 text-sm text-gray-700 placeholder:text-gray-400"
          rows={1}
          disabled={isLoading}
        />

        {/* Voice Toggle */}
        <button
          onClick={toggleVoice}
          className={cn(
            "p-2 rounded-lg transition-all",
            isListening 
              ? "text-red-500 bg-red-50 animate-pulse" 
              : "text-gray-400 hover:text-navy hover:bg-white"
          )}
        >
          <Mic className="w-5 h-5" />
        </button>

        {/* Send Button */}
        <button
          onClick={handleSend}
          disabled={!text.trim() || isLoading}
          className="p-2.5 bg-cyan hover:bg-cyan-dark text-white rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-cyan/20"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
      
      {isLoading && (
        <div className="text-[10px] text-gray-400 mt-2 flex items-center gap-1.5 animate-pulse">
          <div className="w-1.5 h-1.5 bg-cyan rounded-full" />
          Procesando respuesta...
        </div>
      )}
    </div>
  );
};

export default ChatInput;