import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import AppointmentSearch from './AppointmentSearch';
import { Loader2, AlertCircle } from 'lucide-react';

const BuscarCitaCheckout = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState('verifying');
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const success = searchParams.get('success');
    const canceled = searchParams.get('canceled');

    if (canceled) {
      setStatus('canceled');
      return;
    }

    if (success) {
      // Retrieve user data stored before redirect
      const storedData = localStorage.getItem('buscar_cita_user_data');
      if (storedData) {
        setUserData(JSON.parse(storedData));
        setStatus('success');
      } else {
        setStatus('error'); // Payment success but data lost?
      }
    } else {
      // Direct access without params? Redirect home
      navigate('/');
    }
  }, [searchParams, navigate]);

  if (status === 'verifying') {
    return (
      <div className="min-h-screen bg-navy flex items-center justify-center">
         <div className="text-center">
            <Loader2 className="w-10 h-10 text-cyan animate-spin mx-auto mb-4" />
            <p className="text-gray-400">Verificando pago...</p>
         </div>
      </div>
    );
  }

  if (status === 'canceled') {
    return (
       <div className="min-h-screen bg-navy flex items-center justify-center p-4">
         <div className="bg-navy-light p-8 rounded-2xl border border-red-500/30 text-center max-w-md">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Pago Cancelado</h2>
            <p className="text-gray-400 mb-6">El proceso de pago no se completó. No se ha realizado ningún cargo.</p>
            <button 
               onClick={() => navigate('/')}
               className="bg-navy border border-gray-600 text-white px-6 py-2 rounded-lg hover:bg-navy-dark"
            >
               Volver
            </button>
         </div>
      </div>
    );
  }

  if (status === 'success' && userData) {
    return (
      <div className="min-h-screen bg-navy flex items-center justify-center p-4">
        {/* Render the search component immediately after verification */}
        <AppointmentSearch userData={userData} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy flex items-center justify-center text-white">
       <p>Error desconocido. Por favor contacta con soporte.</p>
    </div>
  );
};

export default BuscarCitaCheckout;