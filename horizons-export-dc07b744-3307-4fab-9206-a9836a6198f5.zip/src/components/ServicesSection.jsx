import React from 'react';
import { motion } from 'framer-motion';
import { Check, Shield } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const ServicesSection = () => {
  const { t, language } = useLanguage();

  return (
    <section id="services" className="py-16 bg-navy relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-cyan/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-purple/5 rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-center gap-2 mb-3"
          >
            <Shield className="w-5 h-5 text-cyan" />
            <span className="text-cyan font-bold uppercase tracking-wider text-sm">Legal & Safe</span>
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold text-white mb-4"
          >
            {t.servicesTitle}
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 max-w-2xl mx-auto"
          >
            {t.servicesSubtitle}
          </motion.p>
        </div>
        
        <div 
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-7xl mx-auto" 
          dir={language === 'ar' ? 'rtl' : 'ltr'}
        >
          {t.servicesList.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.02, backgroundColor: 'rgba(30, 41, 59, 0.8)' }}
              className="flex items-center gap-3 bg-navy-light border border-navy-lighter p-4 rounded-xl shadow-sm hover:border-cyan/50 hover:shadow-cyan/10 transition-all cursor-default group"
            >
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-cyan/10 flex items-center justify-center group-hover:bg-cyan/20 transition-colors">
                <Check className="w-3.5 h-3.5 text-cyan" />
              </div>
              <span className="text-sm font-medium text-gray-200 group-hover:text-white transition-colors">
                {service}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;