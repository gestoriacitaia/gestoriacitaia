import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, Search } from 'lucide-react';
import BuscarCitaPaymentForm from './payment/BuscarCitaPaymentForm';
import { useLanguage } from '../contexts/LanguageContext';

const BuscarCitaModal = ({ isOpen, onClose }) => {
  const { t } = useLanguage();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-navy-dark/95 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="bg-navy w-full max-w-4xl rounded-2xl shadow-2xl border border-navy-light overflow-hidden relative my-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-navy-light bg-navy/50">
             <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-cyan/10 flex items-center justify-center text-cyan border border-cyan/20">
                   <Search className="w-5 h-5" />
                </div>
                <div>
                   <h2 className="text-xl font-bold text-white">Buscador de Citas Express</h2>
                   <p className="text-sm text-gray-400">Servicio automatizado 24/7. Precio fijo: 9.99€</p>
                </div>
             </div>
             <button 
               onClick={onClose}
               className="p-2 rounded-full hover:bg-navy-light text-gray-400 hover:text-white transition-colors"
             >
               <X className="w-6 h-6" />
             </button>
          </div>

          {/* Form Content */}
          <div className="max-h-[80vh] overflow-y-auto custom-scrollbar bg-navy">
             <BuscarCitaPaymentForm />
          </div>

        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default BuscarCitaModal;