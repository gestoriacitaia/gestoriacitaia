import React, { useEffect, useRef, useState } from 'react';
import { didSessionManager } from '@/services/DIDSessionManager';
import { Loader2, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

const RealTimeConsultationAvatar = ({ avatarId }) => {
  const videoRef = useRef(null);
  const [status, setStatus] = useState('connecting'); // connecting, connected, error
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    let mounted = true;

    const connect = async () => {
      setStatus('connecting');
      try {
        if (!videoRef.current) return;
        
        didSessionManager.onConnectionStateChange = (state) => {
          if (!mounted) return;
          console.log('WebRTC State:', state);
          if (state === 'connected') setStatus('connected');
          if (state === 'disconnected' || state === 'failed') setStatus('error');
        };

        await didSessionManager.initSession(avatarId, videoRef.current);
      } catch (error) {
        console.error("Avatar Connection Error:", error);
        if (mounted) setStatus('error');
      }
    };

    connect();

    return () => {
      mounted = false;
      didSessionManager.closeSession();
    };
  }, [avatarId, retryCount]);

  const handleRetry = () => {
    setRetryCount(c => c + 1);
  };

  return (
    <div className="relative w-full h-full bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full h-full object-cover"
      />

      {/* Status Overlay */}
      <div className="absolute top-4 left-4 flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full text-xs font-mono">
        {status === 'connected' ? (
          <><Wifi className="w-3 h-3 text-green-500" /><span className="text-green-500">LIVE LINK</span></>
        ) : status === 'error' ? (
          <><WifiOff className="w-3 h-3 text-red-500" /><span className="text-red-500">DISCONNECTED</span></>
        ) : (
          <><Loader2 className="w-3 h-3 text-yellow-500 animate-spin" /><span className="text-yellow-500">CONNECTING...</span></>
        )}
      </div>

      {/* Loading State */}
      {status === 'connecting' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm z-10">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-cyan/30 border-t-cyan rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
               <span className="text-xs font-bold text-cyan">AI</span>
            </div>
          </div>
          <p className="mt-4 text-cyan font-mono text-sm tracking-widest animate-pulse">ESTABLISHING NEURAL LINK</p>
        </div>
      )}

      {/* Error State */}
      {status === 'error' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-20">
          <WifiOff className="w-12 h-12 text-red-500 mb-4" />
          <p className="text-white font-bold mb-2">Connection Lost</p>
          <Button onClick={handleRetry} variant="outline" className="border-red-500 text-red-500 hover:bg-red-950">
            Retry Connection
          </Button>
        </div>
      )}
    </div>
  );
};

export default RealTimeConsultationAvatar;