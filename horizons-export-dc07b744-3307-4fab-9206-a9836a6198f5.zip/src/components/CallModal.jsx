import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mic, MicOff, MessageCircle, FileText, PhoneOff, Signal, Loader2, Wifi, ShieldCheck, Download } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from './ui/use-toast';

const CallModal = ({ isOpen, onClose, avatar }) => {
  const { language } = useLanguage();
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  
  const [callState, setCallState] = useState('connecting'); // connecting, connected, ended
  const [isMuted, setIsMuted] = useState(false);
  const [isChatActive, setIsChatActive] = useState(false);
  const [duration, setDuration] = useState(0);
  const [connectionQuality, setConnectionQuality] = useState(3); // 0-3 bars

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setCallState('connecting');
      setDuration(0);
      setIsMuted(false);
      setIsChatActive(false);
      
      // Simulate connection delay
      const connectTimer = setTimeout(() => {
        setCallState('connected');
      }, 2500);

      return () => clearTimeout(connectTimer);
    }
  }, [isOpen]);

  // Call timer
  useEffect(() => {
    let interval;
    if (callState === 'connected') {
      interval = setInterval(() => {
        setDuration(prev => prev + 1);
        // Simulate fluctuating connection quality
        if (Math.random() > 0.8) {
          setConnectionQuality(Math.floor(Math.random() * 2) + 2); // 2 or 3 bars
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callState]);

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    setCallState('ended');
    setTimeout(onClose, 800);
  };

  const handleFileClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        toast({
          variant: "destructive",
          title: language === 'es' ? "Error" : "Error",
          description: language === 'es' ? "Solo archivos PDF." : "Only PDF files allowed."
        });
        return;
      }
      toast({
        title: language === 'es' ? "Documento recibido" : "Document received",
        description: `${file.name} - ${language === 'es' ? 'Analizando...' : 'Analyzing...'}`,
        className: "bg-blue-900 border-slate-700 text-white"
      });
    }
  };

  const toggleChat = () => {
    setIsChatActive(!isChatActive);
    toast({
      description: isChatActive 
        ? (language === 'es' ? "Chat minimizado" : "Chat minimized")
        : (language === 'es' ? "Chat abierto" : "Chat opened"),
      className: "bg-slate-800 border-slate-700 text-white duration-2000"
    });
  };

  const buttonBaseClass = "px-6 py-4 md:px-8 md:py-4 text-base md:text-lg rounded-none font-bold text-white flex items-center justify-center gap-3 transition-all duration-200 hover:scale-105 hover:shadow-xl shadow-lg w-full sm:w-auto min-w-[160px]";

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-0 md:p-6 overflow-hidden"
      >
        <div className="relative w-full h-full md:max-w-6xl md:h-[90vh] flex flex-col bg-slate-900 shadow-2xl overflow-hidden border border-slate-800">
            
            {/* --- Top Bar (Status & Info) --- */}
            <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-slate-900/90 via-slate-900/50 to-transparent z-30 flex justify-between items-start p-4 md:p-6 pointer-events-none">
               
               {/* User Info & Secure Badge */}
               <div className="flex flex-col gap-1 pointer-events-auto">
                  <div className="flex items-center gap-2">
                     <div className="flex items-center justify-center w-8 h-8 rounded-none bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                        <ShieldCheck className="w-4 h-4" />
                     </div>
                     <span className="text-emerald-400 text-xs font-bold tracking-wide">
                        {language === 'es' ? 'CONEXIÓN SEGURA E-2EE' : 'SECURE E-2EE CONNECTION'}
                     </span>
                  </div>
                  <div className="flex items-center gap-2 pl-1">
                     <span className={`w-2 h-2 rounded-none ${callState === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-amber-500'}`}></span>
                     <span className="text-slate-300 text-sm font-medium">
                        {callState === 'connected' ? formatDuration(duration) : (language === 'es' ? 'Conectando...' : 'Connecting...')}
                     </span>
                  </div>
               </div>

               {/* Right Side: Connection & Close */}
               <div className="flex items-center gap-4 pointer-events-auto">
                  {callState === 'connected' && (
                    <div className="flex items-center gap-1.5 bg-slate-800/50 backdrop-blur px-3 py-1.5 rounded-none border border-slate-700">
                        <Wifi className={`w-4 h-4 ${connectionQuality > 1 ? 'text-green-400' : 'text-yellow-400'}`} />
                        <span className="text-xs text-slate-300 hidden md:inline">HD Quality</span>
                    </div>
                  )}
                  <button 
                     onClick={handleEndCall} 
                     className="bg-slate-800/80 hover:bg-red-500/20 hover:text-red-400 text-slate-400 px-4 py-2 rounded-none backdrop-blur-md transition-all border border-transparent hover:border-red-500/30"
                  >
                     <X className="w-6 h-6" />
                  </button>
               </div>
            </div>

            {/* --- Main Video Area --- */}
            <div className="flex-1 relative bg-gradient-to-br from-slate-800 to-slate-950 flex flex-col items-center justify-center overflow-hidden">
               
               {/* Background Ambient Glow */}
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-900/10 blur-[100px] rounded-none pointer-events-none"></div>

               {/* Avatar Container */}
               <div className="relative z-10 w-full h-full max-h-[80vh] flex items-center justify-center p-4 md:p-8">
                  <div className="relative w-full max-w-lg md:max-w-2xl aspect-square md:aspect-[4/3] flex items-center justify-center">
                      
                      {/* Video/Image Placeholder */}
                      <div className="relative w-full h-full rounded-none overflow-hidden shadow-2xl border border-slate-700/50 bg-slate-900 group">
                          
                          {/* Simulated Video Stream (Image) */}
                          {avatar?.image && (
                            <img 
                              src={avatar.image} 
                              alt={avatar.name || "Specialist"} 
                              className={`w-full h-full object-cover transition-all duration-700 ${callState === 'connected' ? 'scale-105 opacity-100' : 'scale-100 opacity-60 blur-sm'}`}
                            />
                          )}
                          {!avatar?.image && (
                             <div className="w-full h-full bg-slate-800 flex items-center justify-center">
                                <span className="text-6xl">👨🏽‍⚖️</span>
                             </div>
                          )}
                          
                          {/* Gradient Overlay for Text Readability */}
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-80"></div>

                          {/* Avatar Name Tag */}
                          <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
                              <div>
                                 <h2 className="text-white text-xl md:text-2xl font-bold drop-shadow-md">{avatar?.name || "Immigration Specialist"}</h2>
                                 <p className="text-blue-300 text-sm md:text-base font-medium drop-shadow-sm flex items-center gap-2">
                                    {avatar?.role || "Expert Consultant"}
                                    {callState === 'connected' && !isMuted && (
                                       <span className="flex gap-0.5 h-3 items-end">
                                          <motion.span animate={{ height: [4, 12, 4] }} transition={{ repeat: Infinity, duration: 0.5 }} className="w-1 bg-green-400 rounded-none" />
                                          <motion.span animate={{ height: [6, 16, 6] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.1 }} className="w-1 bg-green-400 rounded-none" />
                                          <motion.span animate={{ height: [4, 10, 4] }} transition={{ repeat: Infinity, duration: 0.4, delay: 0.2 }} className="w-1 bg-green-400 rounded-none" />
                                       </span>
                                    )}
                                 </p>
                              </div>
                          </div>
                      </div>

                      {/* Connecting State Overlay */}
                      {callState === 'connecting' && (
                         <div className="absolute inset-0 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm rounded-none z-20">
                            <div className="flex flex-col items-center gap-4">
                               <div className="relative">
                                  <div className="absolute inset-0 bg-green-500 blur-xl opacity-20 animate-pulse rounded-none"></div>
                                  <Loader2 className="w-16 h-16 text-green-400 animate-spin relative z-10" />
                               </div>
                               <p className="text-slate-300 font-medium tracking-wide animate-pulse">
                                  {language === 'es' ? 'Estableciendo conexión...' : 'Establishing connection...'}
                                </p>
                            </div>
                         </div>
                      )}

                  </div>
               </div>
            </div>

            {/* --- Bottom Controls Bar --- */}
            <div className="relative z-30 bg-slate-900/80 backdrop-blur-xl border-t border-slate-800 pb-8 pt-6 px-6 md:pb-10">
               <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center gap-4 md:gap-6">
                  
                  {/* Hidden File Input */}
                  <input 
                    type="file" 
                    accept=".pdf" 
                    ref={fileInputRef} 
                    className="hidden" 
                    onChange={handleFileChange} 
                  />

                  {/* Mic Toggle */}
                  <button 
                    onClick={() => setIsMuted(!isMuted)}
                    className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
                  >
                     {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                     {isMuted ? (language === 'es' ? 'Silenciado' : 'Muted') : (language === 'es' ? 'Micrófono' : 'Mic')}
                  </button>

                  {/* Chat Button */}
                  <button 
                    onClick={toggleChat}
                    className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
                  >
                     <MessageCircle className="w-6 h-6" />
                     Chat
                  </button>

                  {/* PDF Upload */}
                  <button 
                    onClick={handleFileClick}
                    className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
                  >
                     <Download className="w-6 h-6" />
                     PDF
                  </button>

                  {/* End Call */}
                  <button 
                    onClick={handleEndCall}
                    className={`${buttonBaseClass} bg-red-600 hover:bg-red-700`}
                  >
                     <PhoneOff className="w-6 h-6" />
                     {language === 'es' ? 'Fin' : 'End'}
                  </button>

               </div>
            </div>

        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default CallModal;