import React, { useState, useEffect } from 'react';
import { Share2, Copy, CheckCircle, Users } from 'lucide-react';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useReferralSystem } from '@/hooks/useReferralSystem';
import { useToast } from '@/components/ui/use-toast';

const ReferralLinkSection = () => {
  const { user } = useGoogleAuth();
  const { generateReferralLink, getReferralCount } = useReferralSystem();
  const { toast } = useToast();
  
  const [link, setLink] = useState('');
  const [count, setCount] = useState(0);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (user?.id) {
      generateReferralLink(user.id).then(setLink);
      getReferralCount(user.id).then(setCount);
    }
  }, [user]);

  const handleCopy = () => {
    if (link) {
      navigator.clipboard.writeText(link);
      setCopied(true);
      toast({ title: "¡Enlace copiado!", description: "Listo para compartir con tus amigos." });
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="bg-gradient-to-br from-navy-light to-navy border border-cyan/20 p-6 rounded-2xl shadow-xl relative overflow-hidden mb-6">
      <div className="absolute top-0 right-0 w-32 h-32 bg-cyan/10 rounded-full blur-3xl -mr-10 -mt-10" />
      
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
        <div>
          <h3 className="text-xl font-bold text-white flex items-center gap-2 mb-2">
            <Share2 className="w-5 h-5 text-cyan" /> Invita y Gana
          </h3>
          <p className="text-gray-400 text-sm mb-4">
            Por cada 3 amigos que se registren, ¡ganas 1 mes de Plan Estándar gratis!
          </p>
          
          <div className="flex items-center gap-2 bg-navy-dark p-2 rounded-lg border border-navy-lighter">
            <code className="text-cyan text-sm px-2 truncate max-w-[200px] sm:max-w-xs">{link || 'Generando enlace...'}</code>
            <button 
              onClick={handleCopy}
              className="bg-cyan hover:bg-cyan-light text-navy p-2 rounded-md transition-colors ml-auto"
            >
              {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="bg-navy-dark border border-cyan/30 rounded-xl p-4 text-center min-w-[150px]">
          <Users className="w-8 h-8 text-cyan mx-auto mb-2" />
          <div className="text-3xl font-bold text-white">{count}</div>
          <div className="text-xs text-gray-400 uppercase tracking-wider">Referidos</div>
        </div>
      </div>
    </div>
  );
};

export default ReferralLinkSection;