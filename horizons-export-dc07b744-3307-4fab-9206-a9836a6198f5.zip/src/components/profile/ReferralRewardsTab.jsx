import React, { useEffect, useState } from 'react';
import { Gift, Clock, CheckCircle, Loader2 } from 'lucide-react';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useReferralSystem } from '@/hooks/useReferralSystem';

const ReferralRewardsTab = () => {
  const { user } = useGoogleAuth();
  const { getReferralRewards } = useReferralSystem();
  const [rewards, setRewards] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      getReferralRewards(user.id).then(res => {
        setRewards(res);
        setLoading(false);
      });
    }
  }, [user]);

  if (loading) return <div className="p-8 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-cyan" /></div>;

  return (
    <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-6">
        <Gift className="w-6 h-6 text-yellow-500" /> Mis Recompensas
      </h2>

      {rewards.length === 0 ? (
        <div className="text-center py-12 bg-navy rounded-xl border border-dashed border-navy-lighter">
          <Gift className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400">Aún no tienes recompensas. ¡Invita amigos para ganar planes!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {rewards.map((reward) => {
            const isActive = reward.status === 'active' && new Date(reward.expires_at) > new Date();
            
            return (
              <div key={reward.id} className={`p-5 rounded-xl border relative overflow-hidden ${isActive ? 'bg-gradient-to-br from-navy to-navy-dark border-yellow-500/50' : 'bg-navy border-navy-lighter opacity-70'}`}>
                {isActive && (
                  <div className="absolute top-0 right-0 bg-yellow-500 text-navy text-xs font-bold px-3 py-1 rounded-bl-lg">
                    ACTIVA
                  </div>
                )}
                
                <div className="flex items-start gap-4 mb-4">
                  <div className={`p-3 rounded-lg ${isActive ? 'bg-yellow-500/20 text-yellow-500' : 'bg-gray-800 text-gray-500'}`}>
                    <Gift className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-white font-bold">{reward.plan_type}</h3>
                    <p className="text-xs text-gray-400">Por referir 3 amigos</p>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between text-gray-400">
                    <span className="flex items-center gap-1"><CheckCircle className="w-4 h-4" /> Activada:</span>
                    <span>{new Date(reward.activated_at).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center justify-between text-gray-400">
                    <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> Vence:</span>
                    <span className={isActive ? 'text-yellow-500' : ''}>{new Date(reward.expires_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ReferralRewardsTab;