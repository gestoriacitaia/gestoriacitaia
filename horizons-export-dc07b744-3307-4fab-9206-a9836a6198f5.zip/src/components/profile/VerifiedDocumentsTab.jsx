import React, { useEffect, useState } from 'react';
import { CheckCircle, FileCheck, Eye, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useToast } from '@/components/ui/use-toast';

const VerifiedDocumentsTab = () => {
  const { user } = useGoogleAuth();
  const { toast } = useToast();
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVerifiedDocs = async () => {
      if (!user) return;
      try {
        const { data, error } = await supabase
          .from('tabla_documentos')
          .select('*')
          .eq('cliente_id', user.id)
          .eq('verificado', true)
          .order('fecha_subida', { ascending: false });

        if (error) throw error;
        setDocuments(data || []);
      } catch (error) {
        console.error("Error fetching verified docs:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchVerifiedDocs();
  }, [user]);

  const handlePreview = () => {
    toast({
      title: "🚧 Función en desarrollo",
      description: "La vista previa segura de documentos estará disponible pronto.",
      duration: 3000,
    });
  };

  if (loading) return <div className="p-8 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-green-500" /></div>;

  return (
    <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-6">
        <FileCheck className="w-6 h-6 text-green-500" /> Documentos Verificados
      </h2>

      {documents.length === 0 ? (
        <div className="text-center py-12 bg-navy rounded-xl border border-dashed border-navy-lighter">
          <AlertCircle className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-400">No tienes documentos verificados en este momento.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {documents.map((doc) => (
            <div key={doc.id} className="p-4 bg-navy rounded-xl border border-green-500/20 flex flex-col justify-between h-full">
              <div className="flex items-start gap-3 mb-4">
                <div className="mt-1">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                </div>
                <div>
                  <h3 className="text-white font-medium">{doc.nombre_documento || doc.tipo || 'Documento Verificado'}</h3>
                  <p className="text-xs text-gray-400 mt-1">
                    Verificado el {new Date(doc.fecha_subida).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <button 
                onClick={handlePreview}
                className="w-full flex items-center justify-center gap-2 py-2 bg-navy-dark hover:bg-navy-lighter text-sm text-gray-300 rounded-lg transition-colors border border-navy-lighter hover:border-gray-600"
              >
                <Eye className="w-4 h-4" /> Ver Documento
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default VerifiedDocumentsTab;