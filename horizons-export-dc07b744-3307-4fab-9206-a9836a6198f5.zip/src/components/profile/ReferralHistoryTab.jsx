import React, { useEffect, useState } from 'react';
import { Users, UserPlus, Calendar, Loader2 } from 'lucide-react';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useReferralSystem } from '@/hooks/useReferralSystem';
import ReferralLinkSection from './ReferralLinkSection';

const ReferralHistoryTab = () => {
  const { user } = useGoogleAuth();
  const { getReferralHistory, getReferralCount } = useReferralSystem();
  const [history, setHistory] = useState([]);
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      Promise.all([
        getReferralHistory(user.id),
        getReferralCount(user.id)
      ]).then(([h, c]) => {
        setHistory(h);
        setCount(c);
        setLoading(false);
      });
    }
  }, [user]);

  const progress = (count % 3) / 3 * 100;
  const remaining = 3 - (count % 3);

  return (
    <div className="space-y-6">
      <ReferralLinkSection />

      <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-6">
          <Users className="w-6 h-6 text-cyan" /> Historial de Referidos
        </h2>

        <div className="mb-8 bg-navy p-4 rounded-xl border border-navy-lighter">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-400">Progreso para recompensa</span>
            <span className="text-cyan font-bold">{count % 3} / 3</span>
          </div>
          <div className="w-full bg-navy-dark rounded-full h-2.5 mb-2">
            <div className="bg-cyan h-2.5 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-xs text-gray-500">
            {remaining === 3 ? 'Refiere a 3 amigos para ganar un mes de Plan Estándar.' : `Solo faltan ${remaining} referidos para tu próxima recompensa.`}
          </p>
        </div>

        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-cyan" /></div>
        ) : history.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-navy-lighter rounded-xl">
            <UserPlus className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <p className="text-gray-400">Aún no has invitado a nadie.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {history.map((item) => (
              <div key={item.id} className="flex items-center justify-between bg-navy p-4 rounded-xl border border-navy-lighter">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-navy-dark flex items-center justify-center text-cyan font-bold">
                    {item.referred_user?.nombre?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <p className="text-white font-medium">{item.referred_user?.nombre || 'Usuario Anónimo'}</p>
                    <p className="text-xs text-gray-400">{item.referred_user?.email || 'Sin email'}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center gap-1 text-xs bg-green-500/10 text-green-400 px-2 py-1 rounded-full mb-1">
                    Completado
                  </span>
                  <p className="text-xs text-gray-500 flex items-center justify-end gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(item.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ReferralHistoryTab;