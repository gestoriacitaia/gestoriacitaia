import React, { useEffect, useState } from 'react';
import { FileText, Download, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useToast } from '@/components/ui/use-toast';

const PDFsFilledTab = () => {
  const { user } = useGoogleAuth();
  const { toast } = useToast();
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPDFs = async () => {
      if (!user) return;
      try {
        const { data, error } = await supabase
          .from('tabla_documentos')
          .select('*')
          .eq('cliente_id', user.id)
          .eq('generado_automaticamente', true)
          .order('fecha_generacion', { ascending: false });

        if (error) throw error;
        setDocuments(data || []);
      } catch (error) {
        console.error("Error fetching PDFs:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPDFs();
  }, [user]);

  const handleDownload = async (docUrl, docName) => {
    try {
      toast({ title: "Preparando descarga...", description: docName });
      
      // If it's a storage path
      if (docUrl && !docUrl.startsWith('http')) {
         const { data, error } = await supabase.storage.from('documentos').download(docUrl);
         if (error) throw error;
         
         const url = URL.createObjectURL(data);
         const a = document.createElement('a');
         a.href = url;
         a.download = docName || 'documento.pdf';
         a.click();
         URL.revokeObjectURL(url);
      } else if (docUrl) {
         window.open(docUrl, '_blank');
      } else {
          throw new Error("URL de documento no disponible");
      }
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: "No se pudo descargar el archivo." });
    }
  };

  if (loading) return <div className="p-8 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-cyan" /></div>;

  return (
    <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-6">
        <FileText className="w-6 h-6 text-cyan" /> PDFs Llenados
      </h2>

      {documents.length === 0 ? (
        <div className="text-center py-12 bg-navy rounded-xl border border-dashed border-navy-lighter">
          <AlertCircle className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-400">No tienes documentos PDF generados automáticamente aún.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {documents.map((doc) => (
            <div key={doc.id} className="flex items-center justify-between p-4 bg-navy rounded-xl border border-navy-lighter hover:border-cyan/50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-red-500/10 text-red-400 rounded-lg">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-white font-medium">{doc.nombre_documento || 'Documento sin título'}</h3>
                  <p className="text-sm text-gray-400">
                    Generado el {new Date(doc.fecha_generacion || doc.fecha_subida).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => handleDownload(doc.url_documento || doc.documento_url, doc.nombre_documento)}
                className="p-2 hover:bg-cyan/10 text-cyan rounded-lg transition-colors"
                title="Descargar"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PDFsFilledTab;