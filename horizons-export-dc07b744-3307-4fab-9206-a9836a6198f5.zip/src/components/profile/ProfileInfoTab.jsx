import React from 'react';
import { User, Mail, CreditCard, Calendar, Clock, Edit } from 'lucide-react';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useToast } from '@/components/ui/use-toast';

const ProfileInfoTab = () => {
  const { clientData, user } = useGoogleAuth();
  const { toast } = useToast();

  const handleEdit = () => {
    toast({
      title: "🚧 Función en desarrollo",
      description: "La edición de perfil estará disponible pronto.",
      duration: 3000,
    });
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'No definido';
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric', month: 'long', day: 'numeric'
    });
  };

  return (
    <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-cyan/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
      
      <div className="flex justify-between items-center mb-8 relative z-10">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <User className="w-6 h-6 text-cyan" /> Información Personal
        </h2>
        <button 
          onClick={handleEdit}
          className="flex items-center gap-2 bg-navy border border-navy-lighter hover:border-cyan text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium"
        >
          <Edit className="w-4 h-4" /> Editar
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
        <InfoCard icon={<User />} label="Nombre" value={clientData?.nombre || user?.user_metadata?.full_name || 'Sin definir'} />
        <InfoCard icon={<Mail />} label="Email" value={clientData?.email || user?.email} />
        <InfoCard icon={<CreditCard />} label="Plan Actual" value={clientData?.plan_actual || 'Ninguno'} highlight />
        <InfoCard icon={<CreditCard />} label="Tipo de Pago" value={clientData?.tipo_pago || 'No registrado'} />
        <InfoCard icon={<Calendar />} label="Inicio del Plan" value={formatDate(clientData?.fecha_inicio_plan)} />
        <InfoCard icon={<Clock />} label="Vencimiento" value={formatDate(clientData?.fecha_vencimiento)} />
      </div>
    </div>
  );
};

const InfoCard = ({ icon, label, value, highlight }) => (
  <div className="bg-navy p-4 rounded-xl border border-navy-lighter flex items-start gap-4">
    <div className={`p-3 rounded-lg ${highlight ? 'bg-cyan/20 text-cyan' : 'bg-navy-dark text-gray-400'}`}>
      {React.cloneElement(icon, { className: "w-5 h-5" })}
    </div>
    <div>
      <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">{label}</p>
      <p className={`font-semibold ${highlight ? 'text-cyan' : 'text-white'}`}>{value}</p>
    </div>
  </div>
);

export default ProfileInfoTab;