import React, { useEffect, useState } from 'react';
import { MessageSquare, Clock, ChevronRight, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useToast } from '@/components/ui/use-toast';

const ChatHistoryTab = () => {
  const { user } = useGoogleAuth();
  const { toast } = useToast();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSessions = async () => {
      if (!user) return;
      try {
        const { data, error } = await supabase
          .from('tabla_sesiones_avatar')
          .select('*')
          .eq('cliente_id', user.id)
          .order('fecha_inicio', { ascending: false });

        if (error) throw error;
        setSessions(data || []);
      } catch (error) {
        console.error("Error fetching sessions:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchSessions();
  }, [user]);

  const handleViewTranscript = () => {
    toast({
      title: "🚧 Función en desarrollo",
      description: "El visor de transcripciones detallado estará disponible pronto.",
      duration: 3000,
    });
  };

  const formatDuration = (seconds) => {
    if (!seconds) return '0 min';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s`;
  };

  if (loading) return <div className="p-8 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-cyan" /></div>;

  return (
    <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-6">
        <MessageSquare className="w-6 h-6 text-cyan" /> Historial de Chat
      </h2>

      {sessions.length === 0 ? (
        <div className="text-center py-12 bg-navy rounded-xl border border-dashed border-navy-lighter">
          <AlertCircle className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-400">No hay sesiones de chat registradas.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {sessions.map((session) => (
            <div key={session.id} className="p-4 bg-navy rounded-xl border border-navy-lighter hover:border-cyan/30 transition-colors">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-cyan/10 text-cyan rounded-lg">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-white font-medium capitalize">Avatar: {session.avatar_id || 'Asesor IA'}</h3>
                    <div className="flex items-center gap-4 mt-1 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {formatDuration(session.duracion_segundos)}
                      </span>
                      <span>{new Date(session.fecha_inicio).toLocaleString()}</span>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={handleViewTranscript}
                  className="flex items-center gap-1 text-sm text-cyan hover:text-cyan-light transition-colors self-start sm:self-center"
                >
                  Ver Detalles <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ChatHistoryTab;