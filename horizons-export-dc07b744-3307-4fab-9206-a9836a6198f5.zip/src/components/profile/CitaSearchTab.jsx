import React, { useEffect, useState } from 'react';
import { Search, MapPin, Calendar as CalIcon, Loader2, AlertCircle, XCircle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useToast } from '@/components/ui/use-toast';

const CitaSearchTab = () => {
  const { user, clientData } = useGoogleAuth();
  const { toast } = useToast();
  const [citas, setCitas] = useState([]);
  const [loading, setLoading] = useState(true);

  // Solo mostrar si el plan incluye búsqueda de citas
  const hasPlan = clientData?.plan_actual?.includes('Búsqueda de Citas') || clientData?.plan_actual?.includes('Pro');

  useEffect(() => {
    const fetchCitas = async () => {
      if (!user || !hasPlan) {
        setLoading(false);
        return;
      }
      try {
        const { data, error } = await supabase
          .from('tabla_citas')
          .select('*')
          .eq('cliente_id', user.id)
          .order('fecha_creacion', { ascending: false });

        if (error) throw error;
        setCitas(data || []);
      } catch (error) {
        console.error("Error fetching citas:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchCitas();
  }, [user, hasPlan]);

  const handleCancelSearch = () => {
    toast({
      title: "🚧 Función en desarrollo",
      description: "La cancelación de búsqueda activa estará disponible pronto.",
      duration: 3000,
    });
  };

  if (!hasPlan) {
    return (
      <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8 text-center">
        <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-white mb-2">Función No Disponible</h2>
        <p className="text-gray-400 mb-6">Tu plan actual no incluye la Búsqueda Automática de Citas.</p>
        <button 
           onClick={() => window.location.href = '/subscription-checkout'}
           className="bg-yellow-500 hover:bg-yellow-600 text-navy font-bold py-2 px-6 rounded-lg transition-colors"
        >
          Mejorar Plan
        </button>
      </div>
    );
  }

  if (loading) return <div className="p-8 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-purple-500" /></div>;

  return (
    <div className="bg-navy-light rounded-2xl shadow-xl border border-navy-lighter p-6 md:p-8">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-6">
        <Search className="w-6 h-6 text-purple-500" /> Búsqueda de Citas Activa
      </h2>

      {citas.length === 0 ? (
        <div className="text-center py-12 bg-navy rounded-xl border border-dashed border-navy-lighter">
          <Search className="w-12 h-12 text-gray-500 mx-auto mb-4 opacity-50" />
          <p className="text-gray-400 mb-4">No tienes ninguna búsqueda de cita en curso.</p>
          <button 
             onClick={() => window.location.href = '/buscar-cita-checkout'}
             className="bg-purple-600 hover:bg-purple-700 text-white font-medium py-2 px-6 rounded-lg transition-colors"
          >
            Iniciar Nueva Búsqueda
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {citas.map((cita) => {
            const isSearching = cita.estado?.toLowerCase() === 'searching' || cita.estado?.toLowerCase() === 'pendiente';
            const isFound = cita.estado?.toLowerCase() === 'found' || cita.estado?.toLowerCase() === 'confirmada';
            
            return (
              <div key={cita.id} className="p-5 bg-navy rounded-xl border border-navy-lighter relative overflow-hidden">
                {isSearching && (
                  <div className="absolute top-0 left-0 w-1 h-full bg-purple-500 animate-pulse" />
                )}
                
                <div className="flex flex-col md:flex-row justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        isSearching ? 'bg-purple-500/20 text-purple-400' : 
                        isFound ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                      }`}>
                        {cita.estado || 'Pendiente'}
                      </span>
                      <span className="text-gray-400 text-sm">{new Date(cita.fecha_creacion).toLocaleDateString()}</span>
                    </div>
                    <h3 className="text-white font-medium text-lg mb-1">{cita.notas || 'Trámite General'}</h3>
                    
                    {isFound && cita.fecha_cita && (
                      <div className="flex items-center gap-2 text-green-400 mt-3 bg-green-500/10 p-2 rounded-lg inline-flex">
                        <CalIcon className="w-4 h-4" />
                        <span className="text-sm font-medium">Cita: {new Date(cita.fecha_cita).toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center md:flex-col justify-end gap-2">
                    {isSearching && (
                      <button 
                        onClick={handleCancelSearch}
                        className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors text-sm"
                      >
                        <XCircle className="w-4 h-4" /> Cancelar
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default CitaSearchTab;