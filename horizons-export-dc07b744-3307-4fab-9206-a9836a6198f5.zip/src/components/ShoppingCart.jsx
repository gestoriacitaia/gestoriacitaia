import React from 'react';

// This component has been deprecated/removed.
export default function ShoppingCart() {
  return null;
}