import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { CheckCircle, Loader2, ArrowRight, Calendar } from 'lucide-react';
import GestoriaHeader from './GestoriaHeader';
import Footer from './Footer';

const ConsultationPaymentSuccess = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const sessionId = searchParams.get('session_id');
  
  const [status, setStatus] = useState('verifying'); // verifying, success, error
  const [details, setDetails] = useState(null);

  useEffect(() => {
    if (!sessionId) {
      setStatus('error');
      return;
    }

    const verifyAndSave = async () => {
      try {
        // 1. Verify with Edge Function
        const { data: paymentData, error: verifyError } = await supabase.functions.invoke('verify-stripe-payment', {
          body: { sessionId }
        });

        if (verifyError) throw verifyError;
        if (!paymentData?.paid) throw new Error('Payment not verified');

        setDetails(paymentData);

        // 2. Database Insertions
        // Retrieve current user (if logged in) or use anonymous logical flow
        const { data: { user } } = await supabase.auth.getUser();
        const userId = user?.id || null;
        
        // A. Insert Appointment (Cita)
        const { data: citaData, error: citaError } = await supabase
          .from('tabla_citas')
          .insert([{
            cliente_id: userId,
            avatar_id: paymentData.metadata?.avatarId || 'miriam',
            estado: 'pendiente', // As paid but not started
            notas: `Paid via Stripe ${paymentData.stripe_payment_id}`,
            fecha_cita: new Date().toISOString() // Immediate
          }])
          .select()
          .single();

        if (citaError) console.error('Error creating appointment:', citaError);

        // B. Insert Payment Record
        const { error: paymentDbError } = await supabase
          .from('tabla_pagos')
          .insert([{
            cliente_id: userId,
            cita_id: citaData?.id,
            monto: paymentData.amount,
            moneda: paymentData.currency,
            stripe_payment_id: paymentData.stripe_payment_id,
            estado: 'completado',
            fecha_pago: new Date().toISOString()
          }]);
          
        if (paymentDbError) console.error('Error saving payment:', paymentDbError);

        // C. Initialize Session Record
        if (citaData?.id) {
          await supabase
            .from('tabla_sesiones_avatar')
            .insert([{
               cliente_id: userId,
               cita_id: citaData.id,
               avatar_id: paymentData.metadata?.avatarId || 'miriam',
               fecha_inicio: new Date().toISOString()
            }]);
        }

        setStatus('success');

      } catch (error) {
        console.error('Verification failed:', error);
        setStatus('error');
      }
    };

    verifyAndSave();
  }, [sessionId]);

  const startSession = () => {
    navigate('/consultation-session', {
      state: {
        avatarId: details?.metadata?.avatarId || 'miriam',
        clientName: details?.metadata?.customerName || 'Guest'
      }
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col font-sans">
      <GestoriaHeader />
      
      <main className="flex-1 container mx-auto px-4 flex flex-col items-center justify-center py-20">
        
        {status === 'verifying' && (
          <div className="text-center animate-pulse">
            <Loader2 className="w-16 h-16 text-cyan animate-spin mx-auto mb-6" />
            <h2 className="text-2xl font-bold mb-2">Verifying Payment...</h2>
            <p className="text-slate-400">Please wait while we confirm your transaction.</p>
          </div>
        )}

        {status === 'success' && (
          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center shadow-2xl">
            <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-500" />
            </div>
            
            <h1 className="text-3xl font-bold mb-2 text-white">Payment Successful!</h1>
            <p className="text-slate-400 mb-8">
              Your consultation with <span className="text-cyan font-bold capitalize">{details?.metadata?.avatarId}</span> is ready to begin.
            </p>

            <div className="bg-slate-950 rounded-xl p-4 mb-8 border border-slate-800">
               <div className="flex justify-between text-sm mb-2">
                 <span className="text-slate-500">Transaction ID</span>
                 <span className="text-slate-300 font-mono text-xs">{details?.stripe_payment_id?.slice(-8)}</span>
               </div>
               <div className="flex justify-between text-sm">
                 <span className="text-slate-500">Amount Paid</span>
                 <span className="text-cyan font-bold">{details?.amount}€</span>
               </div>
            </div>

            <button
              onClick={startSession}
              className="w-full bg-cyan hover:bg-cyan/90 text-navy font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan/20 animate-pulse"
            >
              Start Consultation Now
              <ArrowRight className="w-5 h-5" />
            </button>
            
            <p className="mt-4 text-xs text-slate-500">
              Check your email ({details?.metadata?.customerEmail}) for the receipt.
            </p>
          </div>
        )}

        {status === 'error' && (
          <div className="max-w-md w-full bg-slate-900 border border-red-900/50 rounded-3xl p-8 text-center shadow-2xl">
            <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar className="w-10 h-10 text-red-500" />
            </div>
            <h1 className="text-2xl font-bold mb-2 text-white">Verification Failed</h1>
            <p className="text-slate-400 mb-8">
              We couldn't verify your payment automatically. If you were charged, please contact support.
            </p>
            <button
              onClick={() => navigate('/consultation/payment')}
              className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition-all"
            >
              Return to Payment
            </button>
          </div>
        )}

      </main>
      <Footer />
    </div>
  );
};

export default ConsultationPaymentSuccess;