import React, { useEffect, useState } from 'react';
import { Loader2, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

const StripeCheckout = () => {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState('loading'); // loading, success, cancel
  
  useEffect(() => {
    const success = searchParams.get('success');
    const canceled = searchParams.get('canceled');

    if (success) {
      setStatus('success');
    } else if (canceled) {
      setStatus('cancel');
    } else {
      setStatus('idle');
    }
  }, [searchParams]);

  if (status === 'loading') {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-white">
        <Loader2 className="w-12 h-12 text-cyan animate-spin mb-4" />
        <h3 className="text-xl font-bold">Procesando pago...</h3>
        <p className="text-gray-400">Por favor, no cierres esta ventana.</p>
      </div>
    );
  }

  if (status === 'success') {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-white bg-emerald-900/20 rounded-xl border border-emerald-500/30">
        <CheckCircle className="w-16 h-16 text-emerald-500 mb-4" />
        <h3 className="text-2xl font-bold mb-2">¡Pago Exitoso!</h3>
        <p className="text-gray-300 text-center max-w-md">
          Hemos recibido tu pago correctamente. Recibirás un correo electrónico con los detalles de tu cita.
        </p>
      </div>
    );
  }

  if (status === 'cancel') {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-white bg-red-900/20 rounded-xl border border-red-500/30">
        <XCircle className="w-16 h-16 text-red-500 mb-4" />
        <h3 className="text-2xl font-bold mb-2">Pago Cancelado</h3>
        <p className="text-gray-300 text-center max-w-md mb-6">
          El proceso de pago fue cancelado o no se pudo completar.
        </p>
        <button 
           onClick={() => window.location.href = '/'}
           className="flex items-center gap-2 bg-navy-light hover:bg-navy-lighter px-6 py-2 rounded-lg transition-colors border border-navy-lighter"
        >
          <RefreshCw className="w-4 h-4" /> Intentar de nuevo
        </button>
      </div>
    );
  }

  return null;
};

export default StripeCheckout;