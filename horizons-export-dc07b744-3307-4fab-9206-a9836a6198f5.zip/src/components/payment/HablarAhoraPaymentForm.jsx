import React, { useState } from 'react';
import { usePayment } from '../../contexts/PaymentContext';
import { CONSULTATION_PLANS, createConsultationCheckout } from '@/services/stripeService';
import { Loader2, ShieldCheck, ArrowRight, Phone, Mail, User, AlertCircle, CreditCard } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import CountryCodeSelect from '../ui/CountryCodeSelect';
import { useToast } from '../ui/use-toast';

const HablarAhoraPaymentForm = ({ preSelectedPlanId, onSuccess }) => {
  const { t } = useLanguage();
  const { setIsProcessing, isProcessing } = usePayment();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    countryCode: '+34',
    selectedPlan: preSelectedPlanId || 'basic'
  });
  
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Requerido';
    if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Inválido';
    if (!formData.phone.trim()) newErrors.phone = 'Requerido';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
        toast({ variant: "destructive", title: "Datos incompletos", description: "Revisa los campos." });
        return;
    }

    setIsProcessing(true);

    try {
        // Simulation of Stripe Payment for "Hablar Ahora"
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        toast({
            title: "Pago Exitoso",
            description: "Conectando con tu asistente...",
        });
        
        if (onSuccess) onSuccess();

    } catch (err) {
        toast({ variant: "destructive", title: "Error", description: err.message });
    } finally {
        setIsProcessing(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: null }));
  };

  return (
    <div className="w-full bg-navy-dark/50 p-6 rounded-xl border border-navy-light">
       <div className="mb-6">
          <h4 className="text-white font-bold text-lg mb-2 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-cyan" />
            Datos de Facturación
          </h4>
          <p className="text-xs text-gray-400">Pago único seguro para consulta inmediata.</p>
       </div>
       
       <div className="space-y-4">
         <div className="grid grid-cols-1 gap-4">
             <div className="relative">
                <User className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
                <input
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Nombre en la tarjeta"
                  className={`w-full bg-navy-dark border rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:border-cyan outline-none ${errors.name ? 'border-red-500' : 'border-navy-lighter'}`}
                />
             </div>
             
             <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-500" />
                <input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Email para recibo"
                  className={`w-full bg-navy-dark border rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:border-cyan outline-none ${errors.email ? 'border-red-500' : 'border-navy-lighter'}`}
                />
             </div>
         </div>

         {/* Plan Selector */}
         <div className="bg-navy-light/50 p-3 rounded-lg border border-navy-lighter">
            <label className="text-xs text-gray-400 uppercase font-bold mb-2 block">Plan Seleccionado</label>
            <select 
               name="selectedPlan"
               value={formData.selectedPlan}
               onChange={handleChange}
               className="w-full bg-navy-dark border border-navy-lighter rounded-lg p-2 text-sm text-white focus:outline-none focus:border-cyan"
            >
               <option value="basic">Consulta Básica (15 min) - 9.99€</option>
               <option value="standard">Consulta Estándar (30 min) - 19.99€</option>
               <option value="pro">Consulta Pro (1h + Docs) - 29.99€</option>
            </select>
         </div>
       </div>

       <button
          onClick={handleSubmit}
          disabled={isProcessing}
          type="button" 
          className="w-full mt-6 bg-gradient-to-r from-cyan to-blue-600 hover:from-cyan-light hover:to-blue-500 text-white font-bold py-3 px-4 rounded-xl transition-all shadow-lg shadow-cyan/20 flex items-center justify-center gap-2 disabled:opacity-50"
       >
          {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : "Pagar y Conectar"}
       </button>
       
       <div className="mt-4 flex justify-center items-center gap-2 text-[10px] text-gray-500">
          <ShieldCheck className="w-3 h-3 text-green-500" /> 
          <span>Pago seguro encriptado SSL</span>
       </div>
    </div>
  );
};

export default HablarAhoraPaymentForm;