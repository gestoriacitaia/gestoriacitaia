import React, { useState } from 'react';
import { usePayment } from '../../contexts/PaymentContext';
import { BUSCAR_CITA_PRODUCT, SERVICE_TYPES } from '../../config/paymentPlans';
import { Loader2, CreditCard, ShieldCheck, User, Mail, Phone, AlertCircle } from 'lucide-react';
import CountryCodeSelect from '../ui/CountryCodeSelect';
import { paymentDebugService } from '@/services/paymentDebugService';
import { useToast } from '../ui/use-toast';

const BuscarCitaPaymentForm = () => {
  const { initiatePayment, isProcessing } = usePayment();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    countryCode: '+34',
    serviceType: ''
  });
  
  const [errors, setErrors] = useState({});

  const validate = () => {
    paymentDebugService.logStep('BuscarCitaForm', 'Validating', formData);
    const newErrors = {};
    if (!formData.name) newErrors.name = 'El nombre es obligatorio';
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email inválido';
    if (!formData.phone) newErrors.phone = 'El teléfono es obligatorio';
    if (!formData.serviceType) newErrors.serviceType = 'Selecciona un trámite';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // 1. Validate
    if (!validate()) {
        paymentDebugService.logStep('BuscarCitaForm', 'Validation Failed', errors);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Por favor corrige los campos marcados."
        });
        return;
    }

    try {
        paymentDebugService.logStep('BuscarCitaForm', 'Submitting Payment Request');

        // 2. Prepare Data
        const fullData = {
            ...formData,
            phone: `${formData.countryCode} ${formData.phone}`
        };

        // 3. Save Context (For retrieval after redirect)
        localStorage.setItem('buscar_cita_user_data', JSON.stringify(fullData));

        // 4. Determine URLs
        const successUrl = `${window.location.origin}/buscar-cita-checkout?success=true`;

        // 5. Initiate Payment via Context
        await initiatePayment(BUSCAR_CITA_PRODUCT.price, BUSCAR_CITA_PRODUCT, fullData, successUrl);
    
    } catch (err) {
        paymentDebugService.logError('BuscarCitaForm:Submit', err);
        toast({
            variant: "destructive",
            title: "Error de Sistema",
            description: "No se pudo iniciar el pago. Por favor intenta nuevamente."
        });
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: null }));
  };

  const handleCountryChange = (code) => {
    setFormData(prev => ({ ...prev, countryCode: code }));
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Personal Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Nombre Completo</label>
            <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  disabled={isProcessing}
                  className={`w-full bg-navy-dark border rounded-xl pl-10 pr-4 py-3 text-white placeholder:text-gray-600 focus:outline-none focus:ring-1 transition-all ${errors.name ? 'border-red-500' : 'border-navy-lighter focus:border-cyan'}`}
                  placeholder="Juan Pérez"
                />
            </div>
            {errors.name && <p className="text-red-500 text-xs">{errors.name}</p>}
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">Email</label>
            <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  disabled={isProcessing}
                  className={`w-full bg-navy-dark border rounded-xl pl-10 pr-4 py-3 text-white placeholder:text-gray-600 focus:outline-none focus:ring-1 transition-all ${errors.email ? 'border-red-500' : 'border-navy-lighter focus:border-cyan'}`}
                  placeholder="juan@ejemplo.com"
                />
            </div>
            {errors.email && <p className="text-red-500 text-xs">{errors.email}</p>}
          </div>

          <div className="space-y-2 md:col-span-2">
            <label className="text-sm font-medium text-gray-300">Teléfono Móvil</label>
            <div className="flex gap-3">
                <div className="w-[120px] flex-shrink-0">
                    <CountryCodeSelect 
                        value={formData.countryCode} 
                        onChange={handleCountryChange}
                        className="h-full py-0"
                    />
                </div>
                <div className="relative flex-1">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                    <input
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleChange}
                      disabled={isProcessing}
                      className={`w-full bg-navy-dark border rounded-xl pl-10 pr-4 py-3 text-white placeholder:text-gray-600 focus:outline-none focus:ring-1 transition-all ${errors.phone ? 'border-red-500' : 'border-navy-lighter focus:border-cyan'}`}
                      placeholder="600 000 000"
                    />
                </div>
            </div>
            {errors.phone && <p className="text-red-500 text-xs">{errors.phone}</p>}
          </div>
        </div>

        {/* Service Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-300">Tipo de Trámite</label>
          <select
            name="serviceType"
            value={formData.serviceType}
            onChange={handleChange}
            disabled={isProcessing}
            className={`w-full bg-navy-dark border rounded-xl p-3 text-white focus:outline-none focus:ring-1 transition-all appearance-none cursor-pointer ${errors.serviceType ? 'border-red-500' : 'border-navy-lighter focus:border-cyan'}`}
          >
            <option value="">Selecciona un trámite...</option>
            {SERVICE_TYPES.map((service, idx) => (
              <option key={idx} value={service} className="bg-navy-dark text-white">{service}</option>
            ))}
          </select>
          {errors.serviceType && <p className="text-red-500 text-xs">{errors.serviceType}</p>}
        </div>

        {/* Error Feedback */}
        {Object.keys(errors).length > 0 && (
           <div className="p-3 bg-red-500/10 border border-red-500/50 rounded-lg flex items-center gap-2 text-red-400 text-xs">
               <AlertCircle className="w-4 h-4" />
               Por favor corrige los errores antes de continuar.
           </div>
        )}

        {/* Submit Button */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full bg-gradient-to-r from-cyan to-cyan-dark hover:from-cyan-light hover:to-cyan text-white text-lg font-bold py-4 rounded-xl shadow-lg shadow-cyan/20 transition-all transform hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center justify-center gap-3"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" /> Procesando...
              </>
            ) : (
              <>
                <CreditCard className="w-6 h-6" /> Pagar 9.99€ y Buscar Cita
              </>
            )}
          </button>
          
          <div className="mt-4 flex items-center justify-center gap-2 text-gray-500 text-xs">
            <ShieldCheck className="w-3 h-3" />
            <span>Pago seguro único de 9.99€ para iniciar la búsqueda automatizada.</span>
          </div>
        </div>

      </form>
    </div>
  );
};

export default BuscarCitaPaymentForm;