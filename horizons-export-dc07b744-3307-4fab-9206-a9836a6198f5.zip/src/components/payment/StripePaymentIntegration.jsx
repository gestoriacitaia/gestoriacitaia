import React, { useState } from 'react';
import { Check } from 'lucide-react';

const plans = [
  { id: 'basico', name: 'Plan Básico', price: '$9.99', desc: 'Consultas básicas y orientación.' },
  { id: 'visado', name: 'Plan Visado', price: '$12.99', desc: 'Asesoría específica para visados.' },
  { id: 'estandar', name: 'Plan Estándar', price: '$14.99', desc: 'Revisión de documentos simples.' },
  { id: 'pro', name: 'Plan Pro', price: '$27.99', desc: 'Trámites completos y rellenado de formularios.' }
];

const StripePaymentIntegration = ({ onPaymentSuccess }) => {
  const [selectedPlan, setSelectedPlan] = useState('estandar');
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePay = () => {
    setIsProcessing(true);
    // Simulate Stripe Checkout redirect and success
    setTimeout(() => {
      setIsProcessing(false);
      onPaymentSuccess(selectedPlan);
    }, 2000);
  };

  return (
    <div className="bg-slate-800 p-6 border border-slate-700 w-full max-w-3xl mx-auto my-8 rounded-none">
      <h2 className="text-2xl font-bold text-center text-white mb-6">Elige tu Plan de Asesoría</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {plans.map(plan => (
          <div 
            key={plan.id}
            onClick={() => setSelectedPlan(plan.id)}
            className={`p-4 border-2 cursor-pointer transition-all ${
              selectedPlan === plan.id ? 'border-cyan bg-cyan/10' : 'border-slate-700 bg-slate-900 hover:border-slate-500'
            }`}
          >
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-bold text-white">{plan.name}</h3>
              {selectedPlan === plan.id && <Check className="text-cyan w-5 h-5" />}
            </div>
            <p className="text-2xl font-bold text-cyan mb-2">{plan.price}</p>
            <p className="text-sm text-slate-400">{plan.desc}</p>
          </div>
        ))}
      </div>

      <button
        onClick={handlePay}
        disabled={isProcessing}
        className="w-full bg-cyan text-navy py-4 font-bold text-lg hover:bg-cyan-light transition-colors rounded-none"
      >
        {isProcessing ? 'Procesando pago seguro...' : 'Pagar y Continuar Consulta'}
      </button>
      <p className="text-center text-xs text-slate-500 mt-4">Pagos seguros procesados por Stripe.</p>
    </div>
  );
};

export default StripePaymentIntegration;