import React, { useState, useEffect } from 'react';
import StripePaymentIntegration from './StripePaymentIntegration';
import { Lock } from 'lucide-react';

const PaymentGateFlow = ({ children }) => {
  const [showGate, setShowGate] = useState(false);
  const [hasPaid, setHasPaid] = useState(false);

  useEffect(() => {
    // Show gate after 1 minute of chat (simulated with 5s for testing)
    const timer = setTimeout(() => {
      if (!hasPaid) setShowGate(true);
    }, 15000);
    return () => clearTimeout(timer);
  }, [hasPaid]);

  if (hasPaid) return <>{children}</>;

  if (showGate) {
    return (
      <div className="w-full animate-in fade-in">
        <div className="bg-amber-500/20 border border-amber-500/50 p-4 mb-6 flex items-center gap-3 text-amber-200">
          <Lock className="w-5 h-5 flex-shrink-0" />
          <p>Has alcanzado el límite de tiempo gratuito. Para continuar con tu trámite y descargar documentos, selecciona un plan.</p>
        </div>
        <StripePaymentIntegration onPaymentSuccess={() => {
          setHasPaid(true);
          setShowGate(false);
        }} />
      </div>
    );
  }

  return (
    <div className="relative w-full">
      {/* Visual indicator of free time */}
      <div className="absolute top-0 left-0 w-full h-1 bg-slate-800 z-50">
        <div className="h-full bg-cyan transition-all duration-[15000ms] ease-linear" style={{ width: '100%' }} />
      </div>
      {children}
    </div>
  );
};

export default PaymentGateFlow;