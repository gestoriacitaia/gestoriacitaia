import React from 'react';
import { motion } from 'framer-motion';
import { Check, Star } from 'lucide-react';
import { Button } from './ui/button';
import { useToast } from './ui/use-toast';

const PricingCard = ({ 
  planName, 
  price, 
  features, 
  highlighted = false,
  recommended = false,
  isMonthly = false
}) => {
  const { toast } = useToast();
  
  // Combine highlighted and recommended logic if needed, 
  // or use recommended to trigger the badge explicitly
  const isRecommended = highlighted || recommended;

  const handleContract = () => {
    toast({
      title: "🚧 Función en desarrollo",
      description: "La integración de pagos estará disponible pronto. ¡Solicítala en tu próximo mensaje!",
      duration: 5000,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -8, transition: { duration: 0.2 } }}
      className={`relative p-8 rounded-2xl shadow-lg transition-all duration-300 flex flex-col h-full ${
        isRecommended
          ? 'bg-gradient-to-br from-blue-600 to-purple-600 text-white border-2 border-white transform scale-105 z-10'
          : 'bg-white border border-gray-200 hover:border-blue-300'
      }`}
    >
      {isRecommended && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-gray-900 px-4 py-1.5 rounded-full text-sm font-bold shadow-md flex items-center gap-1 whitespace-nowrap">
          <Star className="w-3 h-3 fill-gray-900" />
          Recomendado
        </div>
      )}
      
      <div className="mb-6">
        <h3 className={`text-2xl font-bold mb-2 ${isRecommended ? 'text-white' : 'text-gray-900'}`}>
          {planName}
        </h3>
        <div className="flex items-baseline gap-1">
          <span className={`text-4xl font-bold ${isRecommended ? 'text-white' : 'text-blue-600'}`}>
            {price}€
          </span>
          {isMonthly && (
            <span className={`text-sm ${isRecommended ? 'text-blue-100' : 'text-gray-500'}`}>
              /mes
            </span>
          )}
        </div>
      </div>

      <ul className="space-y-3 mb-8 flex-1">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start gap-2">
            <Check className={`w-5 h-5 mt-0.5 flex-shrink-0 ${
              isRecommended ? 'text-blue-200' : 'text-green-500'
            }`} />
            <span className={`text-sm ${isRecommended ? 'text-white' : 'text-gray-600'}`}>
              {feature}
            </span>
          </li>
        ))}
      </ul>

      <Button
        onClick={handleContract}
        className={`w-full py-6 font-bold text-lg mt-auto ${
          isRecommended
            ? 'bg-white text-blue-600 hover:bg-blue-50 shadow-lg'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        }`}
      >
        Contratar
      </Button>
    </motion.div>
  );
};

export default PricingCard;