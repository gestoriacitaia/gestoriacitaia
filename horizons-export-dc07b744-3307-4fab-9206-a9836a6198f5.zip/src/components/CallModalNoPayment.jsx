import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Mic, MicOff, MessageCircle, FileText, PhoneOff, Wifi, ShieldCheck, Loader2, Download } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from './ui/use-toast';

const CallModalNoPayment = ({ isOpen, onClose, avatar }) => {
  const { language } = useLanguage();
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  
  // States for the call interface
  const [callState, setCallState] = useState('connecting'); // connecting, connected, ended
  const [isMuted, setIsMuted] = useState(false);
  const [isChatActive, setIsChatActive] = useState(false);
  const [duration, setDuration] = useState(0);
  const [connectionQuality, setConnectionQuality] = useState(3);

  // Auto-connect on mount (No forms, no waiting)
  useEffect(() => {
    if (isOpen) {
      setCallState('connecting');
      setDuration(0);
      setIsMuted(false);
      
      // Fast connection simulation
      const connectTimer = setTimeout(() => {
        setCallState('connected');
      }, 1500);

      return () => clearTimeout(connectTimer);
    }
  }, [isOpen]);

  // Call timer logic
  useEffect(() => {
    let interval;
    if (callState === 'connected') {
      interval = setInterval(() => {
        setDuration(prev => prev + 1);
        if (Math.random() > 0.9) setConnectionQuality(Math.floor(Math.random() * 2) + 2);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callState]);

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    setCallState('ended');
    setTimeout(onClose, 800);
  };

  const handleFileClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      toast({
        title: language === 'es' ? "Archivo enviado" : "File sent",
        description: file.name,
        className: "bg-slate-800 border-slate-700 text-white"
      });
    }
  };

  const toggleChat = () => {
    setIsChatActive(!isChatActive);
    toast({
      description: isChatActive 
        ? (language === 'es' ? "Chat cerrado" : "Chat closed")
        : (language === 'es' ? "Chat disponible" : "Chat available"),
      className: "bg-slate-800 border-slate-700 text-white"
    });
  };

  const buttonBaseClass = "px-6 py-4 md:px-8 md:py-4 text-base md:text-lg rounded-none font-bold text-white flex items-center justify-center gap-3 transition-all duration-200 hover:scale-105 hover:shadow-xl shadow-lg w-full sm:w-auto min-w-[160px]";

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center overflow-hidden"
      >
        <div className="relative w-full h-full md:max-w-6xl md:h-[90vh] flex flex-col bg-slate-900 shadow-2xl overflow-hidden border border-slate-800">
            
            {/* --- Header: Status & Secure Badge --- */}
            <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-slate-900/90 via-slate-900/50 to-transparent z-30 flex justify-between items-start p-6 pointer-events-none">
               <div className="flex flex-col gap-1 pointer-events-auto">
                  <div className="flex items-center gap-2">
                     <div className="flex items-center justify-center w-6 h-6 rounded-none bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                        <ShieldCheck className="w-3.5 h-3.5" />
                     </div>
                     <span className="text-emerald-400 text-[10px] md:text-xs font-bold tracking-wider uppercase">
                        {language === 'es' ? 'Encriptado E2E' : 'E2E Encrypted'}
                     </span>
                  </div>
                  <div className="flex items-center gap-2 pl-1">
                     <span className={`w-2 h-2 rounded-none ${callState === 'connected' ? 'bg-red-500 animate-pulse' : 'bg-amber-500'}`}></span>
                     <span className="text-slate-200 text-sm font-medium font-mono">
                        {callState === 'connected' ? formatDuration(duration) : (language === 'es' ? 'Conectando...' : 'Connecting...')}
                     </span>
                  </div>
               </div>

               <div className="flex items-center gap-4 pointer-events-auto">
                  {callState === 'connected' && (
                    <div className="flex items-center gap-1 bg-slate-800/60 backdrop-blur px-2 py-1 rounded-none border border-slate-700/50">
                        <Wifi className={`w-4 h-4 ${connectionQuality > 1 ? 'text-green-400' : 'text-yellow-400'}`} />
                    </div>
                  )}
                  <button 
                     onClick={handleEndCall} 
                     className="bg-slate-800/80 hover:bg-red-500/20 hover:text-red-400 text-slate-400 px-4 py-2 rounded-none backdrop-blur-md transition-all border border-transparent hover:border-red-500/30"
                  >
                     <X className="w-6 h-6" />
                  </button>
               </div>
            </div>

            {/* --- Main Video Display --- */}
            <div className="flex-1 relative bg-slate-900 flex flex-col items-center justify-center overflow-hidden">
               {/* Ambient Background */}
               <div className="absolute inset-0 bg-gradient-to-b from-slate-900 via-slate-800/50 to-slate-900"></div>
               
               {/* Avatar/Video Feed */}
               <div className="relative z-10 w-full max-w-4xl aspect-[4/3] md:aspect-video flex items-center justify-center p-4">
                  {callState === 'connecting' ? (
                     <div className="flex flex-col items-center justify-center gap-4">
                        <div className="relative">
                           <div className="w-24 h-24 rounded-none border-4 border-slate-700/50 flex items-center justify-center bg-slate-800 relative z-10">
                              <img src={avatar?.image} alt={avatar?.name} className="w-full h-full object-cover opacity-50" />
                           </div>
                           <div className="absolute inset-0 border-4 border-t-green-500 border-r-transparent border-b-transparent border-l-transparent animate-spin w-24 h-24"></div>
                        </div>
                        <p className="text-green-400 font-mono text-base tracking-widest uppercase animate-pulse">
                           {language === 'es' ? 'Estableciendo conexión...' : 'Establishing connection...'}
                        </p>
                     </div>
                  ) : (
                     <div className="relative w-full h-full rounded-none overflow-hidden shadow-2xl bg-slate-800 group border border-slate-700">
                        <img 
                           src={avatar?.image} 
                           alt={avatar?.name} 
                           className="w-full h-full object-cover transform transition-transform duration-[10s] group-hover:scale-105"
                        />
                        {/* Name Overlay */}
                        <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent">
                           <h2 className="text-white text-xl font-bold tracking-tight">{avatar?.name}</h2>
                           <p className="text-green-400 text-sm font-bold uppercase">{avatar?.specialty || (language === 'es' ? 'Especialista en Extranjería' : 'Immigration Specialist')}</p>
                        </div>
                     </div>
                  )}
               </div>
            </div>

            {/* --- Bottom Action Bar --- */}
            <div className="relative z-30 bg-slate-900/90 backdrop-blur-xl border-t border-slate-800 py-8 px-6">
               <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center gap-4 md:gap-6">
                  
                  {/* Hidden Input */}
                  <input type="file" accept=".pdf" ref={fileInputRef} className="hidden" onChange={handleFileChange} />

                  {/* Mic Toggle */}
                  <button 
                    onClick={() => setIsMuted(!isMuted)}
                    className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
                  >
                     {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
                     {isMuted ? (language === 'es' ? 'Silenciado' : 'Muted') : (language === 'es' ? 'Micrófono' : 'Mic')}
                  </button>

                  {/* Chat Button */}
                  <button 
                    onClick={toggleChat}
                    className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
                  >
                     <MessageCircle className="w-6 h-6" />
                     Chat
                  </button>

                  {/* PDF Upload */}
                  <button 
                    onClick={handleFileClick}
                    className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
                  >
                     <Download className="w-6 h-6" />
                     PDF
                  </button>

                  {/* End Call */}
                  <button 
                    onClick={handleEndCall}
                    className={`${buttonBaseClass} bg-red-600 hover:bg-red-700`}
                  >
                     <PhoneOff className="w-6 h-6" />
                     {language === 'es' ? 'Fin' : 'End'}
                  </button>

               </div>
            </div>

        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default CallModalNoPayment;