import React, { useState } from 'react';
import { motion } from 'framer-motion';
import SimpleAvatarCard from './SimpleAvatarCard';
import { useLanguage } from '../contexts/LanguageContext';
import { getAvatars } from '../services/immigrationService';

const AvatarSpecialists = ({ onOpenChat }) => {
  const { language } = useLanguage();
  const [avatars] = useState(getAvatars());

  const translations = {
    es: {
      title: 'Nuestros Especialistas',
      subtitle: 'Asistentes virtuales expertos disponibles 24/7 para ayudarte',
    },
    ar: {
      title: 'Imusnawen-nneɣ',
      subtitle: 'Imudda idigitalen imusnawen i yellan 24/7 iwakken ad k-awin',
    },
  };

  const t = translations[language] || translations.es;

  return (
    <section id="specialists" className="py-20 bg-sky-bg">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-navy mb-4">
            {t.title}
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {t.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {avatars.map((avatar) => (
             <div key={avatar.id} className="h-full">
              <SimpleAvatarCard
                name={avatar.name}
                image={avatar.image}
                specialty={avatar.specialty}
                imageStyle={avatar.imageStyle}
                onClick={() => onOpenChat(avatar)}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AvatarSpecialists;