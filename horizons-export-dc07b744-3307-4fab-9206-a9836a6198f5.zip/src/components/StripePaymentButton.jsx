import React, { useState } from 'react';
import { CreditCard, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const StripePaymentButton = ({ clienteId, onPaymentComplete }) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handlePayment = async () => {
    setLoading(true);
    try {
      // In a real scenario, we would call create-stripe-checkout here.
      // For this simplified task, we will simulate the process and save to DB.
      
      /* 
      const { data: checkoutData, error: checkoutError } = await supabase.functions.invoke('create-stripe-checkout', {
         body: { amount: 50, currency: 'usd', description: 'Consultation Fee' }
      });
      if (checkoutError) throw checkoutError;
      window.location.href = checkoutData.url; 
      */

      // SIMULATION FOR TASK 3 REQUIREMENTS (Save directly to DB)
      await new Promise(resolve => setTimeout(resolve, 1500)); // Fake network delay

      const mockPaymentId = `pay_${Math.random().toString(36).substr(2, 9)}`;
      
      const { error } = await supabase
        .from('tabla_pagos')
        .insert([{
          cliente_id: clienteId,
          monto: 50,
          moneda: 'USD',
          stripe_payment_id: mockPaymentId,
          estado: 'completed',
          fecha_pago: new Date().toISOString()
        }]);

      if (error) throw error;

      toast({
        title: "Pago Exitoso",
        description: "Tu pago de $50 ha sido procesado correctamente.",
      });

      if (onPaymentComplete) onPaymentComplete();

    } catch (error) {
      console.error('Payment Error:', error);
      toast({
        title: "Error en el pago",
        description: "No se pudo procesar el pago. Inténtalo de nuevo.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button 
      onClick={handlePayment} 
      disabled={loading}
      className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-6 rounded-xl flex items-center justify-center gap-2 shadow-lg hover:shadow-green-500/20 transition-all"
    >
      {loading ? (
        <Loader2 className="w-5 h-5 animate-spin" />
      ) : (
        <CreditCard className="w-5 h-5" />
      )}
      Pagar $50 USD
    </Button>
  );
};

export default StripePaymentButton;