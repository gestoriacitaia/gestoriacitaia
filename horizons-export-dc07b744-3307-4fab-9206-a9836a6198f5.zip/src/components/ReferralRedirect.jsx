import React, { useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';

const ReferralRedirect = () => {
  const { code } = useParams();

  useEffect(() => {
    if (code) {
      sessionStorage.setItem('referralCode', code);
    }
  }, [code]);

  return <Navigate to={`/signup?ref=${code}`} replace />;
};

export default ReferralRedirect;