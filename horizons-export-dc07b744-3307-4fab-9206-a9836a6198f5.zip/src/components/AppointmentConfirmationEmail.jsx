import React from 'react';

// This is a template component, typically rendered server-side or used to generate HTML string
// For this frontend-only context, we provide the layout structure that could be used.
const AppointmentConfirmationEmail = ({ customerName, date, time, avatarName, link }) => {
  const containerStyle = {
    fontFamily: 'Arial, sans-serif',
    maxWidth: '600px',
    margin: '0 auto',
    backgroundColor: '#ffffff',
    border: '1px solid #e2e8f0',
    borderRadius: '8px',
    overflow: 'hidden'
  };

  const headerStyle = {
    backgroundColor: '#0f172a',
    padding: '24px',
    textAlign: 'center',
    color: '#ffffff'
  };

  const bodyStyle = {
    padding: '32px',
    color: '#334155'
  };

  const buttonStyle = {
    display: 'inline-block',
    backgroundColor: '#06b6d4',
    color: '#0f172a',
    padding: '12px 24px',
    borderRadius: '6px',
    textDecoration: 'none',
    fontWeight: 'bold',
    marginTop: '24px'
  };

  return (
    <div style={containerStyle}>
      <div style={headerStyle}>
        <h1 style={{margin: 0, fontSize: '24px'}}>Booking Confirmed</h1>
      </div>
      <div style={bodyStyle}>
        <p>Hello {customerName},</p>
        <p>Your AI consultation appointment has been successfully booked.</p>
        
        <div style={{backgroundColor: '#f1f5f9', padding: '16px', borderRadius: '8px', marginTop: '16px'}}>
          <p style={{margin: '4px 0'}}><strong>Specialist:</strong> {avatarName}</p>
          <p style={{margin: '4px 0'}}><strong>Date:</strong> {date}</p>
          <p style={{margin: '4px 0'}}><strong>Time:</strong> {time}</p>
        </div>

        <p>Please be ready 5 minutes before your scheduled time.</p>
        
        <div style={{textAlign: 'center'}}>
          <a href={link} style={buttonStyle}>Join Consultation</a>
        </div>
        
        <p style={{fontSize: '12px', color: '#94a3b8', marginTop: '32px'}}>
          If you need to cancel, please contact support at least 24 hours in advance.
        </p>
      </div>
    </div>
  );
};

export default AppointmentConfirmationEmail;