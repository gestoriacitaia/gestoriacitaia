import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Check, Download, Share2, Calendar, MapPin, User, ArrowLeft } from 'lucide-react';
import { usePayment } from '../contexts/PaymentContext';

const AppointmentConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { saveAppointment } = usePayment();
  const { appointment, userData } = location.state || {};

  // If accessed directly without state, try to recover from localStorage
  const data = appointment ? { appointment, userData } : JSON.parse(localStorage.getItem('last_appointment_confirmation'));

  useEffect(() => {
    if (data) {
        // Persist for refresh
        localStorage.setItem('last_appointment_confirmation', JSON.stringify(data));
        
        // Save to backend (Make.com)
        saveAppointment({
            ...data.userData,
            appointment: data.appointment,
            confirmedAt: new Date().toISOString()
        });
    } else {
        // If no data found, go home
        navigate('/');
    }
  }, []);

  if (!data) return null;

  return (
    <div className="min-h-screen bg-navy py-12 px-4 flex items-center justify-center">
      <div className="max-w-2xl w-full bg-navy-light border border-cyan/20 rounded-3xl overflow-hidden shadow-2xl relative">
        
        {/* Success Header */}
        <div className="bg-gradient-to-br from-cyan/20 to-navy-dark p-8 text-center border-b border-cyan/10">
          <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-emerald-500/30">
            <Check className="w-10 h-10 text-white" strokeWidth={3} />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">¡Cita Confirmada!</h1>
          <p className="text-gray-300">Hemos enviado la confirmación a tu WhatsApp y Email.</p>
        </div>

        {/* Details Body */}
        <div className="p-8 space-y-8">
          
          {/* Appointment Card */}
          <div className="bg-navy-dark/50 rounded-2xl p-6 border border-navy-lighter">
            <h3 className="text-xs font-bold text-cyan uppercase tracking-wider mb-4">Detalles de la Cita</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-gray-400 mt-1" />
                    <div>
                        <p className="text-sm text-gray-500">Fecha y Hora</p>
                        <p className="text-white font-medium capitalize">{data.appointment.date}</p>
                        <p className="text-cyan font-bold">{data.appointment.time}</p>
                    </div>
                </div>

                <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-gray-400 mt-1" />
                    <div>
                        <p className="text-sm text-gray-500">Ubicación</p>
                        <p className="text-white font-medium">{data.appointment.location}</p>
                    </div>
                </div>
            </div>
          </div>

          {/* User Info */}
          <div className="flex items-center gap-4 p-4 bg-navy-dark/30 rounded-xl">
             <div className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center text-gray-300">
                <User className="w-5 h-5" />
             </div>
             <div>
                <p className="text-white font-medium">{data.userData.name}</p>
                <p className="text-sm text-gray-500">{data.userData.documentId} • {data.userData.serviceType}</p>
             </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button className="flex-1 bg-navy hover:bg-navy-darker border border-navy-lighter text-white py-3 rounded-xl flex items-center justify-center gap-2 transition-colors">
                <Download className="w-5 h-5" /> Descargar PDF
            </button>
            <button className="flex-1 bg-navy hover:bg-navy-darker border border-navy-lighter text-white py-3 rounded-xl flex items-center justify-center gap-2 transition-colors">
                <Share2 className="w-5 h-5" /> Compartir
            </button>
          </div>
          
          <button 
             onClick={() => navigate('/')}
             className="w-full text-center text-gray-500 hover:text-white text-sm mt-4 flex items-center justify-center gap-1"
          >
             <ArrowLeft className="w-4 h-4" /> Volver al inicio
          </button>

        </div>
      </div>
    </div>
  );
};

export default AppointmentConfirmation;