import React, { useState } from 'react';
import { Calendar as CalendarIcon, Clock, Check, Loader2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import CalendarWidget from '@/components/CalendarWidget'; // Reusing existing component

const SimpleCitaBooking = ({ clienteId, onClose }) => {
  const [step, setStep] = useState('date');
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Mock available times for simplicity as per Task 4 requirements
  const timeSlots = ['09:00', '09:30', '10:00', '10:30', '11:00', '14:00', '14:30', '15:00'];

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setStep('time');
  };

  const handleBooking = async () => {
    if (!selectedDate || !selectedTime) return;
    setLoading(true);

    try {
      const citaDate = new Date(selectedDate);
      const [hours, minutes] = selectedTime.split(':');
      citaDate.setHours(parseInt(hours), parseInt(minutes));

      const { error } = await supabase
        .from('tabla_citas')
        .insert([{
          cliente_id: clienteId,
          fecha_cita: citaDate.toISOString(),
          estado: 'pending',
          avatar_id: 'Miriam', // Default for simplified view
          fecha_creacion: new Date().toISOString()
        }]);

      if (error) throw error;

      toast({
        title: "Cita Reservada",
        description: `Tu cita para el ${citaDate.toLocaleDateString()} a las ${selectedTime} ha sido confirmada.`,
      });
      
      onClose();

    } catch (error) {
      console.error('Booking Error:', error);
      toast({
        title: "Error",
        description: "No se pudo reservar la cita.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-white font-bold text-lg flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-cyan" />
            Reservar Cita
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {step === 'date' && (
            <div className="flex flex-col items-center">
              <p className="text-slate-400 mb-4 text-sm">Selecciona un día para tu consulta</p>
              <CalendarWidget 
                availableDates={[
                  new Date().toISOString().split('T')[0],
                  new Date(Date.now() + 86400000).toISOString().split('T')[0],
                  new Date(Date.now() + 172800000).toISOString().split('T')[0]
                ]}
                onDateSelected={handleDateSelect}
                selectedDate={selectedDate}
              />
            </div>
          )}

          {step === 'time' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                 <button onClick={() => setStep('date')} className="text-xs text-cyan hover:underline">← Cambiar fecha</button>
                 <span className="text-slate-300 text-sm font-medium">
                   {selectedDate?.toLocaleDateString()}
                 </span>
              </div>
              <p className="text-slate-400 mb-4 text-sm">Selecciona una hora disponible</p>
              <div className="grid grid-cols-3 gap-2">
                {timeSlots.map(time => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={cn(
                      "py-2 px-3 rounded-lg text-sm font-medium border transition-all",
                      selectedTime === time
                        ? "bg-cyan border-cyan text-navy"
                        : "bg-slate-950 border-slate-800 text-slate-300 hover:border-cyan/50"
                    )}
                  >
                    {time}
                  </button>
                ))}
              </div>
              
              <Button 
                onClick={handleBooking}
                disabled={!selectedTime || loading}
                className="w-full mt-6 bg-cyan hover:bg-cyan/90 text-navy font-bold"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Check className="w-4 h-4 mr-2" />}
                Confirmar Reserva
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SimpleCitaBooking;