import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, CalendarCheck, Zap } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from './ui/use-toast';
import { Button } from './ui/button';

const VideoPresenter = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlay = () => {
    setIsPlaying(true);
    toast({
      title: "Video Playback",
      description: "Starting video presentation...",
    });
  };

  const handleSearchAppointment = () => {
    toast({
      title: t.btnSearchAppointment,
      description: "9.99€ - Initiating appointment search...",
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="flex flex-col gap-6"
      >
        <div className="relative rounded-[24px] overflow-hidden shadow-2xl bg-navy border border-white/20 aspect-video">
          <img 
            src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=1200"
            alt="AI Presenter"
            className={`w-full h-full object-cover transition-opacity duration-500 ${isPlaying ? 'opacity-40' : 'opacity-80'}`}
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-navy via-transparent to-transparent opacity-90" />
          
          <div className="absolute top-4 left-4 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full flex items-center gap-2 border border-white/20">
             <Zap className="w-4 h-4 text-sky-400" />
             <span className="text-xs font-bold text-white uppercase tracking-wider">Inteligencia Artificial</span>
          </div>

          <div className="absolute inset-0 flex items-center justify-center">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handlePlay}
              className="w-20 h-20 bg-sky-500/90 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(14,165,233,0.5)] backdrop-blur-sm group transition-all"
            >
              <Play className="w-8 h-8 text-white ml-1 fill-white group-hover:scale-110 transition-transform" />
            </motion.button>
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-navy to-transparent">
            <h2 className="text-xl md:text-2xl font-bold text-white mb-1">
              {t.videoTitle}
            </h2>
          </div>
        </div>

        {/* Single Full Width Button */}
        <Button
          onClick={handleSearchAppointment}
          className="w-full bg-sky-500 hover:bg-sky-600 text-white text-lg font-bold py-6 shadow-lg shadow-sky-500/20 flex items-center justify-center gap-3 transition-transform hover:scale-[1.02] rounded-2xl"
        >
          <CalendarCheck className="w-6 h-6" />
          <span>{t.btnSearchAppointment}</span>
          <span className="bg-white/20 text-white text-sm px-2 py-1 rounded ml-2">9.99€</span>
        </Button>
      </motion.div>
    </div>
  );
};

export default VideoPresenter;