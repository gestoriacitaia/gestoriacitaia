import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Zap } from 'lucide-react';
import { Button } from './ui/button';

const AvatarCard = ({ image, name, title, description, onChat }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      whileHover={{ scale: 1.05, y: -8 }}
      className="bg-white rounded-[20px] shadow-lg border border-sky-100 overflow-hidden transition-all duration-300 hover:shadow-2xl"
    >
      <div className="relative h-64 overflow-hidden">
        <img
          src={image || 'https://via.placeholder.com/400x300'}
          alt={`${name || 'Avatar'} - ${title || 'Especialista'}`}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy/60 to-transparent" />
        
        {/* Label Update */}
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
           <Zap className="w-3 h-3 text-purple" />
           <span className="text-xs font-bold text-navy uppercase">Inteligencia Artificial</span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-navy mb-2">{name || 'Asistente'}</h3>
        <p className="text-sky-600 font-semibold mb-3">{title || 'Especialista'}</p>
        <p className="text-gray-600 text-sm mb-6">{description || 'Asistente virtual disponible para ayudarte con tus consultas.'}</p>

        <Button
          onClick={() => onChat && onChat(name)}
          className="w-full bg-sky-500 hover:bg-sky-600 text-white flex items-center justify-center gap-2 rounded-xl"
        >
          <MessageCircle className="w-4 h-4" />
          <span>Hablar Ahora</span>
        </Button>
      </div>
    </motion.div>
  );
};

export default AvatarCard;