import React, { useRef, useState } from 'react';
import { FileText, Upload, Loader2, Check } from 'lucide-react';
import { useToast } from './ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';

const DocumentUpload = ({ onUploadComplete, className = "" }) => {
  const fileInputRef = useRef(null);
  const { toast } = useToast();
  const { language } = useLanguage();
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Basic Validation: PDF Only
    if (file.type !== 'application/pdf') {
      toast({
        variant: "destructive",
        title: language === 'es' ? "Error" : "Error",
        description: language === 'es' ? "Solo archivos PDF." : "Only PDF files allowed."
      });
      return;
    }

    setIsUploading(true);

    // Simulate Upload Delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsUploading(false);
    
    toast({
      title: language === 'es' ? "Documento subido" : "Document uploaded",
      description: file.name,
      className: "bg-blue-900 border-slate-700 text-white"
    });

    if (onUploadComplete) onUploadComplete(file);
    
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className={className}>
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        accept="application/pdf" 
        className="hidden" 
      />
      <button 
        onClick={() => fileInputRef.current?.click()}
        disabled={isUploading}
        className="group flex items-center justify-center gap-3 px-6 py-4 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-all duration-300 hover:scale-[1.02] shadow-lg w-full"
      >
        <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 group-hover:bg-blue-500/20 transition-colors">
            {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <FileText className="w-5 h-5" />}
        </div>
        <span className="font-semibold text-sm">
          {isUploading 
            ? (language === 'es' ? 'Subiendo...' : 'Uploading...') 
            : (language === 'es' ? 'Subir PDF' : 'Upload PDF')
          }
        </span>
      </button>
    </div>
  );
};

export default DocumentUpload;