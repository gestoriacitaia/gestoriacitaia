import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, CreditCard, Star, ArrowRight } from 'lucide-react';
import { useToast } from './ui/use-toast';
import GestoriaHeader from './GestoriaHeader';
import Footer from './Footer';

const ConsultationCheckoutFlow = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedAvatar, setSelectedAvatar] = useState('miriam');
  const [isProcessing, setIsProcessing] = useState(false);

  const avatars = [
    { id: 'miriam', name: 'Miriam', role: 'Documentation Specialist', desc: 'Expert in checking PDF documents and forms.' },
    { id: 'mohammad', name: 'Mohammad', role: 'Appointment Finder', desc: 'Specialized in finding available Citas.' },
    { id: 'khalid', name: 'Khalid', role: 'Residency Lawyer', desc: 'Expert in Arraigo and Residency laws.' }
  ];

  const handlePayment = async () => {
    setIsProcessing(true);
    // Simulate Stripe
    setTimeout(() => {
      setIsProcessing(false);
      toast({ title: "Payment Successful", description: "Starting your consultation..." });
      navigate('/consultation-session', { 
        state: { avatarId: selectedAvatar, clientName: 'Guest User' } 
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-navy text-white flex flex-col">
      <GestoriaHeader />
      
      <main className="flex-1 container mx-auto px-4 py-12 flex flex-col items-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">Select Your AI Specialist</h1>
        
        {/* Avatar Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl mb-12">
           {avatars.map(avatar => (
             <div 
               key={avatar.id}
               onClick={() => setSelectedAvatar(avatar.id)}
               className={`relative p-6 rounded-2xl border-2 cursor-pointer transition-all ${
                 selectedAvatar === avatar.id 
                 ? 'border-cyan bg-slate-800 shadow-xl scale-105' 
                 : 'border-slate-700 bg-slate-900 hover:border-slate-500'
               }`}
             >
               {selectedAvatar === avatar.id && (
                 <div className="absolute top-4 right-4 bg-cyan text-black p-1 rounded-full">
                   <Check className="w-4 h-4" />
                 </div>
               )}
               <div className="w-20 h-20 rounded-full bg-slate-700 mb-4 mx-auto overflow-hidden">
                  <img 
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${avatar.id}`} 
                    alt={avatar.name}
                    className="w-full h-full object-cover" 
                  />
               </div>
               <h3 className="text-xl font-bold text-center mb-1">{avatar.name}</h3>
               <p className="text-cyan text-sm text-center mb-4">{avatar.role}</p>
               <p className="text-slate-400 text-sm text-center">{avatar.desc}</p>
             </div>
           ))}
        </div>

        {/* Payment Summary */}
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl">
           <div className="flex justify-between items-center mb-6 pb-6 border-b border-slate-800">
              <span className="text-slate-300">Consultation Fee</span>
              <span className="text-2xl font-bold">9.99€</span>
           </div>
           
           <div className="space-y-4 mb-8">
             <div className="flex items-center gap-3 text-sm text-slate-300">
               <Star className="w-4 h-4 text-yellow-500" />
               <span>Real-time Video Consultation</span>
             </div>
             <div className="flex items-center gap-3 text-sm text-slate-300">
               <Star className="w-4 h-4 text-yellow-500" />
               <span>Unlimited Questions (15 min)</span>
             </div>
             <div className="flex items-center gap-3 text-sm text-slate-300">
               <Star className="w-4 h-4 text-yellow-500" />
               <span>Document Verification Included</span>
             </div>
           </div>

           <button
             onClick={handlePayment}
             disabled={isProcessing}
             className="w-full py-4 bg-cyan hover:bg-cyan/90 text-navy font-bold rounded-xl flex items-center justify-center gap-2 transition-all"
           >
             {isProcessing ? (
               <span>Processing...</span>
             ) : (
               <>
                 <CreditCard className="w-5 h-5" />
                 <span>Pay & Start Session</span>
                 <ArrowRight className="w-5 h-5 ml-1" />
               </>
             )}
           </button>
           <p className="text-center text-slate-500 text-xs mt-4">Secure payment powered by Stripe</p>
        </div>

      </main>
      <Footer />
    </div>
  );
};

export default ConsultationCheckoutFlow;