import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, FileText, AlertTriangle } from 'lucide-react';

const DocumentVerificationDisplay = ({ result, documentName, documentType }) => {
  if (!result) return null;

  const isValid = result.isValid;
  const statusColor = isValid ? 'text-green-500' : 'text-red-500';
  const bgColor = isValid ? 'bg-green-500/10' : 'bg-red-500/10';
  const borderColor = isValid ? 'border-green-500/20' : 'border-red-500/20';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-xl border ${borderColor} ${bgColor} p-4 mt-4`}
    >
      <div className="flex items-start gap-3">
        <div className={`mt-1 p-2 rounded-full bg-slate-950/50 ${borderColor} border`}>
          {isValid ? (
            <CheckCircle className={`w-6 h-6 ${statusColor}`} />
          ) : (
            <XCircle className={`w-6 h-6 ${statusColor}`} />
          )}
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h4 className={`font-bold text-sm ${statusColor}`}>
                {isValid ? 'Documento Válido' : 'Documento Inválido'}
              </h4>
              <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                <FileText className="w-3 h-3" /> {documentName}
              </p>
            </div>
            {result.confidence && (
               <span className="text-xs font-mono bg-slate-950 px-2 py-1 rounded text-slate-500 border border-slate-800">
                 {Math.round(result.confidence * 100)}% Match
               </span>
            )}
          </div>

          <p className="text-sm text-slate-300 mt-2 leading-relaxed">
            {result.summary}
          </p>

          {!isValid && result.issues && result.issues.length > 0 && (
            <div className="mt-3 bg-slate-950/50 rounded-lg p-3 border border-red-500/20">
              <h5 className="text-xs font-bold text-red-400 flex items-center gap-1 mb-2">
                <AlertTriangle className="w-3 h-3" /> Issues Detected:
              </h5>
              <ul className="space-y-1">
                {result.issues.map((issue, idx) => (
                  <li key={idx} className="text-xs text-slate-400 flex items-start gap-2">
                    <span className="text-red-500 mt-1">•</span>
                    {issue}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default DocumentVerificationDisplay;