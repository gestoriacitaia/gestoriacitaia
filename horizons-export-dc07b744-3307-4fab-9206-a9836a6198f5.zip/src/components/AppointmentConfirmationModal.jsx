import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, CheckCircle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AppointmentConfirmationModal = ({ 
  isOpen, 
  onClose, 
  onConfirm, 
  onChange, 
  details 
}) => {
  if (!isOpen || !details) return null;

  const { date, time, avatarId } = details;
  const formattedDate = date.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-md shadow-2xl relative"
        >
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-500 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-cyan/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-cyan/30">
              <Calendar className="w-8 h-8 text-cyan" />
            </div>
            <h2 className="text-xl font-bold text-white">Confirm Appointment</h2>
            <p className="text-slate-400 text-sm mt-1">Please review your booking details</p>
          </div>

          <div className="bg-slate-950 rounded-xl p-4 mb-6 space-y-3 border border-slate-800">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-slate-500 text-sm">Specialist</span>
              <span className="text-white font-medium capitalize">{avatarId}</span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-slate-500 text-sm">Date</span>
              <span className="text-white font-medium capitalize">{formattedDate}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500 text-sm">Time</span>
              <div className="flex items-center gap-1 text-cyan font-bold">
                <Clock className="w-3 h-3" />
                {time}
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={onChange}
              className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800"
            >
              Change
            </Button>
            <Button 
              onClick={onConfirm}
              className="flex-1 bg-cyan hover:bg-cyan/90 text-navy font-bold"
            >
              Confirm Booking
            </Button>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default AppointmentConfirmationModal;