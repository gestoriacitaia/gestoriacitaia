import React, { useState } from 'react';
import { FileText, Download, Loader2, X, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const DocumentDownloadSimple = ({ clienteId, onClose }) => {
  const [downloading, setDownloading] = useState(null);
  const { toast } = useToast();

  const documents = [
    { id: 'summary', name: 'Resumen de Consulta', type: 'PDF' },
    { id: 'forms', name: 'Formulario EX-15', type: 'PDF' },
    { id: 'guide', name: 'Guía de Trámites', type: 'PDF' }
  ];

  const handleDownload = async (docId, docName) => {
    setDownloading(docId);
    try {
      // Simulate fetch/generate
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Real implementation would fetch signed URL from Supabase Storage
      // const { data } = supabase.storage.from('documentos').getPublicUrl(`${clienteId}/${docId}.pdf`);
      
      toast({
        title: "Descarga Iniciada",
        description: `Descargando ${docName}...`,
      });
      
    } catch (error) {
      toast({ title: "Error", description: "No se pudo descargar el archivo.", variant: "destructive" });
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-white font-bold text-lg flex items-center gap-2">
            <Package className="w-5 h-5 text-cyan" />
            Documentos Disponibles
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-3">
          {documents.map((doc) => (
            <div key={doc.id} className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-900 rounded-lg text-cyan">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">{doc.name}</p>
                  <p className="text-xs text-slate-500">{doc.type} • 2.4 MB</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleDownload(doc.id, doc.name)}
                disabled={downloading === doc.id}
                className="text-cyan hover:text-cyan/80 hover:bg-cyan/10"
              >
                {downloading === doc.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              </Button>
            </div>
          ))}

          <Button onClick={onClose} className="w-full mt-4 bg-slate-800 hover:bg-slate-700 text-white">
            Cerrar
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DocumentDownloadSimple;