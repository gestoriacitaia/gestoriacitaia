import React, { useState, useRef } from 'react';
import { Upload, FileText, Check, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

const DocumentUploadWidget = ({ onDocumentUploaded, isVerifying }) => {
  const [selectedType, setSelectedType] = useState('dni');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef(null);

  const documentTypes = [
    { value: 'dni', label: 'Cédula / DNI' },
    { value: 'passport', label: 'Pasaporte' },
    { value: 'residency', label: 'Comprobante de domicilio' },
    { value: 'medical', label: 'Documentos médicos' },
    { value: 'other', label: 'Otros' },
  ];

  const handleFileSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== 'application/pdf' && !file.type.startsWith('image/')) {
      alert('Please upload a PDF or Image file.');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    try {
      // Call parent handler (which does the actual upload/verify logic)
      await onDocumentUploaded(file, selectedType);
      setUploadProgress(100);
    } catch (error) {
      console.error("Upload error:", error);
      alert("Failed to upload document.");
    } finally {
      setIsUploading(false);
      clearInterval(interval);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 w-full">
      <div className="mb-4">
        <label className="block text-sm font-medium text-slate-400 mb-2">
          Tipo de Documento
        </label>
        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-cyan"
          disabled={isUploading || isVerifying}
        >
          {documentTypes.map((type) => (
            <option key={type.value} value={type.value}>
              {type.label}
            </option>
          ))}
        </select>
      </div>

      <div className="relative">
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileSelect}
          className="hidden"
          accept=".pdf,image/*"
        />
        
        {isUploading || isVerifying ? (
          <div className="flex flex-col items-center justify-center py-4 border-2 border-dashed border-slate-700 rounded-lg bg-slate-950/50">
            <Loader2 className="w-8 h-8 text-cyan animate-spin mb-2" />
            <p className="text-xs text-cyan font-mono">
              {isUploading ? 'UPLOADING...' : 'ANALYZING...'}
            </p>
            {isUploading && (
              <Progress value={uploadProgress} className="w-3/4 mt-2 h-1 bg-slate-800" />
            )}
          </div>
        ) : (
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-6 border-2 border-dashed border-slate-700 hover:border-cyan hover:bg-cyan/5 rounded-lg flex flex-col items-center justify-center transition-all group"
          >
            <Upload className="w-8 h-8 text-slate-500 group-hover:text-cyan mb-2" />
            <span className="text-sm text-slate-400 group-hover:text-white">
              Click to Upload PDF
            </span>
            <span className="text-xs text-slate-600 mt-1">
              Max 10MB
            </span>
          </button>
        )}
      </div>
    </div>
  );
};

export default DocumentUploadWidget;