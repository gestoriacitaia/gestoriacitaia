import React from 'react';
import { motion } from 'framer-motion';
import { FileText, MessageCircle, Calendar } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from './ui/use-toast';

const ActionButtons = () => {
  const { language } = useLanguage();
  const { toast } = useToast();

  const actions = [
    {
      icon: FileText,
      label: language === 'es' ? "Verificar PDF" : "Taqyiq PDF",
      price: null,
      color: "text-blue-600"
    },
    {
      icon: MessageCircle,
      label: language === 'es' ? "Consultas" : "Tiwizi",
      price: null,
      color: "text-purple-600"
    },
    {
      icon: Calendar,
      label: language === 'es' ? "Cita Previa" : "Awwalen",
      price: "9.99€",
      color: "text-[#20c997]"
    }
  ];

  const handleAction = (label) => {
    toast({
      title: "🚧 " + (language === 'es' ? "En desarrollo" : "Mazal"),
      description: `${label} - ` + (language === 'es' ? "Esta función estará lista pronto." : "Tazzart-a ad tili taqrib."),
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {actions.map((action, index) => (
          <motion.button
            key={index}
            whileHover={{ y: -5, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleAction(action.label)}
            className="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-lg hover:shadow-[#20c997]/20 transition-all duration-300 group"
          >
            <div className={`p-4 rounded-full bg-gray-50 mb-3 group-hover:bg-gray-100 transition-colors ${action.color}`}>
              <action.icon className="w-8 h-8" />
            </div>
            <span className="text-gray-900 font-bold text-lg mb-1">{action.label}</span>
            {action.price && (
              <span className="text-[#20c997] font-bold text-sm bg-[#20c997]/10 px-2 py-1 rounded-full">
                {action.price}
              </span>
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
};

export default ActionButtons;