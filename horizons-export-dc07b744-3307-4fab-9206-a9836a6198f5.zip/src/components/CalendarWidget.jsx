import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

const CalendarWidget = ({ availableDates = [], onDateSelected, selectedDate }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const days = new Date(year, month + 1, 0).getDate();
    return Array.from({ length: days }, (_, i) => new Date(year, month, i + 1));
  };

  const days = getDaysInMonth(currentMonth);
  const firstDayOfMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1).getDay();
  // Adjust for Monday start (0=Sun -> 0=Mon conversion if needed, but standard US/ISO differs. Let's stick to Sun=0)
  
  const formatDateKey = (date) => date.toISOString().split('T')[0];

  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 w-full max-w-sm">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <button onClick={handlePrevMonth} className="p-2 hover:bg-slate-800 rounded-full text-slate-400">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <h3 className="text-white font-bold text-lg capitalize">
          {currentMonth.toLocaleString('es-ES', { month: 'long', year: 'numeric' })}
        </h3>
        <button onClick={handleNextMonth} className="p-2 hover:bg-slate-800 rounded-full text-slate-400">
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Weekdays */}
      <div className="grid grid-cols-7 gap-1 mb-2 text-center">
        {['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa'].map(d => (
          <span key={d} className="text-xs text-slate-500 font-medium">{d}</span>
        ))}
      </div>

      {/* Days */}
      <div className="grid grid-cols-7 gap-1">
        {Array(firstDayOfMonth).fill(null).map((_, i) => (
          <div key={`empty-${i}`} className="h-10" />
        ))}
        
        {days.map((date) => {
          const dateKey = formatDateKey(date);
          const isAvailable = availableDates.includes(dateKey);
          const isSelected = selectedDate && formatDateKey(selectedDate) === dateKey;
          const isPast = date < new Date().setHours(0,0,0,0);

          return (
            <motion.button
              key={dateKey}
              whileHover={isAvailable && !isSelected ? { scale: 1.1 } : {}}
              whileTap={isAvailable && !isSelected ? { scale: 0.95 } : {}}
              onClick={() => isAvailable && onDateSelected(date)}
              disabled={!isAvailable || isPast}
              className={cn(
                "h-10 w-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors relative",
                isSelected ? "bg-cyan text-navy font-bold shadow-lg shadow-cyan/20" : 
                isAvailable ? "bg-slate-800 text-white hover:bg-slate-700 hover:border hover:border-cyan" : 
                "text-slate-600 cursor-not-allowed"
              )}
            >
              {date.getDate()}
              {isAvailable && !isSelected && (
                <span className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-green-500 rounded-full" />
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};

export default CalendarWidget;