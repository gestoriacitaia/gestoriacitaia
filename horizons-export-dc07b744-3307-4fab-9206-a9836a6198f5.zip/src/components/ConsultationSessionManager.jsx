import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import RealTimeConsultationSession from './RealTimeConsultationSession';
import { realTimeAudioProcessor } from '@/services/RealTimeAudioProcessor';
import { avatarResponseEngine } from '@/services/AvatarResponseEngine';
import { elevenLabsVoiceSynthesis } from '@/services/ElevenLabsVoiceSynthesis';
import { didVideoService } from '@/services/DIDVideoService';
import { consultationSessionStorage } from '@/services/ConsultationSessionStorage';
import { didSessionManager } from '@/services/DIDSessionManager';
import { consultationSessionRecorder } from '@/services/ConsultationSessionRecorder';
import { useDocumentVerification } from '@/hooks/useDocumentVerification';
import { useAppointmentBooking } from '@/hooks/useAppointmentBooking';
import DocumentUploadWidget from './DocumentUploadWidget';
import DocumentVerificationDisplay from './DocumentVerificationDisplay';
import CalendarWidget from './CalendarWidget';
import AppointmentTimeSelector from './AppointmentTimeSelector';
import AppointmentConfirmationModal from './AppointmentConfirmationModal';
import ConsultationEndingFlow from './ConsultationEndingFlow';
import { Mic, MicOff, MessageSquare, Clock, FileCheck, CalendarPlus } from 'lucide-react';
import { useToast } from './ui/use-toast';

const ConsultationSessionManager = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { citaId } = useParams();
  const { toast } = useToast();
  
  const { avatarId = 'miriam', clientName = 'Client' } = location.state || {};
  
  const [interactionStatus, setInteractionStatus] = useState('idle');
  const [transcript, setTranscript] = useState([]);
  const [sessionDuration, setSessionDuration] = useState(0);
  const [currentUser, setCurrentUser] = useState(null);
  const [showBookingFlow, setShowBookingFlow] = useState(false);
  const [isSessionEnding, setIsSessionEnding] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setCurrentUser(data.user);
      if (data.user) {
        consultationSessionRecorder.init(data.user.id, citaId, avatarId);
      }
    });
  }, [citaId, avatarId]);

  const { 
    uploadDocument, 
    isVerifying, 
    verificationResult, 
    lastUploadedDoc 
  } = useDocumentVerification(currentUser?.id, citaId);

  const {
    step,
    setStep,
    selectedDate,
    selectedTime,
    availableDates,
    getSlotsForDate,
    searchAvailableSlots,
    selectDate,
    selectTime,
    confirmAppointment,
    resetFlow
  } = useAppointmentBooking(currentUser?.id, avatarId);

  useEffect(() => {
    if (showBookingFlow) searchAvailableSlots(new Date());
  }, [showBookingFlow, searchAvailableSlots]);

  useEffect(() => {
    const timer = setInterval(() => setSessionDuration(d => d + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const speakText = async (text) => {
    setInteractionStatus('speaking');
    try {
      if (didSessionManager.sessionId) {
        await supabase.functions.invoke('send-avatar-message', {
          body: {
            sessionId: didSessionManager.sessionId,
            streamId: didSessionManager.streamId,
            text: text,
            avatarId
          }
        });
        setTimeout(() => setInteractionStatus('idle'), text.length * 80);
      } else {
         const { audioBlob } = await elevenLabsVoiceSynthesis.synthesizeSpeech(text, avatarId);
         const audioUrl = URL.createObjectURL(audioBlob);
         const audio = new Audio(audioUrl);
         await audio.play();
         audio.onended = () => setInteractionStatus('idle');
      }

      setTranscript(prev => [...prev, { role: 'ai', text, timestamp: new Date().toISOString() }]);
      consultationSessionRecorder.addInteraction("", text);
    } catch (error) {
      console.error("Speech Error:", error);
      setInteractionStatus('idle');
    }
  };

  const handleBookingTrigger = async () => {
    setShowBookingFlow(true);
    await speakText("Por supuesto. Aquí tienes mi calendario.");
  };

  const handleAppointmentConfirm = async () => {
    const result = await confirmAppointment();
    if (result) {
      setShowBookingFlow(false);
      await speakText(`Excelente. Tu cita ha sido confirmada.`);
    }
  };

  const handleDocumentUpload = async (file, type) => {
    await speakText("Analizando documento...");
    const result = await uploadDocument(file, type);
    if (result && result.verification?.isValid) {
      await speakText("Documento válido.");
    } else {
      await speakText("Detecté problemas con el documento.");
    }
  };

  const startListening = async () => {
    setInteractionStatus('listening');
    await realTimeAudioProcessor.startListening();
  };

  const stopListening = async () => {
    setInteractionStatus('processing');
    try {
      const { text } = await realTimeAudioProcessor.stopListeningAndTranscribe();
      if (!text) {
        setInteractionStatus('idle');
        return;
      }
      
      setTranscript(prev => [...prev, { role: 'user', text, timestamp: new Date().toISOString() }]);
      consultationSessionRecorder.addInteraction(text, "");

      if (text.toLowerCase().includes('cita')) {
        await handleBookingTrigger();
      } else if (text.toLowerCase().includes('terminar') || text.toLowerCase().includes('adios')) {
         handleEndSession();
      } else {
        const response = await avatarResponseEngine.generateResponse(text, avatarId, transcript);
        await speakText(response.text);
      }
    } catch (error) {
      console.error("Pipeline Error:", error);
      setInteractionStatus('idle');
    }
  };

  const handleEndSession = async () => {
    setIsSessionEnding(true);
    await consultationSessionStorage.saveSession({
      clientId: currentUser?.id || 'guest',
      avatarId,
      startTime: new Date(Date.now() - sessionDuration * 1000).toISOString(),
      duration: sessionDuration,
      status: 'completed'
    });
    await consultationSessionRecorder.finalize();
    // Do NOT navigate yet; show ending flow
  };

  const handleClose = () => {
    navigate('/');
  };

  return (
    <div className="h-screen w-full bg-slate-950 flex flex-col md:flex-row overflow-hidden relative">
      
      {/* Ending Flow Overlay */}
      {isSessionEnding && (
        <ConsultationEndingFlow 
          isActive={isSessionEnding}
          citaId={citaId}
          clienteId={currentUser?.id}
          avatarId={avatarId}
          conversationHistory={transcript}
          onClose={handleClose}
        />
      )}

      {/* Left: Avatar Video */}
      <div className="w-full md:w-2/3 h-1/2 md:h-full relative p-4 flex flex-col">
        <div className="flex-1 relative rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-black">
          <RealTimeConsultationSession 
            avatarId={avatarId} 
            onEndSession={handleEndSession}
            isSpeaking={interactionStatus === 'speaking'}
          />
          
          {showBookingFlow && (
            <div className="absolute top-4 right-4 z-40 w-80">
               {step === 'calendar' && <CalendarWidget availableDates={availableDates} onDateSelected={selectDate} selectedDate={selectedDate} />}
               {step === 'time' && <AppointmentTimeSelector selectedDate={selectedDate} availableSlots={getSlotsForDate(selectedDate)} onTimeSelected={selectTime} onBack={() => setStep('calendar')} selectedTime={selectedTime} />}
               {step === 'confirm' && <AppointmentConfirmationModal isOpen={true} onConfirm={handleAppointmentConfirm} onChange={() => setStep('calendar')} onClose={() => setShowBookingFlow(false)} details={{ date: selectedDate, time: selectedTime, avatarId }} />}
            </div>
          )}

          <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-30 flex flex-col items-center gap-2">
             <div className="text-white/60 text-xs font-mono bg-black/40 px-3 py-1 rounded-full backdrop-blur-sm">
                {interactionStatus === 'listening' ? 'LISTENING...' : interactionStatus === 'processing' ? 'THINKING...' : interactionStatus === 'speaking' ? 'SPEAKING' : 'READY'}
             </div>
             <button
               onMouseDown={startListening}
               onMouseUp={stopListening}
               className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                 interactionStatus === 'listening' ? 'bg-red-500 scale-110 shadow-lg' : 'bg-cyan hover:bg-cyan/80 shadow-lg'
               }`}
             >
               <Mic className="w-8 h-8 text-white" />
             </button>
          </div>
        </div>
        <div className="mt-4 hidden md:flex gap-4">
           <button onClick={() => setShowBookingFlow(!showBookingFlow)} className="flex items-center gap-2 bg-slate-800 text-white px-4 py-3 rounded-xl hover:bg-slate-700 transition-colors">
             <CalendarPlus className="w-5 h-5 text-cyan" />
             <span className="text-sm font-bold">Book Appointment</span>
           </button>
           <div className="flex-1">
             <DocumentUploadWidget onDocumentUploaded={handleDocumentUpload} isVerifying={isVerifying} />
           </div>
        </div>
      </div>

      {/* Right: Transcript */}
      <div className="w-full md:w-1/3 h-1/2 md:h-full bg-slate-900 border-l border-slate-800 flex flex-col">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-950">
          <div><h2 className="text-white font-bold text-lg capitalize">{avatarId} AI</h2></div>
          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1 rounded-lg">
            <Clock className="w-4 h-4 text-cyan" />
            <span className="text-cyan font-mono text-sm">{Math.floor(sessionDuration / 60)}:{(sessionDuration % 60).toString().padStart(2, '0')}</span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {transcript.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
               <div className={`max-w-[85%] p-3 rounded-xl text-sm ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-200'}`}>{msg.text}</div>
            </div>
          ))}
          {verificationResult && lastUploadedDoc && <div className="flex justify-start w-full"><div className="max-w-[95%]"><DocumentVerificationDisplay result={verificationResult} documentName={lastUploadedDoc.name} documentType={lastUploadedDoc.type} /></div></div>}
        </div>
      </div>
    </div>
  );
};

export default ConsultationSessionManager;