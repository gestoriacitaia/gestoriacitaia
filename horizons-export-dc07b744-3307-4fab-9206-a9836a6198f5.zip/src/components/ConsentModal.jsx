import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useConsent } from '@/contexts/ConsentContext';
import { useNavigate } from 'react-router-dom';

const ConsentModal = () => {
  const { showModal, acceptConsent, rejectConsent } = useConsent();
  const navigate = useNavigate();

  if (!showModal) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-0 left-0 right-0 z-50 p-4 md:p-6"
      >
        <div className="max-w-5xl mx-auto bg-slate-900/95 backdrop-blur-md border border-slate-700 rounded-2xl shadow-2xl p-6 flex flex-col md:flex-row items-center gap-6">
          <div className="flex items-start gap-4 flex-1">
            <div className="bg-cyan/10 p-3 rounded-xl hidden md:block">
              <ShieldCheck className="w-8 h-8 text-cyan" />
            </div>
            <div className="space-y-2">
              <h3 className="text-lg font-bold text-white">Tu privacidad es importante</h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                Al continuar aceptas nuestra <button onClick={() => navigate('/politica-privacidad')} className="text-cyan hover:underline">Política de Privacidad</button> y el uso de cookies conforme al RGPD y la Ley Orgánica 3/2018 de Protección de Datos. Solo usaremos tus datos para: guiar trámites, generar formularios y enviarte alertas de citas.
              </p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 min-w-fit">
            <Button 
              variant="outline" 
              onClick={rejectConsent}
              className="border-slate-600 text-slate-300 hover:bg-slate-800"
            >
              Rechazar
            </Button>
            <Button 
              onClick={acceptConsent}
              className="bg-cyan hover:bg-cyan/90 text-navy font-bold px-8"
            >
              Aceptar y Continuar
            </Button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ConsentModal;