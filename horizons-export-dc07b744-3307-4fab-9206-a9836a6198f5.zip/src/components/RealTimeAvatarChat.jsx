import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mic, PhoneOff, Globe, Loader2, MessageSquare, Video } from 'lucide-react';
import { realTimeAudioProcessor } from '@/services/RealTimeAudioProcessor';
import { didVideoService } from '@/services/DIDVideoService';
import { didSessionManager } from '@/services/DIDSessionManager';
import AnimatedAvatarPlayer from '@/components/AnimatedAvatarPlayer';
import { useNavigate } from 'react-router-dom';

const RealTimeAvatarChat = () => {
  const navigate = useNavigate();
  const [appStatus, setAppStatus] = useState('connecting'); // connecting, idle, listening, processing, speaking, error
  const [transcript, setTranscript] = useState([]);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);

  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [transcript]);

  const handleStartListening = async () => {
    try {
      await realTimeAudioProcessor.startListening();
      setAppStatus('listening');
    } catch (err) {
      console.error("Mic Error:", err);
      setError("Cannot access microphone.");
    }
  };

  const handleStopListening = async () => {
    setAppStatus('processing');
    try {
      const result = await realTimeAudioProcessor.stopListeningAndProcess();
      
      if (!result) {
        setAppStatus('idle');
        return;
      }

      const { userText, aiText, audioBlob } = result;

      // Update UI
      setTranscript(prev => [...prev, 
        { role: 'user', text: userText }, 
        { role: 'ai', text: aiText }
      ]);

      setAppStatus('speaking');

      // Play Audio Locally 
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      
      await audio.play();

      audio.onended = () => {
        setAppStatus('idle');
      };

    } catch (err) {
      console.error("Processing Error:", err);
      setError("Error processing conversation.");
      setAppStatus('idle');
    }
  };

  const handleEndCall = async () => {
    await didSessionManager.closeSession(didVideoService);
    navigate('/');
  };

  const buttonBaseClass = "px-6 py-4 sm:px-8 sm:py-4 text-base sm:text-lg rounded-none font-bold text-white flex items-center justify-center gap-3 transition-all duration-200 hover:scale-105 hover:shadow-xl shadow-lg w-full sm:w-auto min-w-[160px]";

  return (
    <div className="h-screen w-full bg-slate-950 flex flex-col relative overflow-hidden">
      
      {/* Background Video Layer */}
      <div className="absolute inset-0 z-0">
        <AnimatedAvatarPlayer 
          onSessionReady={() => setAppStatus('idle')}
          onError={(err) => setAppStatus('error')}
        />
      </div>

      {/* UI Overlay */}
      <div className="relative z-10 flex-1 flex flex-col justify-between p-4 md:p-8 pointer-events-none">
        
        {/* Header */}
        <div className="flex justify-between items-start pointer-events-auto">
           <div className="bg-black/60 backdrop-blur-md p-4 rounded-none border border-white/10 flex items-center gap-3">
              <div className={`w-3 h-3 rounded-none ${appStatus === 'error' ? 'bg-red-500' : 'bg-green-500'}`}></div>
              <div>
                <h2 className="text-white font-bold text-lg">Miriam AI</h2>
                <p className="text-green-400 font-bold text-sm uppercase">Immigration Attorney</p>
              </div>
           </div>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="absolute top-24 left-0 right-0 flex justify-center pointer-events-auto">
             <div className="bg-red-500/90 text-white px-8 py-4 rounded-none shadow-xl text-base font-bold">
                {error}
             </div>
          </div>
        )}

        {/* Chat History */}
        <div className="flex-1 overflow-y-auto my-4 px-2 space-y-4 max-h-[45vh] mask-image-linear-gradient pointer-events-auto">
           {transcript.map((msg, i) => (
             <motion.div 
               key={i}
               initial={{ opacity: 0, y: 10 }}
               animate={{ opacity: 1, y: 0 }}
               className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
             >
               <div className={`max-w-[85%] p-4 rounded-none text-base font-medium shadow-lg ${
                 msg.role === 'user' 
                 ? 'bg-blue-600/90 text-white border border-blue-500' 
                 : 'bg-black/80 text-gray-100 backdrop-blur-md border border-white/20'
               }`}>
                 {msg.text}
               </div>
             </motion.div>
           ))}
           <div ref={messagesEndRef} />
        </div>

        {/* Action Bar */}
        <div className="w-full pointer-events-auto absolute bottom-0 left-0 right-0 p-4 sm:p-8 bg-gradient-to-t from-black/90 to-transparent">
           <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center gap-4 sm:gap-6">
              
              <button 
                onMouseDown={handleStartListening}
                onMouseUp={handleStopListening}
                onTouchStart={handleStartListening}
                onTouchEnd={handleStopListening}
                disabled={appStatus === 'connecting' || appStatus === 'error'}
                className={`${buttonBaseClass} ${
                  appStatus === 'listening' 
                  ? 'bg-red-500 hover:bg-red-600' 
                  : appStatus === 'processing'
                  ? 'bg-indigo-500 hover:bg-indigo-600'
                  : 'bg-green-500 hover:bg-green-600'
                } disabled:opacity-50 disabled:grayscale`}
              >
                {appStatus === 'processing' ? <Loader2 className="w-6 h-6 animate-spin" /> : <Mic className="w-6 h-6" />}
                {appStatus === 'connecting' ? 'Connecting...' 
                 : appStatus === 'listening' ? 'Listening...' 
                 : appStatus === 'processing' ? 'Thinking...' 
                 : appStatus === 'speaking' ? 'Speaking...' 
                 : 'Hold to Speak'}
              </button>

              <button 
                onClick={() => {}}
                className={`${buttonBaseClass} bg-green-500 hover:bg-green-600`}
              >
                <Video className="w-6 h-6" />
                Camera
              </button>

              <button 
                onClick={handleEndCall}
                className={`${buttonBaseClass} bg-red-600 hover:bg-red-700`}
              >
                <PhoneOff className="w-6 h-6" />
                End Call
              </button>

           </div>
        </div>

      </div>
    </div>
  );
};

export default RealTimeAvatarChat;