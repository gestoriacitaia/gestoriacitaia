import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';

const Services = () => {
  const { t, language } = useLanguage();

  const servicesList = [
    "Arraigo Social", "Arraigo por Formación", "Arraigo Laboral",
    "Visado de Estudiante", "Visado de Trabajo",
    "Residencia Temporal", "Residencia Permanente",
    "Nacionalidad Española",
    "Renovación de NIE", "Renovación de Pasaporte",
    "Empadronamiento", "Solicitud de Asilo",
    "Reagrupación Familiar", "Autorización de Residencia"
  ];
  
  return (
    <section id="services" className="py-12 bg-navy-dark border-t border-navy-light">
      <div className="container mx-auto px-4">
        <h2 className="text-lg font-bold text-gray-400 mb-8 text-center uppercase tracking-widest">{t.servicesTitle}</h2>
        
        <div className="flex flex-wrap justify-center gap-3 max-w-5xl mx-auto" dir={language === 'ar' ? 'rtl' : 'ltr'}>
          {servicesList.map((service, index) => (
            <span 
              key={index}
              className="text-xs md:text-sm font-medium text-gray-300 bg-navy-light border border-navy-lighter px-4 py-2 rounded-lg hover:border-cyan hover:text-cyan transition-colors cursor-default"
            >
              {service}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;