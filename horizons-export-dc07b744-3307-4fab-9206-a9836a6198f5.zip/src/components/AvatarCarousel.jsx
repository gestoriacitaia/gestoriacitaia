import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { getAvatars } from '../services/immigrationService';

const AvatarCarousel = ({ onAvatarClick }) => {
  const scrollRef = useRef(null);
  const [avatars] = useState(getAvatars());

  return (
    <div className="w-full py-8">
      <div 
        className="flex flex-wrap md:flex-nowrap justify-center gap-4 px-4 overflow-x-auto"
        ref={scrollRef}
      >
        {avatars.map((avatar) => (
          <motion.div
            key={avatar.id}
            whileHover={{ y: -5 }}
            className="flex flex-col w-full md:w-1/3 max-w-sm bg-white rounded-[20px] overflow-hidden shadow-lg border border-sky-100"
          >
            {/* Square Image Container */}
            <div className="relative aspect-square w-full overflow-hidden">
              <img
                src={avatar.image}
                alt={avatar.name}
                className="w-full h-full object-cover"
                style={avatar.imageStyle}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/40 via-transparent to-transparent opacity-60 pointer-events-none" />
              <div className="absolute top-4 right-4 w-4 h-4 rounded-full border-2 border-white shadow-lg bg-lime" />
            </div>
            
            <div className="p-4 flex flex-col gap-2">
              <div>
                <h3 className="text-navy font-bold text-lg">{avatar.name}</h3>
                <p className="text-sky-500 text-sm font-medium">{avatar.specialty}</p>
              </div>
              
              <Button 
                onClick={() => onAvatarClick(avatar)}
                className="w-full mt-2 bg-sky-500 hover:bg-sky-600 text-white font-bold flex items-center justify-center gap-2 rounded-xl"
              >
                <MessageCircle className="w-4 h-4" />
                Hablar Ahora
              </Button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AvatarCarousel;