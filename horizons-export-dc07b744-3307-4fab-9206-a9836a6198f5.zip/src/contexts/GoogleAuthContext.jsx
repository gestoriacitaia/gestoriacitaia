import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useReferralSystem } from '@/hooks/useReferralSystem';

const GoogleAuthContext = createContext(null);

export const GoogleAuthProvider = ({ children }) => {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [clientData, setClientData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { trackReferral, checkAndAwardReward } = useReferralSystem();

  useEffect(() => {
    const fetchUserAndProfile = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        setUser(session?.user ?? null);
        
        if (session?.user) {
          await loadClientProfile(session.user.id);
        } else {
            setClientData(null);
        }
      } catch (error) {
        console.error('Auth check error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserAndProfile();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          await loadClientProfile(session.user.id);
        } else {
          setClientData(null);
        }
        setLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const loadClientProfile = async (userId) => {
    try {
      const { data, error } = await supabase
        .from('tabla_clientes')
        .select('*')
        .eq('id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching client profile:', error);
      } else if (data) {
        setClientData(data);
        
        // Check rewards silently if profile loaded
        checkAndAwardReward(userId);
      }
    } catch (err) {
      console.error('Failed to load profile:', err);
    }
  };

  const createOrUpdateProfile = async (userData) => {
      try {
          const { data: existing } = await supabase
            .from('tabla_clientes')
            .select('id')
            .eq('id', userData.id)
            .single();

          if (!existing) {
              const { error } = await supabase.from('tabla_clientes').insert({
                  id: userData.id,
                  email: userData.email,
                  nombre: userData.user_metadata?.full_name || userData.email?.split('@')[0],
                  fecha_registro: new Date().toISOString()
              });
              if(error) console.error("Error creating profile", error);
              
              // Process referral if exists in session storage
              const refCode = sessionStorage.getItem('referralCode');
              if (refCode) {
                await trackReferral(refCode, userData.id);
                sessionStorage.removeItem('referralCode');
              }

              await loadClientProfile(userData.id);
          }
      } catch (err) {
          console.error("Profile sync error", err);
      }
  };

  const signInWithGoogle = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/profile`
        }
      });
      if (error) throw error;
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error al iniciar sesión",
        description: error.message
      });
    }
  };

  const signUpWithGoogle = async (refCode = null) => {
    try {
      if (refCode) {
        sessionStorage.setItem('referralCode', refCode);
      }
      
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/profile?new=true`
        }
      });
      if (error) throw error;
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error al registrarse",
        description: error.message
      });
    }
  };

  const logOut = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setClientData(null);
      window.location.href = '/';
    } catch (error) {
       console.error("Logout error", error);
    }
  };

  return (
    <GoogleAuthContext.Provider value={{
      user,
      clientData,
      loading,
      signInWithGoogle,
      signUpWithGoogle,
      logOut,
      createOrUpdateProfile,
      loadClientProfile
    }}>
      {children}
    </GoogleAuthContext.Provider>
  );
};

export const useGoogleAuth = () => {
  const context = useContext(GoogleAuthContext);
  if (!context) {
    throw new Error('useGoogleAuth must be used within GoogleAuthProvider');
  }
  return context;
};