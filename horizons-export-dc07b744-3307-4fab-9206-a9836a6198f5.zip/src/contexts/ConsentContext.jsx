import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';

const ConsentContext = createContext();

export const ConsentProvider = ({ children }) => {
  const [consentGiven, setConsentGiven] = useState(false);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    // Check local storage on mount
    const storedConsent = localStorage.getItem('gestoria_consent');
    if (storedConsent === 'true') {
      setConsentGiven(true);
      setShowModal(false);
    } else if (storedConsent === 'false') {
      setConsentGiven(false);
      setShowModal(false); // They rejected, but we don't nag them immediately again
    } else {
      setShowModal(true);
    }
  }, []);

  const saveConsentToSupabase = async (status) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const consentData = {
        consent_accepted: status,
        consent_date: new Date().toISOString(),
        consent_type: 'GDPR_COOKIES_INITIAL',
        user_agent: navigator.userAgent,
        user_id: session?.user?.id || null // Nullable if not logged in
      };

      await supabase.from('tabla_consentimientos').insert([consentData]);
    } catch (error) {
      console.error('Error saving consent:', error);
    }
  };

  const acceptConsent = () => {
    localStorage.setItem('gestoria_consent', 'true');
    setConsentGiven(true);
    setShowModal(false);
    saveConsentToSupabase(true);
  };

  const rejectConsent = () => {
    localStorage.setItem('gestoria_consent', 'false');
    setConsentGiven(false);
    setShowModal(false);
    saveConsentToSupabase(false);
  };

  return (
    <ConsentContext.Provider value={{ consentGiven, showModal, acceptConsent, rejectConsent }}>
      {children}
    </ConsentContext.Provider>
  );
};

export const useConsent = () => {
  const context = useContext(ConsentContext);
  if (!context) {
    throw new Error('useConsent must be used within a ConsentProvider');
  }
  return context;
};