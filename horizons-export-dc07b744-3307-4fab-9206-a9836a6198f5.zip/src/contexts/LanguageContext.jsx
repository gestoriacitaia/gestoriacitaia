import React, { createContext, useContext, useState, useEffect } from 'react';

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('ar');

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const translations = {
    es: {
      siteName: 'gestoriacitaia',
      
      // Header
      navHome: 'Inicio',
      navServices: 'Servicios',
      navContact: 'Contacto',
      navPrivacy: 'Privacidad',
      btnBook: 'Buscar Cita',
      
      // Avatars
      avatarSarahName: "Sarah",
      avatarIvanName: "Iván",
      avatarLaetitiaName: "Laetitia",
      btnSpeak: 'Hablar Ahora',
      
      // Video
      videoTitle: 'Video de Presentación - Conce Gestória IA',
      btnSearchAppointment: 'Buscar Cita 9.99€',
      
      // Pricing
      planBasicTitle: 'Básico',
      planBasicPrice: '9.99€',
      planBasicBenefits: ['15 min Consulta', 'Dudas Extranjería', 'Chat IA'],
      
      planStandardTitle: 'Estándar',
      planStandardPrice: '19.99€',
      planStandardBenefits: ['Verificación Docs', 'Revisión NIE/Pasaporte', '3 Consultas/mes'],
      
      planProTitle: 'Pro',
      planProPrice: '29.99€',
      planProBenefits: ['Cita Extranjería', 'Gestión Completa', 'Soporte Prioritario'],
      
      btnContract: 'Contratar',
      btnSelect: 'Seleccionar',
      
      // Services Section
      servicesTitle: 'Trámites de Extranjería',
      servicesSubtitle: 'Gestión completa de todos tus trámites legales',
      servicesList: [
        "Arraigo Social", 
        "Arraigo por Formación", 
        "Arraigo Laboral",
        "Visado de Estudiante", 
        "Visado de Trabajo",
        "Residencia Temporal", 
        "Residencia Permanente",
        "Nacionalidad Española",
        "Renovación de NIE", 
        "Renovación de Pasaporte",
        "Empadronamiento", 
        "Solicitud de Asilo",
        "Reagrupación Familiar", 
        "Autorización de Residencia",
        "Permiso de Trabajo",
        "Certificado de Antecedentes",
        "Solicitud de Visa",
        "Cambio de Estatus Migratorio"
      ],
      
      // Modal
      modalVerify: 'Verificar PDF',
      modalPlaceholder: 'Escribe tu mensaje...',
      securePayment: 'Métodos de pago seguros',
      
      // Footer
      privacy: 'Política de Privacidad',
      terms: 'Términos de Servicio',
      contact: 'Contacto',
      rights: 'Todos los derechos reservados.',
      aboutText: 'Gestoría inteligente con soporte 24/7 para tus trámites de extranjería.',
    },
    ar: {
      siteName: 'gestoriacitaia',
      
      // Header
      navHome: 'البداية',
      navServices: 'خدمات',
      navContact: 'اتصل بنا',
      navPrivacy: 'الخصوصية',
      btnBook: 'نقلب على موعد',

      // Avatars
      avatarSarahName: "سارة",
      avatarIvanName: "إيفان",
      avatarLaetitiaName: "ليتيسيا",
      btnSpeak: 'تحدث الآن',
      
      // Video
      videoTitle: 'فيديو تقديمي - كونسي جيستوريا IA',
      btnSearchAppointment: 'نقلب على موعد 9.99€',
      
      // Pricing
      planBasicTitle: 'أساسي',
      planBasicPrice: '9.99€',
      planBasicBenefits: ['15 دقيقة استشارة', 'أسئلة الهجرة', 'دردشة الذكاء الاصطناعي'],

      planStandardTitle: 'قياسي',
      planStandardPrice: '19.99€',
      planStandardBenefits: ['التحقق من الوثائق', 'مراجعة NIE', '3 استشارات/شهر'],

      planProTitle: 'برو',
      planProPrice: '29.99€',
      planProBenefits: ['موعد الهجرة', 'إدارة كاملة', 'دعم ذو أولوية'],
      
      btnContract: 'تعاقد',
      btnSelect: 'اختر',
      
      // Services Section
      servicesTitle: 'خدمات الهجرة',
      servicesSubtitle: 'إدارة كاملة لجميع إجراءاتك القانونية',
      servicesList: [
        "الجذور الاجتماعية", 
        "الجذور للتدريب", 
        "الجذور العملية",
        "تأشيرة طالب", 
        "تأشيرة عمل",
        "إقامة مؤقتة", 
        "إقامة دائمة",
        "الجنسية الإسبانية",
        "تجديد NIE", 
        "تجديد جواز السفر",
        "تسجيل السكن", 
        "طلب اللجوء",
        "لم شمل الأسرة", 
        "تصريح الإقامة",
        "تصريح العمل",
        "صحيفة السوابق",
        "طلب التأشيرة",
        "تغيير الوضع القانوني"
      ],
      
      // Modal
      modalVerify: 'تحقق من PDF',
      modalPlaceholder: 'اكتب رسالتك...',
      securePayment: 'طرق الدفع الآمنة',
      
      // Footer
      privacy: 'سياسة الخصوصية',
      terms: 'شروط الخدمة',
      contact: 'اتصل بنا',
      rights: 'جميع الحقوق محفوظة.',
      aboutText: 'وكالة ذكية مع دعم 24/7 لإجراءات الهجرة الخاصة بك.',
    }
  };

  const switchLanguage = (lang) => {
    setLanguage(lang);
  };

  return (
    <LanguageContext.Provider value={{ language, switchLanguage, t: translations[language] }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};