import React, { createContext, useContext, useState } from 'react';
import { useToast } from '../components/ui/use-toast';

const PaymentContext = createContext();

export const PaymentProvider = ({ children }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);
  
  // Subscription State - Mocked to always be active/true for free access
  const [subscriptionStatus, setSubscriptionStatus] = useState('active');

  const { toast } = useToast();

  const isSubscriptionActive = () => {
    return true; // Always true for free access
  };

  const checkAccess = () => {
    return true; // Always allow access
  };

  // Mock payment initiator that just simulates success
  const initiatePayment = async (amount, plan, userData, successUrl = null) => {
    setIsProcessing(true);
    setTimeout(() => {
        setIsProcessing(false);
        if (successUrl) {
            window.location.href = successUrl;
        }
    }, 1000);
  };

  const updateSubscriptionLocal = (plan, status, expiry) => {
      setSubscriptionStatus(status);
  };

  return (
    <PaymentContext.Provider value={{ 
      isProcessing, 
      setIsProcessing,
      error, 
      subscriptionStatus,
      setSubscriptionStatus,
      updateSubscriptionLocal,
      isSubscriptionActive,
      initiatePayment, 
      checkAccess
    }}>
      {children}
    </PaymentContext.Provider>
  );
};

export const usePayment = () => {
  const context = useContext(PaymentContext);
  if (!context) {
    throw new Error('usePayment must be used within a PaymentProvider');
  }
  return context;
};