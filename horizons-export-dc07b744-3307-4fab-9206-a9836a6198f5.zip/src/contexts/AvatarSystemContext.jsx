import React, { createContext, useContext, useState } from 'react';

const AvatarSystemContext = createContext();

export const AvatarSystemProvider = ({ children }) => {
  const [activeAvatar, setActiveAvatar] = useState('khalid'); // Default to main avatar
  const [conversationHistory, setConversationHistory] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Simple message handler
  const addMessage = (role, content) => {
    setConversationHistory(prev => [...prev, {
      id: Date.now(),
      role, // 'user' or 'assistant'
      content,
      timestamp: new Date().toISOString()
    }]);
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // In a real app, this would trigger the browser's MediaRecorder
  };

  return (
    <AvatarSystemContext.Provider value={{
      activeAvatar,
      setActiveAvatar,
      conversationHistory,
      addMessage,
      isRecording,
      toggleRecording,
      isProcessing,
      setIsProcessing
    }}>
      {children}
    </AvatarSystemContext.Provider>
  );
};

export const useAvatarSystem = () => {
  const context = useContext(AvatarSystemContext);
  if (!context) {
    throw new Error('useAvatarSystem must be used within an AvatarSystemProvider');
  }
  return context;
};