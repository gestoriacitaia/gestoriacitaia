import React, { createContext, useContext, useState, useEffect } from 'react';

const ConsultationContext = createContext();

export const ConsultationProvider = ({ children }) => {
  const [selectedAvatar, setSelectedAvatar] = useState(null);
  const [consultationLanguage, setConsultationLanguage] = useState('es'); // 'es' or 'ar'
  const [chatMessages, setChatMessages] = useState([]);
  const [uploadedDocuments, setUploadedDocuments] = useState([]);
  const [userData, setUserData] = useState(null); // Store user form data
  const [sessionData, setSessionData] = useState({
    startTime: null,
    duration: 0,
    isActive: false
  });
  const [isProcessing, setIsProcessing] = useState(false);

  // Initialize session
  useEffect(() => {
    const savedSession = localStorage.getItem('consultationSession');
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        setSessionData(parsed.sessionData || sessionData);
        setSelectedAvatar(parsed.selectedAvatar || null);
        setConsultationLanguage(parsed.consultationLanguage || 'es');
        setUserData(parsed.userData || null);
      } catch (e) {
        console.error('Failed to parse saved session', e);
      }
    }
  }, []);

  // Save session to localStorage
  useEffect(() => {
    if (sessionData.isActive) {
      localStorage.setItem('consultationSession', JSON.stringify({
        sessionData,
        selectedAvatar,
        consultationLanguage,
        userData
      }));
    }
  }, [sessionData, selectedAvatar, consultationLanguage, userData]);

  const addMessage = (message) => {
    setChatMessages(prev => [...prev, {
      ...message,
      timestamp: new Date().toISOString(),
      id: Date.now() + Math.random(),
    }]);
  };

  const addDocument = (document) => {
    setUploadedDocuments(prev => [...prev, {
      ...document,
      uploadedAt: new Date().toISOString(),
      id: Date.now() + Math.random(),
    }]);
  };

  const removeDocument = (documentId) => {
    setUploadedDocuments(prev => prev.filter(doc => doc.id !== documentId));
  };

  const startSession = (avatar, user) => {
    if (avatar) setSelectedAvatar(avatar);
    if (user) setUserData(user);
    
    setSessionData({
      startTime: new Date().toISOString(),
      duration: 120, // Default duration
      isActive: true
    });
  };

  const resetSession = () => {
    setSelectedAvatar(null);
    setUserData(null);
    setChatMessages([]);
    setUploadedDocuments([]);
    setSessionData({
      startTime: null,
      duration: 0,
      isActive: false
    });
    localStorage.removeItem('consultationSession');
  };

  return (
    <ConsultationContext.Provider value={{
      selectedAvatar,
      setSelectedAvatar,
      userData,
      setUserData,
      consultationLanguage,
      setConsultationLanguage,
      chatMessages,
      addMessage,
      uploadedDocuments,
      addDocument,
      removeDocument,
      sessionData,
      startSession,
      resetSession,
      isProcessing,
      setIsProcessing,
    }}>
      {children}
    </ConsultationContext.Provider>
  );
};

export const useConsultation = () => {
  const context = useContext(ConsultationContext);
  if (!context) {
    throw new Error('useConsultation must be used within a ConsultationProvider');
  }
  return context;
};