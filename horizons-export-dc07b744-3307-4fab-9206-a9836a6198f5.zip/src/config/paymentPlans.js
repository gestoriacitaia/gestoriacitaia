export const BUSCAR_CITA_PRODUCT = {
  id: 'buscar-cita-fee',
  name: 'Búsqueda de Cita',
  price: 9.99,
  currency: 'EUR',
  stripePriceId: 'price_buscar_cita_fixed',
};

export const PAYMENT_PLANS = [
  {
    id: 'basic',
    name: 'Plan Básico',
    price: 9.99,
    currency: 'EUR',
    stripePriceId: 'price_basic_plan',
    features: ['Consulta IA 15 min', 'Respuesta con videollamada en tiempo real'],
    isMonthly: false
  },
  {
    id: 'standard',
    name: 'Plan Estándar',
    price: 14.99,
    currency: 'EUR',
    stripePriceId: 'price_standard_plan',
    features: ['Consulta IA', 'Videollamada 5 veces al mes', 'Verificación de documentos PDF', 'Prioridad en respuesta', 'Historial de chats guardado'],
    isMonthly: false
  },
  {
    id: 'appointments',
    name: 'Plan Búsqueda de Citas',
    price: 12.99,
    currency: 'EUR',
    stripePriceId: 'price_appointments_plan',
    features: ['Buscar citas', 'Mandar WhatsApp al cliente', 'Acompañamiento del proceso', 'Videollamada en vivo paso a paso'],
    isMonthly: false
  },
  {
    id: 'pro',
    name: 'Plan Pro',
    price: 27.99,
    currency: 'EUR',
    stripePriceId: 'price_pro_plan',
    features: ['Todo ilimitado en el sitio web', 'Abonne cada mes', 'Todo incluido'],
    recommended: true,
    isMonthly: true
  }
];

export const SERVICE_TYPES = [
  "Arraigo Social", 
  "Arraigo por Formación", 
  "Arraigo Laboral",
  "Visado de Estudiante", 
  "Visado de Trabajo",
  "Residencia Temporal", 
  "Residencia Permanente",
  "Nacionalidad Española",
  "Renovación de NIE", 
  "Renovación de Pasaporte",
  "Empadronamiento", 
  "Solicitud de Asilo",
  "Reagrupación Familiar", 
  "Otros Trámites"
];

// Mock data for appointment simulation
export const MOCK_LOCATIONS = [
  "Oficina de Extranjería - Calle Silva 19",
  "Comisaría de Policía - Av. de los Poblados",
  "Oficina de Extranjería - Calle García de Paredes"
];

export const WHATSAPP_TEMPLATES = {
  appointmentFound: (name, date, time) => 
    `¡Hola ${name}! Hemos encontrado una cita disponible para el ${date} a las ${time}. ¿Quieres que la confirmemos? Responde SÍ.`
};