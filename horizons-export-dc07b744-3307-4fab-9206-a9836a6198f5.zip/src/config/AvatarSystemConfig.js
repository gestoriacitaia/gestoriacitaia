export const AVATAR_CONFIG = {
  mohamad: {
    id: 'mohamad',
    name: 'Mohamad',
    role: 'Trámites',
    specializationPrompt: 'Experto en orientación inicial, dudas básicas de extranjería y arraigo. Te guiará paso a paso en tus trámites.',
    voiceId: 'ODq5zmih8GrVes37Dizd', 
    supportedLanguages: ['es', 'darija'],
    image: 'https://img.freepik.com/foto-gratis/hombre-joven-barbudo-gafas-camisa-cuadros_273609-12297.jpg',
    associatedPlans: ['basic', 'standard', 'pro']
  },
  khalid: {
    id: 'khalid',
    name: 'Khalid',
    role: 'Trámites',
    specializationPrompt: 'Experto en rellenar formularios EX, revisar documentación, pasaportes y NIE para distintos trámites.',
    voiceId: 'TX3OmfOUXGLrx1q19pnP', 
    supportedLanguages: ['es', 'darija'],
    image: 'https://img.freepik.com/foto-gratis/retrato-hombre-sonriente-chateando-telefono_23-2148747872.jpg',
    associatedPlans: ['basic', 'standard', 'pro']
  },
  miriam: {
    id: 'miriam',
    name: 'Miriam',
    role: 'Buscar citas',
    specializationPrompt: 'Asistente dedicada a la búsqueda y gestión de citas previas en consulados de Marruecos y España.',
    voiceId: 'EXAVITQu4vr4xnSDxMaL',
    supportedLanguages: ['es', 'darija'],
    image: 'https://img.freepik.com/foto-gratis/retrato-hermosa-mujer-joven-pie-pared-gris_231208-10760.jpg',
    associatedPlans: ['appointments', 'pro']
  }
};