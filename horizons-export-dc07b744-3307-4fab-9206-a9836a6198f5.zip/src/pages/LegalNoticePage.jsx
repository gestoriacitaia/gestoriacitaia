import React from 'react';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import { Helmet } from 'react-helmet';

const LegalNoticePage = () => {
  return (
    <>
      <Helmet>
        <title>Aviso Legal - GestoríaCitaIA</title>
      </Helmet>
      <div className="min-h-screen bg-navy text-white font-sans flex flex-col">
        <GestoriaHeader />
        
        <main className="flex-1 container mx-auto px-4 py-12 max-w-4xl">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-cyan">Aviso Legal</h1>
          
          <div className="space-y-8 text-slate-300 leading-relaxed">
            <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800">
              <h2 className="text-xl font-bold text-white mb-4">1. Datos Identificativos</h2>
              <p className="mb-2">En cumplimiento con el deber de información recogido en artículo 10 de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y del Comercio Electrónico, a continuación se reflejan los siguientes datos:</p>
              <ul className="list-disc pl-5 space-y-2 mt-4 text-sm">
                <li><strong>Denominación Social:</strong> GestoríaCitaIA (Nombre Comercial)</li>
                <li><strong>Domicilio Social:</strong> Madrid, España (Dirección fiscal completa disponible bajo requerimiento formal)</li>
                <li><strong>Correo Electrónico de Contacto:</strong> info@gestoriacitaia.com</li>
                <li><strong>Actividad:</strong> Servicios de soporte tecnológico y orientación para trámites de extranjería.</li>
              </ul>
            </section>

            <DisclaimerBanner />

            <section>
              <h2 className="text-xl font-bold text-white mb-4">2. Objeto y Ámbito de Aplicación</h2>
              <p>
                El presente Aviso Legal regula el uso del sitio web GestoríaCitaIA. Su propósito es ofrecer una plataforma informativa y herramientas de asistencia para ciudadanos, especialmente ciudadanos marroquíes en España, facilitando la comprensión de trámites de extranjería, generación de guías para formularios y sistemas de alertas de citas previas.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">3. Responsabilidad del Usuario</h2>
              <p>
                El usuario asume la responsabilidad del uso del portal. Dicha responsabilidad se extiende al registro que fuese necesario para acceder a determinados servicios o contenidos. El usuario se compromete a hacer un uso adecuado de los contenidos y servicios, y a no emplearlos para actividades ilícitas, ilegales o contrarias a la buena fe y al orden público.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">4. Exención de Responsabilidad</h2>
              <p className="mb-4">
                GestoríaCitaIA declara expresamente que:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-sm">
                <li><strong>NO es un organismo oficial:</strong> No tenemos vinculación con el Ministerio de Asuntos Exteriores, Policía Nacional ni ninguna entidad gubernamental.</li>
                <li><strong>NO ofrece asesoramiento legal vinculante:</strong> Nuestra IA y consultores ofrecen orientación basada en información pública, pero no sustituyen a un abogado colegiado.</li>
                <li><strong>NO garantiza citas:</strong> Las herramientas de búsqueda de citas dependen enteramente de la disponibilidad en las sedes electrónicas oficiales.</li>
                <li><strong>NO vende citas:</strong> Está terminantemente prohibida la venta o reventa de citas a través de nuestra plataforma.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">5. Propiedad Intelectual e Industrial</h2>
              <p>
                GestoríaCitaIA es titular de todos los derechos de propiedad intelectual e industrial de su página web, así como de los elementos contenidos en la misma (imágenes, sonido, audio, vídeo, software o textos; marcas o logotipos, combinaciones de colores, estructura y diseño, etc.). Quedan expresamente prohibidas la reproducción, la distribución y la comunicación pública con fines comerciales sin autorización.
              </p>
            </section>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default LegalNoticePage;