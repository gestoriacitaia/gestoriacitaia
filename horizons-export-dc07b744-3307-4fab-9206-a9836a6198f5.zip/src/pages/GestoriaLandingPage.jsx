import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import GestoriaHeader from '@/components/GestoriaHeader';
import AvatarGrid from '@/components/AvatarGrid';
import VideoSection from '@/components/VideoSection';
import ServicesSection from '@/components/ServicesSection';
import PricingPlansSection from '@/components/PricingPlansSection';
import Footer from '@/components/Footer';
import CallModalNoPayment from '@/components/CallModalNoPayment';
import { useLanguage } from '@/contexts/LanguageContext';

const GestoriaLandingPage = () => {
  const { t } = useLanguage();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState(null);

  const handleAvatarClick = (avatar) => {
    setSelectedAvatar(avatar);
    setIsModalOpen(true);
  };

  return (
    <>
      <Helmet>
        <title>{t.siteName} - Asesoría Inteligente</title>
      </Helmet>

      <div className="min-h-screen bg-navy text-white flex flex-col font-sans">
        
        <GestoriaHeader />
        
        <main className="flex-1 w-full flex flex-col">
          
          <div id="avatars-section" className="mt-8">
            <AvatarGrid onAvatarClick={handleAvatarClick} />
          </div>

          <VideoSection />
          
          <ServicesSection />

          <PricingPlansSection />
          
        </main>

        <Footer />

        <CallModalNoPayment 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          avatar={selectedAvatar}
        />
        
      </div>
    </>
  );
};

export default GestoriaLandingPage;