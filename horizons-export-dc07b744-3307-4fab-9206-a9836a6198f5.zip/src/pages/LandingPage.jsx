import React from 'react';
import { Helmet } from 'react-helmet';
import HeroSection from '../components/HeroSection';
import AvatarSpecialists from '../components/AvatarSpecialists';
import PricingSection from '../components/PricingSection';
import { useLanguage } from '../contexts/LanguageContext';

const LandingPage = ({ onOpenChat }) => {
  const { language } = useLanguage();

  const meta = {
    es: {
      title: 'gestoriaia.com - Asistencia Legal Impulsada por IA',
      description: 'Consultas legales instantáneas 24/7 con nuestros asistentes IA especializados. Ayuda con extranjería, verificación de documentos y más.',
    },
    ar: {
      title: 'gestoriaia.com - Tawiza Qanuniya Bi-AI',
      description: 'Tiwizi tiqanuniyin deg tmezwarut 24/7 s imudda-nneɣ AI imusnawen. Tallalt s tejṛa, taqyiq n isefra d wiyaḍ.',
    },
  };

  const currentMeta = meta[language];

  return (
    <>
      <Helmet>
        <title>{currentMeta.title}</title>
        <meta name="description" content={currentMeta.description} />
      </Helmet>

      <main>
        <HeroSection />
        <AvatarSpecialists onOpenChat={onOpenChat} />
        <PricingSection />
      </main>
    </>
  );
};

export default LandingPage;