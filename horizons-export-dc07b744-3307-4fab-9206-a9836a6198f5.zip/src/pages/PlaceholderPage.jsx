import React from 'react';
import { Helmet } from 'react-helmet';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';
import { Construction } from 'lucide-react';

const PlaceholderPage = ({ title }) => {
  return (
    <>
      <Helmet>
        <title>{title} - GestoríaCitaIA</title>
      </Helmet>
      <div className="min-h-screen bg-navy flex flex-col">
        <GestoriaHeader />
        <main className="flex-1 flex flex-col items-center justify-center p-8 text-center">
          <Construction className="w-24 h-24 text-cyan mb-6 animate-pulse" />
          <h1 className="text-4xl font-bold text-white mb-4">{title}</h1>
          <p className="text-slate-400 max-w-lg mx-auto">
            🚧 Esta sección está siendo optimizada por nuestro equipo de expertos en IA para ofrecerte la mejor experiencia en trámites de extranjería. ¡Pronto estará disponible! 🚀
          </p>
          <button 
            onClick={() => window.history.back()}
            className="mt-8 px-8 py-3 bg-cyan text-navy font-bold hover:bg-cyan-light transition-colors"
          >
            Volver atrás
          </button>
        </main>
        <Footer />
      </div>
    </>
  );
};

export default PlaceholderPage;