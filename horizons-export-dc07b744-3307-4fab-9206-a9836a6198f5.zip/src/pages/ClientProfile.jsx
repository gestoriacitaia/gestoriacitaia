import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, User, FileText, MessageSquare, FileCheck, Search, LayoutDashboard, Users, Gift } from 'lucide-react';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { useNavigate, useSearchParams } from 'react-router-dom';

import ProfileInfoTab from '@/components/profile/ProfileInfoTab';
import PDFsFilledTab from '@/components/profile/PDFsFilledTab';
import ChatHistoryTab from '@/components/profile/ChatHistoryTab';
import VerifiedDocumentsTab from '@/components/profile/VerifiedDocumentsTab';
import CitaSearchTab from '@/components/profile/CitaSearchTab';
import ReferralHistoryTab from '@/components/profile/ReferralHistoryTab';
import ReferralRewardsTab from '@/components/profile/ReferralRewardsTab';
import ReferralRewardNotification from '@/components/ReferralRewardNotification';
import { supabase } from '@/lib/customSupabaseClient';

const ClientProfile = () => {
  const { user, logOut, createOrUpdateProfile } = useGoogleAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isNewUser = searchParams.get('new') === 'true';

  const [activeTab, setActiveTab] = useState('info');
  const [showRewardModal, setShowRewardModal] = useState(false);

  useEffect(() => {
    if (user && isNewUser) {
      createOrUpdateProfile(user);
      // Remove query param after sync
      window.history.replaceState({}, document.title, "/profile");
    }
  }, [user, isNewUser, createOrUpdateProfile]);

  // Listen for new rewards
  useEffect(() => {
    if (!user) return;
    
    const channel = supabase.channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'tabla_referral_rewards',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          setShowRewardModal(true);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const tabs = [
    { id: 'info', label: 'Mi Perfil', icon: <User className="w-5 h-5" /> },
    { id: 'pdfs', label: 'PDFs Llenados', icon: <FileText className="w-5 h-5" /> },
    { id: 'chat', label: 'Historial Chat', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'docs', label: 'Documentos', icon: <FileCheck className="w-5 h-5" /> },
    { id: 'citas', label: 'Búsqueda Citas', icon: <Search className="w-5 h-5" /> },
    { id: 'referrals', label: 'Referidos', icon: <Users className="w-5 h-5" /> },
    { id: 'rewards', label: 'Recompensas', icon: <Gift className="w-5 h-5" /> },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'info': return <ProfileInfoTab />;
      case 'pdfs': return <PDFsFilledTab />;
      case 'chat': return <ChatHistoryTab />;
      case 'docs': return <VerifiedDocumentsTab />;
      case 'citas': return <CitaSearchTab />;
      case 'referrals': return <ReferralHistoryTab />;
      case 'rewards': return <ReferralRewardsTab />;
      default: return <ProfileInfoTab />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-navy text-white">
      <GestoriaHeader />
      
      <main className="flex-1 max-w-[1400px] mx-auto w-full px-4 py-8 md:py-12 flex flex-col lg:flex-row gap-8">
        
        {/* Sidebar Navigation */}
        <aside className="w-full lg:w-72 flex-shrink-0">
          <div className="bg-navy-light rounded-2xl border border-navy-lighter p-6 sticky top-24">
            <div className="flex items-center gap-4 mb-8 pb-6 border-b border-navy-lighter">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan to-blue-500 flex items-center justify-center text-xl font-bold text-navy shadow-lg">
                {user?.user_metadata?.full_name?.charAt(0) || user?.email?.charAt(0)?.toUpperCase() || 'U'}
              </div>
              <div className="overflow-hidden">
                <h3 className="font-bold text-white truncate">{user?.user_metadata?.full_name || 'Usuario'}</h3>
                <p className="text-xs text-gray-400 truncate">{user?.email}</p>
              </div>
            </div>

            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm font-medium ${
                    activeTab === tab.id 
                      ? 'bg-cyan/10 text-cyan border border-cyan/20 shadow-inner' 
                      : 'text-gray-400 hover:text-white hover:bg-navy-lighter border border-transparent'
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </nav>

            <button
              onClick={logOut}
              className="w-full mt-8 flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-red-400 hover:text-white hover:bg-red-500/20 transition-all text-sm font-medium border border-transparent hover:border-red-500/30"
            >
              <LogOut className="w-4 h-4" /> Cerrar Sesión
            </button>
          </div>
        </aside>

        {/* Main Content Area */}
        <section className="flex-1 min-w-0">
          <div className="mb-6 flex items-center gap-3">
            <LayoutDashboard className="w-8 h-8 text-cyan" />
            <h1 className="text-3xl font-bold text-white">Panel de Cliente</h1>
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </section>

      </main>

      <Footer />
      
      <ReferralRewardNotification 
        isOpen={showRewardModal} 
        onClose={() => setShowRewardModal(false)} 
      />
    </div>
  );
};

export default ClientProfile;