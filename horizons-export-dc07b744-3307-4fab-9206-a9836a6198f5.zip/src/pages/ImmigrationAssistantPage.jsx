import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Clock, FileText, ArrowLeft } from 'lucide-react';
import GestoriaHeader from '@/components/GestoriaHeader';
import ImmigrationChatInterface from '@/components/immigration/ImmigrationChatInterface';
import { useNavigate } from 'react-router-dom';

const ImmigrationAssistantPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <GestoriaHeader />

      {/* Hero Section */}
      <div className="relative bg-navy pb-32 pt-12 overflow-hidden">
        {/* Background Image & Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1558613847-e6802746513d?q=80&w=2070&auto=format&fit=crop" 
            alt="Office background" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-navy via-navy/90 to-gray-50" />
          
          {/* Moroccan Pattern Accent */}
          <div 
            className="absolute top-0 right-0 w-1/3 h-full opacity-10 mix-blend-overlay pointer-events-none"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1655403826499-f094afd7dea3?q=80&w=1000&auto=format&fit=crop')`,
              backgroundSize: 'cover'
            }}
          />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          {/* Top Nav Button */}
          <div className="flex justify-between items-center mb-8">
            <button 
              onClick={() => navigate('/')} 
              className="flex items-center gap-2 text-white/70 hover:text-white transition-colors text-sm font-medium"
            >
              <ArrowLeft className="w-4 h-4" /> Volver al Inicio
            </button>
            <a 
              href="#" 
              className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg backdrop-blur-sm text-sm font-semibold transition-all border border-white/10 flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              Ayudas Económicas y Alquiler
            </a>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto mb-12"
          >
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
              Tu Asistente de Inmigración <span className="text-cyan">Inteligente</span>
            </h1>
            <p className="text-gray-300 text-lg md:text-xl leading-relaxed">
              Resuelve tus dudas sobre extranjería al instante. Disponible en Español y Darija, 
              con la garantía legal de nuestros expertos.
            </p>
          </motion.div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12">
            {[
              { icon: Clock, text: "Respuesta en < 5 segundos" },
              { icon: Shield, text: "Verificación Documental Segura" },
              { icon: FileText, text: "Expertos en Extranjería" }
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-center gap-3 bg-white/5 backdrop-blur-sm border border-white/10 p-3 rounded-lg text-gray-200 text-sm font-medium">
                <item.icon className="w-5 h-5 text-cyan" />
                {item.text}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Interface Section - Pulling up over the hero */}
      <div className="container mx-auto px-4 -mt-24 relative z-20 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <ImmigrationChatInterface />
        </motion.div>
      </div>

      {/* Footer Info */}
      <div className="bg-white border-t border-gray-200 py-12">
        <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
          <p>© 2024 GestoriaCitaIA. Todos los derechos reservados.</p>
          <p className="mt-2">La información proporcionada por el asistente IA es orientativa. Para trámites oficiales, consulta siempre con un abogado colegiado.</p>
        </div>
      </div>
    </div>
  );
};

export default ImmigrationAssistantPage;