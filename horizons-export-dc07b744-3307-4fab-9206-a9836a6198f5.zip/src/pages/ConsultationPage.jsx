import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';
import RealTimeAvatarChat from '@/components/RealTimeAvatarChat';

const ConsultationPage = () => {
  const { language } = useLanguage();
  const navigate = useNavigate();

  return (
    <>
      <Helmet>
        <title>{language === 'es' ? 'Asistente IA - gestoriacitaia' : 'AI Assistant - gestoriacitaia'}</title>
      </Helmet>

      {/* We replace the entire page content with the RealTimeChat for an immersive experience */}
      <div className="fixed inset-0 bg-slate-950 z-50">
        <RealTimeAvatarChat />
        
        {/* Floating Back Button */}
        <button
            onClick={() => navigate('/')}
            className="absolute top-6 left-6 z-50 flex items-center gap-2 text-white/50 hover:text-white transition-colors bg-black/20 hover:bg-black/40 px-4 py-2 rounded-full backdrop-blur-md"
        >
            <ArrowLeft className="w-4 h-4" /> 
            <span className="text-sm font-medium">{language === 'es' ? 'Salir' : 'Exit'}</span>
        </button>
      </div>
    </>
  );
};

export default ConsultationPage;