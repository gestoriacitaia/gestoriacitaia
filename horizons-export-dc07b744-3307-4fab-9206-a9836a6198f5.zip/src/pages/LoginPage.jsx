import React from 'react';
import { motion } from 'framer-motion';
import { LogIn, ArrowRight } from 'lucide-react';
import { useGoogleAuth } from '@/contexts/GoogleAuthContext';
import { Link, Navigate } from 'react-router-dom';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';

const LoginPage = () => {
  const { signInWithGoogle, user, loading } = useGoogleAuth();

  if (loading) return null;
  if (user) return <Navigate to="/profile" replace />;

  return (
    <div className="min-h-screen flex flex-col bg-navy text-white">
      <GestoriaHeader />
      
      <main className="flex-1 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-navy-light border border-navy-lighter rounded-2xl p-8 shadow-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan/5 rounded-full blur-3xl -mr-10 -mt-10" />
          
          <div className="text-center mb-8 relative z-10">
            <div className="w-16 h-16 bg-navy rounded-2xl border border-navy-lighter flex items-center justify-center mx-auto mb-6 shadow-lg">
              <LogIn className="w-8 h-8 text-cyan" />
            </div>
            <h1 className="text-3xl font-bold mb-2">Bienvenido de nuevo</h1>
            <p className="text-gray-400">Inicia sesión para acceder a tu panel de cliente</p>
          </div>

          <button
            onClick={signInWithGoogle}
            className="w-full relative z-10 flex items-center justify-center gap-3 bg-white text-gray-900 hover:bg-gray-100 py-3.5 px-4 rounded-xl font-bold transition-all shadow-lg transform hover:-translate-y-0.5"
          >
            <svg viewBox="0 0 24 24" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
              <g transform="matrix(1, 0, 0, 1, 27.009001, -39.238998)">
                <path fill="#4285F4" d="M -3.264,51.509 C -3.264,50.719 -3.334,49.969 -3.454,49.239 L -14.754,49.239 L -14.754,53.749 L -8.284,53.749 C -8.574,55.229 -9.424,56.479 -10.684,57.329 L -10.684,60.329 L -6.824,60.329 C -4.564,58.239 -3.264,55.159 -3.264,51.509 Z"/>
                <path fill="#34A853" d="M -14.754,63.239 C -11.514,63.239 -8.804,62.159 -6.824,60.329 L -10.684,57.329 C -11.764,58.049 -13.134,58.489 -14.754,58.489 C -17.884,58.489 -20.534,56.379 -21.484,53.529 L -25.464,53.529 L -25.464,56.619 C -23.494,60.539 -19.444,63.239 -14.754,63.239 Z"/>
                <path fill="#FBBC05" d="M -21.484,53.529 C -21.734,52.809 -21.864,52.039 -21.864,51.239 C -21.864,50.439 -21.724,49.669 -21.484,48.949 L -21.484,45.859 L -25.464,45.859 C -26.284,47.479 -26.754,49.299 -26.754,51.239 C -26.754,53.179 -26.284,54.999 -25.464,56.619 L -21.484,53.529 Z"/>
                <path fill="#EA4335" d="M -14.754,43.989 C -12.984,43.989 -11.404,44.599 -10.154,45.789 L -6.734,41.939 C -8.804,40.009 -11.514,38.989 -14.754,38.989 C -19.444,38.989 -23.494,41.689 -25.464,45.859 L -21.484,48.949 C -20.534,46.099 -17.884,43.989 -14.754,43.989 Z"/>
              </g>
            </svg>
            Continuar con Google
          </button>

          <div className="mt-8 text-center relative z-10">
            <p className="text-gray-400 text-sm">
              ¿No tienes una cuenta?{' '}
              <Link to="/signup" className="text-cyan hover:text-cyan-light font-bold flex items-center justify-center gap-1 mt-2 transition-colors">
                Regístrate ahora <ArrowRight className="w-4 h-4" />
              </Link>
            </p>
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default LoginPage;