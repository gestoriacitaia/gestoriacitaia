import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Loader2, ArrowLeft, Shield, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePayment } from '@/contexts/PaymentContext';
import { stripeSubscriptionService } from '@/services/stripeSubscriptionService';
import SubscriptionPaymentForm from '@/components/SubscriptionPaymentForm';
import SubscriptionPlansDisplay from '@/components/SubscriptionPlansDisplay';
import SubscriptionModal from '@/components/SubscriptionModal';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';

const SubscriptionCheckout = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { language } = useLanguage();
  const { updateSubscriptionLocal } = usePayment();
  
  const [step, setStep] = useState(1); // 1: Plans, 2: Payment
  const [selectedPlanId, setSelectedPlanId] = useState('basic');
  const [status, setStatus] = useState('idle'); // idle, verifying, success, error
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [verifiedPlan, setVerifiedPlan] = useState(null);

  const sessionId = searchParams.get('session_id');

  // Handle Initial Load with Session ID (Redirect back from Stripe)
  useEffect(() => {
    if (sessionId) {
      verifySession(sessionId);
    }
  }, [sessionId]);

  const verifySession = async (id) => {
    setStatus('verifying');
    const plan = searchParams.get('plan') || 'basic';
    
    try {
      const result = await stripeSubscriptionService.verifyPaymentSession(id, plan);
      
      if (result.success) {
        setStatus('success');
        setVerifiedPlan(result.subscription);
        updateSubscriptionLocal(
            result.subscription.plan_name, 
            'active', 
            result.subscription.expires_at
        );
        setShowSuccessModal(true);
      } else {
        setStatus('error');
      }
    } catch (error) {
      console.error(error);
      setStatus('error');
    }
  };

  const handlePlanSelect = (planId) => {
    setSelectedPlanId(planId);
    setStep(2);
    // Smooth scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToPlans = () => {
    setStep(1);
  };

  return (
    <div className="min-h-screen bg-navy text-white flex flex-col">
      <GestoriaHeader />
      
      <main className="flex-1 container mx-auto px-4 py-12 flex flex-col items-center">
        
        {/* Status: Verifying (Loading) */}
        {status === 'verifying' && (
          <div className="text-center mt-20">
            <Loader2 className="w-16 h-16 text-cyan animate-spin mx-auto mb-6" />
            <h2 className="text-2xl font-bold">
              {language === 'es' ? 'Verificando suscripción...' : 'جاري التحقق من الاشتراك...'}
            </h2>
            <p className="text-gray-400 mt-2">
              {language === 'es' ? 'Por favor no cierres esta ventana.' : 'يرجى عدم إغلاق هذه النافذة.'}
            </p>
          </div>
        )}

        {/* Status: Error */}
        {status === 'error' && (
          <div className="text-center bg-red-900/20 border border-red-500/30 p-8 rounded-2xl max-w-md mt-10">
            <h2 className="text-xl font-bold text-red-400 mb-2">Error</h2>
            <button 
              onClick={() => navigate('/subscription-checkout')}
              className="bg-navy-light text-white px-6 py-2 rounded-lg mt-4"
            >
              Retry
            </button>
          </div>
        )}

        {/* Status: Idle (Main Flow) */}
        {status === 'idle' && (
          <div className="w-full">
            
            {/* Header Section */}
            <div className="text-center mb-12">
              <h1 className="text-3xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
                {step === 1 
                  ? (language === 'es' ? 'Planes de Suscripción' : 'خطط الاشتراك')
                  : (language === 'es' ? 'Finalizar Suscripción' : 'إتمام الاشتراك')}
              </h1>
              <p className="text-gray-400 max-w-2xl mx-auto text-lg">
                {step === 1 
                  ? (language === 'es' 
                      ? 'Elige el plan que mejor se adapte a tus necesidades legales.' 
                      : 'اختر الخطة التي تناسب احتياجاتك القانونية.')
                  : (language === 'es' 
                      ? 'Ingresa tus datos para completar la activación.' 
                      : 'أدخل بياناتك لإكمال التفعيل.')}
              </p>
            </div>

            {/* Step 1: Plans */}
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="plans"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                >
                  <SubscriptionPlansDisplay onSelectPlan={handlePlanSelect} />
                </motion.div>
              )}

              {/* Step 2: Payment Form */}
              {step === 2 && (
                <motion.div
                  key="form"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="max-w-xl mx-auto"
                >
                  <SubscriptionPaymentForm 
                    plan={selectedPlanId} 
                    onBack={handleBackToPlans}
                  />
                  
                  {/* Trust Badges */}
                  <div className="mt-8 grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-3 p-4 bg-navy-light/50 rounded-xl border border-navy-lighter">
                      <Shield className="w-6 h-6 text-green-400" />
                      <div>
                        <p className="text-xs font-bold text-white uppercase">Garantía 100%</p>
                        <p className="text-[10px] text-gray-400">Cancelación gratuita</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-4 bg-navy-light/50 rounded-xl border border-navy-lighter">
                      <Check className="w-6 h-6 text-cyan" />
                      <div>
                        <p className="text-xs font-bold text-white uppercase">Soporte 24/7</p>
                        <p className="text-[10px] text-gray-400">Ayuda experta</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

          </div>
        )}

        {/* Success Modal (Legacy/Fallback) */}
        <SubscriptionModal 
          isOpen={showSuccessModal} 
          onClose={() => setShowSuccessModal(false)}
          planName={verifiedPlan?.plan_name}
          price={verifiedPlan?.amount}
          expiryDate={verifiedPlan?.expires_at}
        />
      </main>

      <Footer />
    </div>
  );
};

export default SubscriptionCheckout;