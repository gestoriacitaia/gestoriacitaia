import React from 'react';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';
import { Helmet } from 'react-helmet';

const CookiesPolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Política de Cookies - GestoríaCitaIA</title>
      </Helmet>
      <div className="min-h-screen bg-navy text-white font-sans flex flex-col">
        <GestoriaHeader />
        
        <main className="flex-1 container mx-auto px-4 py-12 max-w-4xl">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-cyan">Política de Cookies</h1>
          
          <div className="space-y-8 text-slate-300 leading-relaxed">
            <p>
              Esta web utiliza cookies propias y de terceros para ofrecerte una mejor experiencia de navegación, recordar tus preferencias y realizar tareas de análisis.
            </p>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">1. ¿Qué son las Cookies?</h2>
              <p>
                Una cookie es un pequeño fichero de texto que se almacena en tu navegador cuando visitas casi cualquier página web. Su utilidad es que la web sea capaz de recordar tu visita cuando vuelvas a navegar por esa página.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">2. Tipos de Cookies que utilizamos</h2>
              
              <div className="space-y-4">
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                  <h3 className="font-bold text-cyan mb-2">Cookies Técnicas (Necesarias)</h3>
                  <p className="text-sm">Son aquellas que permiten al usuario la navegación a través de la web y la utilización de las diferentes opciones o servicios que en ella existen. Por ejemplo: controlar el tráfico, identificar la sesión de usuario, acceder a partes de acceso restringido (perfil cliente), recordar elementos de un pedido (carrito), realizar el proceso de compra (pagos).</p>
                </div>

                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                  <h3 className="font-bold text-cyan mb-2">Cookies de Personalización</h3>
                  <p className="text-sm">Permiten al usuario acceder al servicio con algunas características de carácter general predefinidas en función de una serie de criterios en el terminal del usuario, como por ejemplo el idioma (Español o Árabe) o el tipo de navegador.</p>
                </div>

                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                  <h3 className="font-bold text-cyan mb-2">Cookies de Análisis</h3>
                  <p className="text-sm">Son aquellas que permiten el seguimiento y análisis del comportamiento de los usuarios en los sitios web a los que están vinculadas. La información recogida mediante este tipo de cookies se utiliza en la medición de la actividad del sitio web.</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">3. Consentimiento</h2>
              <p>
                Al visitar nuestra web por primera vez, te mostramos un aviso de cookies donde puedes aceptar o rechazar el uso de cookies no esenciales. Puedes cambiar tu configuración en cualquier momento eliminando las cookies de tu navegador.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">4. Administración de Cookies</h2>
              <p className="mb-4">
                Puedes permitir, bloquear o eliminar las cookies instaladas en tu equipo mediante la configuración de las opciones del navegador instalado en tu ordenador:
              </p>
              <ul className="list-disc pl-5 space-y-2 text-sm">
                <li><strong>Google Chrome:</strong> Configuración - Privacidad y seguridad - Cookies y otros datos de sitios.</li>
                <li><strong>Mozilla Firefox:</strong> Opciones - Privacidad y seguridad.</li>
                <li><strong>Safari:</strong> Preferencias - Seguridad.</li>
                <li><strong>Microsoft Edge:</strong> Configuración - Cookies y permisos del sitio.</li>
              </ul>
            </section>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default CookiesPolicyPage;