import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import GestoriaHeader from '../components/GestoriaHeader';
import Footer from '../components/Footer';
import { Helmet } from 'react-helmet';

const PrivacyPolicy = () => {
  const { t, language } = useLanguage();

  return (
    <>
      <Helmet>
        <title>{t.privacyTitle} - {t.siteName}</title>
      </Helmet>
      <div className="min-h-screen bg-sky-bg flex flex-col">
        <GestoriaHeader />
        
        <main className="flex-1 py-12 md:py-20">
          <div className="container mx-auto px-4 max-w-4xl">
            <div className="bg-white p-8 md:p-12 rounded-[32px] shadow-xl border border-sky-100">
              <h1 className="text-3xl md:text-4xl font-bold text-navy mb-4">{t.privacyTitle}</h1>
              <p className="text-gray-500 mb-8">{t.privacyLastUpdated}: {new Date().toLocaleDateString()}</p>
              
              <div className="space-y-8 text-gray-700 leading-relaxed" dir={language === 'ar' ? 'rtl' : 'ltr'}>
                <p className="text-lg">{t.privacyIntro}</p>
                
                <section>
                  <h2 className="text-xl font-bold text-navy mb-3">{t.privacySection1}</h2>
                  <p>{t.privacySection1Text}</p>
                </section>

                <section>
                  <h2 className="text-xl font-bold text-navy mb-3">{t.privacySection2}</h2>
                  <p>{t.privacySection2Text}</p>
                </section>

                <section>
                  <h2 className="text-xl font-bold text-navy mb-3">{t.privacySection3}</h2>
                  <p>{t.privacySection3Text}</p>
                </section>
                
                <section className="bg-sky-50 p-6 rounded-xl border border-sky-100 mt-8">
                  <h3 className="font-bold text-navy mb-2">GDPR Compliance</h3>
                  <p className="text-sm">We are fully compliant with the General Data Protection Regulation (GDPR). You have the right to access, rectify, or erase your personal data at any time.</p>
                </section>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default PrivacyPolicy;