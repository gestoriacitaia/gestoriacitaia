import React from 'react';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';
import { Helmet } from 'react-helmet';

const PrivacyPolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Política de Privacidad - GestoríaCitaIA</title>
      </Helmet>
      <div className="min-h-screen bg-navy text-white font-sans flex flex-col">
        <GestoriaHeader />
        
        <main className="flex-1 container mx-auto px-4 py-12 max-w-4xl">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-cyan">Política de Privacidad</h1>
          
          <div className="space-y-8 text-slate-300 leading-relaxed">
            <p className="text-lg">
              En GestoríaCitaIA, nos tomamos muy en serio tu privacidad. Esta política detalla cómo recopilamos, usamos y protegemos tus datos personales conforme al Reglamento General de Protección de Datos (RGPD) y la Ley Orgánica 3/2018 (LOPDGDD).
            </p>

            <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800">
              <h2 className="text-xl font-bold text-white mb-4">1. Responsable del Tratamiento</h2>
              <p>
                <strong>Identidad:</strong> GestoríaCitaIA<br/>
                <strong>Email:</strong> info@gestoriacitaia.com<br/>
                <strong>Delegado de Protección de Datos (DPO):</strong> Para consultas sobre privacidad, contacte a nuestro equipo legal en el email indicado.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">2. Datos que Recopilamos</h2>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Datos Identificativos:</strong> Nombre, apellidos, fecha de nacimiento, nacionalidad.</li>
                <li><strong>Datos de Contacto:</strong> Correo electrónico, número de teléfono, dirección postal.</li>
                <li><strong>Datos de Documentación:</strong> Número de NIE, Pasaporte (necesarios para la generación de formularios EX).</li>
                <li><strong>Datos de Navegación:</strong> Dirección IP, tipo de dispositivo (para seguridad y análisis).</li>
                <li><strong>Datos Transaccionales:</strong> Historial de suscripciones y pagos (procesados de forma segura vía Stripe).</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">3. Finalidad del Tratamiento</h2>
              <p>Usamos tus datos exclusivamente para:</p>
              <ul className="list-disc pl-5 space-y-2 mt-2">
                <li>Gestionar tu cuenta de usuario y suscripción.</li>
                <li>Prestar el servicio de orientación en trámites de extranjería.</li>
                <li>Generar borradores de formularios oficiales (ej. EX-00, EX-15) bajo tu petición.</li>
                <li>Enviarte alertas de disponibilidad de citas previas (si tienes el plan Pro).</li>
                <li>Cumplir con obligaciones legales y fiscales.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">4. Legitimación</h2>
              <p>
                La base legal para el tratamiento de tus datos es el <strong>consentimiento explícito</strong> que nos otorgas al registrarte y aceptar esta política, así como la <strong>ejecución del contrato</strong> de prestación de servicios (suscripción).
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">5. Conservación de Datos</h2>
              <p>
                Los datos personales se conservarán mientras se mantenga la relación comercial o durante los años necesarios para cumplir con las obligaciones legales. Si cancelas tu cuenta, tus datos serán bloqueados y posteriormente eliminados conforme a los plazos legales.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">6. Destinatarios</h2>
              <p>
                No cedemos tus datos a terceros, salvo obligación legal. Sin embargo, compartimos datos estrictamente necesarios con proveedores de servicios tecnológicos (encargados de tratamiento) bajo contratos de confidencialidad:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2 text-sm">
                <li>Supabase (Alojamiento de base de datos)</li>
                <li>Stripe (Pasarela de pagos)</li>
                <li>OpenAI (Procesamiento de consultas IA - datos anonimizados donde es posible)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">7. Derechos del Usuario</h2>
              <p>Tienes derecho a:</p>
              <ul className="list-disc pl-5 space-y-2 mt-2">
                <li><strong>Acceder</strong> a tus datos personales.</li>
                <li><strong>Rectificar</strong> datos inexactos.</li>
                <li><strong>Solicitar la supresión</strong> de tus datos cuando ya no sean necesarios.</li>
                <li><strong>Limitar</strong> el tratamiento de tus datos.</li>
                <li><strong>Oponerte</strong> al tratamiento.</li>
                <li>Solicitar la <strong>portabilidad</strong> de tus datos.</li>
              </ul>
              <p className="mt-4">
                Para ejercer estos derechos, envía un email a info@gestoriacitaia.com con el asunto "Protección de Datos" y copia de tu documento de identidad.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-white mb-4">8. Seguridad</h2>
              <p>
                Implementamos medidas de seguridad técnicas y organizativas robustas, incluyendo encriptación SSL/TLS para toda la web, bases de datos cifradas en reposo, copias de seguridad diarias y control de acceso restringido a la información.
              </p>
            </section>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default PrivacyPolicyPage;