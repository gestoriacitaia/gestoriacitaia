import React from 'react';

// This page has been deprecated/removed.
export default function ProductDetailPage() {
  return null;
}