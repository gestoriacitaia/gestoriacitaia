import React from 'react';
import { useNavigate } from 'react-router-dom';
import { XCircle, RefreshCw, ArrowLeft } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';

const SubscriptionCancelled = () => {
  const navigate = useNavigate();
  const { language } = useLanguage();

  return (
    <div className="min-h-screen bg-navy text-white flex flex-col">
      <GestoriaHeader />
      
      <main className="flex-1 container mx-auto px-4 flex items-center justify-center py-12">
        <div className="bg-navy-light border border-navy-lighter p-8 md:p-12 rounded-3xl max-w-lg w-full text-center shadow-xl">
          <div className="mb-6 flex justify-center">
            <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center">
              <XCircle className="w-10 h-10 text-red-500" />
            </div>
          </div>

          <h1 className="text-2xl font-bold mb-2">
            {language === 'es' ? 'Pago Cancelado' : 'تم إلغاء الدفع'}
          </h1>
          <p className="text-gray-400 mb-8">
            {language === 'es' 
              ? 'El proceso de pago fue cancelado. No se ha realizado ningún cargo en tu cuenta.' 
              : 'تم إلغاء عملية الدفع. لم يتم خصم أي مبلغ من حسابك.'}
          </p>

          <div className="flex flex-col gap-3">
            <button 
              onClick={() => navigate('/subscription-checkout')}
              className="w-full bg-cyan hover:bg-cyan-dark text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg shadow-cyan/20 flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-5 h-5" /> {language === 'es' ? 'Intentar Nuevamente' : 'حاول مرة أخرى'}
            </button>
            
            <button 
              onClick={() => navigate('/')}
              className="w-full bg-transparent hover:bg-navy-dark text-gray-400 hover:text-white font-medium py-3 px-6 rounded-xl transition-all flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" /> {language === 'es' ? 'Volver al Inicio' : 'العودة إلى البداية'}
            </button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default SubscriptionCancelled;