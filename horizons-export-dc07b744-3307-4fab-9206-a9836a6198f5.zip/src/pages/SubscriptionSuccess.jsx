import React, { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Download, ArrowRight, Star } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePayment } from '@/contexts/PaymentContext';
import GestoriaHeader from '@/components/GestoriaHeader';
import Footer from '@/components/Footer';

const SubscriptionSuccess = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { language } = useLanguage();
  const { updateSubscriptionLocal } = usePayment();

  const planId = searchParams.get('plan') || 'basic';
  const sessionId = searchParams.get('session_id');

  const planNames = {
    basic: language === 'es' ? 'Plan Básico' : 'الخطة الأساسية',
    standard: language === 'es' ? 'Plan Estándar' : 'الخطة القياسية',
    appointments: language === 'es' ? 'Plan Búsqueda de Citas' : 'خطة بحث المواعيد',
    pro: language === 'es' ? 'Plan Pro' : 'خطة المحترفين'
  };

  const displayName = planNames[planId] || planNames.basic;

  useEffect(() => {
    // In a real app, we verify the session ID with the backend here.
    // For now, we assume success if we reached this page with a session ID.
    if (planId && sessionId) {
      // Simulate verification and update local state
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + 30); // 30 days from now
      updateSubscriptionLocal(planId, 'active', expiryDate.toISOString());
    }
  }, [planId, sessionId, updateSubscriptionLocal]);

  return (
    <div className="min-h-screen bg-navy text-white flex flex-col">
      <GestoriaHeader />
      
      <main className="flex-1 container mx-auto px-4 flex items-center justify-center py-12">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-navy-light border border-navy-lighter p-8 md:p-12 rounded-3xl max-w-lg w-full text-center shadow-2xl relative overflow-hidden"
        >
          {/* Confetti / Decoration */}
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-400 via-cyan to-blue-500" />
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-green-500/10 rounded-full blur-3xl" />
          
          <div className="mb-6 flex justify-center">
            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center">
              <CheckCircle className="w-10 h-10 text-green-500" />
            </div>
          </div>

          <h1 className="text-3xl font-bold mb-2">
            {language === 'es' ? '¡Pago Exitoso!' : 'تم الدفع بنجاح!'}
          </h1>
          <p className="text-gray-400 mb-8">
            {language === 'es' 
              ? 'Tu suscripción ha sido activada correctamente. Ya puedes disfrutar de todos los beneficios.' 
              : 'تم تفعيل اشتراكك بنجاح. يمكنك الآن الاستمتاع بجميع المزايا.'}
          </p>

          <div className="bg-navy-dark rounded-xl p-4 mb-8 border border-navy-lighter text-left">
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">
              {language === 'es' ? 'Detalles del Pedido' : 'تفاصيل الطلب'}
            </h3>
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-300">Plan</span>
              <span className="font-bold text-white flex items-center gap-1">
                <Star className="w-3 h-3 text-cyan" /> {displayName}
              </span>
            </div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-300">Estado</span>
              <span className="text-green-400 text-sm font-bold bg-green-400/10 px-2 py-0.5 rounded">Activo</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Referencia</span>
              <span className="text-gray-500 text-xs font-mono">{sessionId ? sessionId.slice(-8) : 'REF-12345'}</span>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <button 
              onClick={() => navigate('/consultation')}
              className="w-full bg-cyan hover:bg-cyan-dark text-white font-bold py-3 px-6 rounded-xl transition-all shadow-lg shadow-cyan/20 flex items-center justify-center gap-2"
            >
              {language === 'es' ? 'Ir al Panel' : 'الذهاب إلى اللوحة'} <ArrowRight className="w-5 h-5" />
            </button>
            
            <button 
              className="w-full bg-transparent hover:bg-navy-dark border border-navy-lighter text-gray-300 font-medium py-3 px-6 rounded-xl transition-all flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" /> {language === 'es' ? 'Descargar Recibo' : 'تحميل الإيصال'}
            </button>
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
};

export default SubscriptionSuccess;