import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, Video, CreditCard, Calendar, Download } from 'lucide-react';
import { useConsultationSession } from '@/hooks/useConsultationSession';
import StripePaymentButton from '@/components/StripePaymentButton';
import SimpleCitaBooking from '@/components/SimpleCitaBooking';
import DocumentDownloadSimple from '@/components/DocumentDownloadSimple';
import GestoriaHeader from '@/components/GestoriaHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const SimplifiedConsultationPage = () => {
  const { messages, sendMessage, loading, currentUser } = useConsultationSession();
  const [inputText, setInputText] = useState('');
  const [showBooking, setShowBooking] = useState(false);
  const [showDownloads, setShowDownloads] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    sendMessage(inputText);
    setInputText('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
      <GestoriaHeader />

      <main className="flex-1 container mx-auto px-4 py-6 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-140px)] min-h-[600px]">
          
          {/* LEFT: Avatar & Actions (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            
            {/* Avatar Video Area */}
            <div className="relative aspect-square md:aspect-video lg:aspect-[4/5] bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-800">
              <img 
                src="https://horizons-cdn.hostinger.com/dc07b744-3307-4fab-9206-a9836a6198f5/b81cb6670d37e89b69e5796d550762bf.jpg" 
                alt="Miriam AI Consultant" 
                className="w-full h-full object-cover opacity-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="flex items-center gap-2 mb-1">
                   <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                   <span className="text-xs font-mono text-green-400">ONLINE</span>
                </div>
                <h2 className="text-xl font-bold">Miriam AI</h2>
                <p className="text-sm text-slate-300">Especialista en Extranjería</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid gap-3">
              <StripePaymentButton clienteId={currentUser?.id} />
              
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  onClick={() => setShowBooking(true)}
                  className="bg-slate-800 hover:bg-slate-700 text-white h-14 rounded-xl flex items-center justify-center gap-2"
                >
                  <Calendar className="w-5 h-5 text-cyan" />
                  Buscar Cita
                </Button>
                <Button 
                  onClick={() => setShowDownloads(true)}
                  className="bg-slate-800 hover:bg-slate-700 text-white h-14 rounded-xl flex items-center justify-center gap-2"
                >
                  <Download className="w-5 h-5 text-cyan" />
                  Descargar Docs
                </Button>
              </div>
            </div>

          </div>

          {/* RIGHT: Chat Interface (7 cols) */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col overflow-hidden shadow-xl">
            {/* Chat Header */}
            <div className="p-4 border-b border-slate-800 bg-slate-950/50 flex justify-between items-center">
               <h3 className="text-white font-bold flex items-center gap-2">
                 <Video className="w-4 h-4 text-cyan" />
                 Chat en Vivo
               </h3>
               <span className="text-xs text-slate-500">Gestoria Cita IA v2.0</span>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
              {messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === 'me' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'me' 
                      ? 'bg-cyan text-navy font-medium rounded-tr-sm' 
                      : 'bg-slate-800 text-slate-200 rounded-tl-sm border border-slate-700'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-slate-800 text-slate-400 p-3 rounded-2xl rounded-tl-sm text-xs flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{animationDelay: '0ms'}} />
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}} />
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}} />
                  </div>
                </div>
              )}
            </div>

            {/* Input Area */}
            <div className="p-4 bg-slate-950 border-t border-slate-800">
              <div className="flex gap-2">
                <Input
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Escribe tu consulta aquí..."
                  className="bg-slate-900 border-slate-700 text-white placeholder:text-slate-500"
                />
                <Button 
                  onClick={handleSend}
                  disabled={!inputText.trim() || loading}
                  className="bg-cyan hover:bg-cyan/90 text-navy w-12 px-0"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>

        </div>
      </main>

      {/* Modals */}
      {showBooking && (
        <SimpleCitaBooking 
          clienteId={currentUser?.id} 
          onClose={() => setShowBooking(false)} 
        />
      )}
      
      {showDownloads && (
        <DocumentDownloadSimple 
          clienteId={currentUser?.id} 
          onClose={() => setShowDownloads(false)} 
        />
      )}

    </div>
  );
};

export default SimplifiedConsultationPage;