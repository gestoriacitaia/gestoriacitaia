// INSTRUCTIONS FOR USERS: To see the updated subscription plans, please clear your browser cache (Ctrl+Shift+Delete or Cmd+Shift+Delete) and do a hard refresh (Ctrl+F5 or Cmd+Shift+R).

import React, { useEffect } from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { LanguageProvider } from './contexts/LanguageContext';
import { PaymentProvider } from './contexts/PaymentContext';
import { AvatarSystemProvider } from './contexts/AvatarSystemContext';
import { AuthProvider } from './contexts/SupabaseAuthContext'; 
import { ConsentProvider } from './contexts/ConsentContext'; 
import { GoogleAuthProvider } from './contexts/GoogleAuthContext';
import ScrollToTop from './components/ScrollToTop';
import GestoriaLandingPage from './pages/GestoriaLandingPage';
import ConsultationPage from './pages/ConsultationPage';
import ImmigrationAssistantPage from './pages/ImmigrationAssistantPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import LegalNoticePage from './pages/LegalNoticePage';
import CookiesPolicyPage from './pages/CookiesPolicyPage';
import { Toaster } from './components/ui/toaster';
import StripeCheckout from './components/payment/StripeCheckout';
import BuscarCitaCheckout from './components/BuscarCitaCheckout';
import AppointmentConfirmation from './components/AppointmentConfirmation';
import SubscriptionCheckout from './pages/SubscriptionCheckout';
import SubscriptionSuccess from './pages/SubscriptionSuccess';
import SubscriptionCancelled from './pages/SubscriptionCancelled';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import ClientProfile from './pages/ClientProfile';
import ProtectedRoute from './components/ProtectedRoute';
import { paymentDebugService } from './services/paymentDebugService';
import ConsentModal from './components/ConsentModal'; 
import AvatarChatComponent from '@/components/AvatarChatComponent';
import EnhancedAvatarChatComponent from '@/components/EnhancedAvatarChatComponent';
import ReferralRedirect from '@/components/ReferralRedirect';

function App() {
  
  useEffect(() => {
    paymentDebugService.logSystemStatus();
  }, []);

  return (
    <AuthProvider>
      <GoogleAuthProvider>
        <LanguageProvider>
          <PaymentProvider>
            <AvatarSystemProvider>
              <ConsentProvider>
                <Router>
                  <ScrollToTop />
                  <div className="min-h-screen bg-sky-bg font-sans text-navy">
                    <Routes>
                      {/* Public Routes */}
                      <Route path="/" element={<GestoriaLandingPage />} />
                      <Route path="/consultation" element={<ConsultationPage />} />
                      <Route path="/immigration-assistant" element={<ImmigrationAssistantPage />} />
                      
                      {/* Auth Routes */}
                      <Route path="/login" element={<LoginPage />} />
                      <Route path="/signup" element={<SignupPage />} />
                      <Route path="/ref/:code" element={<ReferralRedirect />} />
                      
                      {/* Protected Routes */}
                      <Route path="/profile" element={
                        <ProtectedRoute>
                          <ClientProfile />
                        </ProtectedRoute>
                      } />

                      {/* Legal Routes */}
                      <Route path="/legal-notice" element={<LegalNoticePage />} />
                      <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
                      <Route path="/cookies-policy" element={<CookiesPolicyPage />} />

                      {/* Payment Routes */}
                      <Route path="/stripe-checkout" element={<StripeCheckout />} />
                      <Route path="/buscar-cita-checkout" element={<BuscarCitaCheckout />} />
                      <Route path="/appointment-confirmation" element={<AppointmentConfirmation />} />
                      
                      {/* Subscription Routes */}
                      <Route path="/subscription-checkout" element={<SubscriptionCheckout />} />
                      <Route path="/subscription-success" element={<SubscriptionSuccess />} />
                      <Route path="/subscription-cancelled" element={<SubscriptionCancelled />} />
                      
                      {/* Avatar Chat Routes */}
                      <Route path="/avatar-chat" element={<AvatarChatComponent />} />
                      <Route path="/enhanced-avatar-chat" element={<EnhancedAvatarChatComponent />} />
                    </Routes>
                    <Toaster />
                    <ConsentModal />
                  </div>
                </Router>
              </ConsentProvider>
            </AvatarSystemProvider>
          </PaymentProvider>
        </LanguageProvider>
      </GoogleAuthProvider>
    </AuthProvider>
  );
}

export default App;