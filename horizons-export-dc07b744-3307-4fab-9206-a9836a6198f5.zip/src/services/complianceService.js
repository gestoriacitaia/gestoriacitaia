import { supabase } from '@/lib/supabaseClient';

/**
 * Compliance Service for GestoríaCitaIA
 * Enforces RGPD, prevents illegal requests, and validates inputs.
 */

const ILLEGAL_KEYWORDS = [
  'comprar cita', 'cita falsa', 'documento falso', 'soborno', 'pagar funcionario',
  'garantizar aprobación', 'sin papeles', 'saltar cola', 'hackear',
  'chri cita', 'tazwir', 'rachwa', 'bla wra9' // Darija/Arabic phonetic keywords
];

const RGPD_DISCLAIMER = "Khasna lmofaqa dyalek 3la RGPD bach n3aljo lma3loumat dyalek. Hna kan7tarmo lkhososya dyalek 100%.";
const ILLEGAL_RESPONSE = "Ma nqdarsh n3awnk f had talab 7it kaykhalef l qanon. Hna kanzawlo lkhadma dyalna b tariqa qanonya 100%.";

export const complianceService = {
  /**
   * Validate user input against illegal keywords
   */
  validateInput: (text) => {
    const lowerText = text.toLowerCase();
    const hasIllegalContent = ILLEGAL_KEYWORDS.some(keyword => lowerText.includes(keyword));
    
    if (hasIllegalContent) {
      return {
        isValid: false,
        message: ILLEGAL_RESPONSE
      };
    }
    return { isValid: true };
  },

  /**
   * Check if user has consented to RGPD
   */
  checkRgpdConsent: (userData) => {
    if (!userData?.hasConsented) {
      return {
        isValid: false,
        message: RGPD_DISCLAIMER
      };
    }
    return { isValid: true };
  },

  /**
   * Encrypt sensitive data (Conceptual implementation for frontend)
   * In production, use Supabase Encryption/Edge Functions
   */
  encryptSensitiveData: (data) => {
    // Conceptual placeholder - real encryption happens server-side or via robust library
    return btoa(JSON.stringify(data)); 
  },

  /**
   * Log compliance event (e.g., blocked request)
   */
  logComplianceEvent: async (userId, eventType, details) => {
    console.warn(`Compliance Event [${eventType}]:`, details);
    if (supabase) {
      await supabase.from('compliance_logs').insert({
        user_id: userId,
        event_type: eventType,
        details: details,
        created_at: new Date().toISOString()
      });
    }
  }
};