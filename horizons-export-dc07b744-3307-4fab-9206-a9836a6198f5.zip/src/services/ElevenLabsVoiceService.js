import axios from 'axios';

class ElevenLabsVoiceService {
  constructor() {
    this.apiKey = import.meta.env.VITE_ELEVENLABS_API_KEY;
    this.baseUrl = 'https://api.elevenlabs.io/v1';
    // Example Voice IDs - these should be replaced with real IDs that support multilingual
    this.voices = {
      es: 'pNInz6obpgDQGcFmaJgB', // Adam (Good generic male)
      ar: 'VR6AewGX3Rex9jLeOSn3', // Example voice that might handle Arabic better
    };
  }

  async generateVoice(text, language = 'es') {
    const voiceId = language === 'es' ? this.voices.es : this.voices.ar;
    
    try {
      const response = await axios({
        method: 'post',
        url: `${this.baseUrl}/text-to-speech/${voiceId}/stream`,
        data: {
          text: text,
          model_id: "eleven_multilingual_v2", // Supports both Spanish and Arabic/Darija better
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75
          }
        },
        headers: {
          'Accept': 'audio/mpeg',
          'xi-api-key': this.apiKey,
          'Content-Type': 'application/json',
        },
        responseType: 'blob'
      });

      return response.data;
    } catch (error) {
      console.error('ElevenLabs Error:', error);
      throw error;
    }
  }
}

export const elevenLabsVoiceService = new ElevenLabsVoiceService();