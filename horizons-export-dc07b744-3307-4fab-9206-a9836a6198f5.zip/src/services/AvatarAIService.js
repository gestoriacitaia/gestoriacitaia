import OpenAI from 'openai';

class AvatarAIService {
  constructor() {
    this.openai = new OpenAI({
      apiKey: import.meta.env.VITE_OPENAI_API_KEY,
      dangerouslyAllowBrowser: true 
    });
    this.history = [];
  }

  detectLanguage(text) {
    // Simple heuristic or could use GPT. For hybrid Darija/Spanish, we assume Spanish default unless Arabic chars or specific keywords found.
    // Darija often uses Latin characters with numbers (3, 7, 9) or Arabic script.
    const arabicPattern = /[\u0600-\u06FF]/;
    const darijaNumbers = /[379]/; 
    
    if (arabicPattern.test(text)) return 'ar'; // Arabic Script Darija
    // Heuristic: If it looks like "shouf 3afak", it's Darija (Latin). 
    // This is a simplified check.
    if (darijaNumbers.test(text) && !text.includes('€')) return 'darija-latin'; 
    
    return 'es'; // Default to Spanish
  }

  async getAvatarResponse(userText, detectedLang = 'es') {
    try {
      const systemPrompt = `You are a helpful immigration lawyer assistant for Spain. 
      You speak two languages: Spanish (Castellano) and Moroccan Darija.
      The user is speaking in: ${detectedLang === 'ar' || detectedLang === 'darija-latin' ? 'Moroccan Darija' : 'Spanish'}.
      Reply in the SAME language as the user.
      Keep your answers concise (under 2 sentences) for real-time conversation.
      If speaking Darija, use Latin script with numbers if the user did, or Arabic script if the user used Arabic.`;

      const messages = [
        { role: 'system', content: systemPrompt },
        ...this.history.slice(-4), // Keep last 4 turns for context
        { role: 'user', content: userText }
      ];

      const completion = await this.openai.chat.completions.create({
        messages: messages,
        model: 'gpt-4o', // or gpt-3.5-turbo
      });

      const responseText = completion.choices[0].message.content;

      // Update history
      this.history.push({ role: 'user', content: userText });
      this.history.push({ role: 'assistant', content: responseText });

      return {
        text: responseText,
        language: detectedLang
      };
    } catch (error) {
      console.error('OpenAI Error:', error);
      return { text: "Lo siento, hubo un error de conexión.", language: 'es' };
    }
  }

  // Helper to clear history for new sessions
  resetSession() {
    this.history = [];
  }
}

export const avatarAIService = new AvatarAIService();