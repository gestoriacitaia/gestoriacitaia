import { supabase } from '@/lib/supabaseClient';

class ConsultationSessionRecorder {
  constructor() {
    this.queue = [];
    this.batchInterval = null;
    this.sessionId = null;
    this.clienteId = null;
    this.citaId = null;
    this.avatarId = null;
    this.startTime = null;
  }

  init(clienteId, citaId, avatarId) {
    this.clienteId = clienteId;
    this.citaId = citaId;
    this.avatarId = avatarId;
    this.startTime = new Date();
    this.queue = [];
    
    // Start Batch Saver
    this.batchInterval = setInterval(() => this.saveBatch(), 30000); // 30s
  }

  addInteraction(userText, avatarText) {
    this.queue.push({
      transcripcion: userText,
      respuesta_avatar: avatarText,
      fecha_inicio: new Date().toISOString(), // Approx
      fecha_fin: new Date().toISOString(),
      duracion_segundos: 0 
    });
  }

  async saveBatch() {
    if (this.queue.length === 0) return;

    const batch = [...this.queue];
    this.queue = []; // Clear queue

    try {
      const { error } = await supabase
        .from('tabla_sesiones_avatar')
        .insert(batch.map(item => ({
          cliente_id: this.clienteId,
          cita_id: this.citaId,
          avatar_id: this.avatarId,
          ...item
        })));

      if (error) console.error("Session Save Error:", error);
    } catch (e) {
      console.error("Batch Save Exception:", e);
      // Re-queue on failure? simpler to just log for now to avoid duplicates
    }
  }

  async finalize() {
    clearInterval(this.batchInterval);
    await this.saveBatch(); // Save remaining
  }
}

export const consultationSessionRecorder = new ConsultationSessionRecorder();