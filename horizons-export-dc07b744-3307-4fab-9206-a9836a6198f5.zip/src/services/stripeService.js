import { paymentDebugService } from './paymentDebugService';

/**
 * Consultation plan configurations
 */
export const CONSULTATION_PLANS = {
  basic: {
    id: 'basic',
    name: { es: 'Plan Básico', ar: 'الخطة الأساسية' },
    price: 9.99,
    currency: 'EUR',
    duration: 15,
    features: {
      es: ['15 min Consulta', 'Dudas Extranjería', 'Chat IA'],
      ar: ['استشارة 15 دقيقة', 'أسئلة الهجرة', 'دردشة الذكاء الاصطناعي']
    }
  },
  standard: {
    id: 'standard',
    name: { es: 'Plan Estándar', ar: 'الخطة القياسية' },
    price: 19.99,
    currency: 'EUR',
    duration: 30,
    features: {
      es: ['Verificación Docs', 'Revisión NIE/Pasaporte', '3 Consultas/mes'],
      ar: ['التحقق من الوثائق', 'مراجعة NIE / جواز السفر', '3 استشارات / شهر']
    }
  },
  pro: {
    id: 'pro',
    name: { es: 'Plan Pro', ar: 'خطة المحترفين' },
    price: 29.99,
    currency: 'EUR',
    duration: 60,
    features: {
      es: ['Cita Extranjería', 'Gestión Completa', 'Soporte Prioritario'],
      ar: ['موعد الهجرة', 'إدارة كاملة', 'دعم ذو أولوية']
    }
  }
};

/**
 * Create checkout session for consultation plan
 */
export const createConsultationCheckout = async (planId, customerData) => {
  // 1. Log Start
  paymentDebugService.logStep('StripeService', 'createConsultationCheckout initiated', { 
    planId, 
    customerEmail: customerData.email,
    timestamp: new Date().toISOString()
  });

  const plan = CONSULTATION_PLANS[planId];
  
  // 2. Validate Plan
  if (!plan) {
    const error = new Error(`Invalid plan ID: ${planId}`);
    paymentDebugService.logError('StripeService:Validation', error);
    throw error;
  }

  try {
    // 3. Prepare Payload (In a real app, this goes to backend)
    const payload = {
      planId: plan.id,
      amount: plan.price * 100, // cents
      currency: plan.currency,
      customerEmail: customerData.email,
      metadata: {
        customerName: customerData.name || 'Guest',
        phone: customerData.phone,
        planType: plan.id,
        consultationType: 'immigration',
        env: import.meta.env.MODE
      }
    };

    paymentDebugService.logStep('StripeService', 'Simulating Backend Session Creation', payload);

    // 4. MOCK API Call
    // Since we don't have a backend in this environment, we mock the session creation
    // This allows the frontend to proceed as if a real session was created
    const mockSession = await new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: `cs_test_${Math.random().toString(36).substr(2, 9)}`,
          url: `${window.location.origin}/consultation?session_id=cs_test_mock_${Date.now()}&payment=success`,
          status: 'open'
        });
      }, 1500);
    });

    // 5. Validate Response
    if (!mockSession || !mockSession.url) {
        const err = new Error('Received invalid session response from payment provider');
        paymentDebugService.logError('StripeService:InvalidResponse', err, mockSession);
        throw err;
    }

    // 6. Log Success
    paymentDebugService.logStep('StripeService', 'Session Created Successfully', {
      sessionId: mockSession.id,
      url: mockSession.url
    });

    return mockSession;

  } catch (error) {
    // 7. Log Error
    paymentDebugService.logError('StripeService:CreateSession', error);
    
    // Re-throw with user-friendly message
    throw new Error(error.message || 'Failed to initialize payment session. Please try again.');
  }
};

/**
 * Verify payment session status
 */
export const verifyPaymentSession = async (sessionId) => {
  try {
    paymentDebugService.logStep('StripeService', 'Verifying Session', { sessionId });
    
    // Simulation: In a real app, verify with backend
    if (!sessionId) {
      throw new Error('No session ID provided');
    }

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const result = {
      verified: true,
      planId: 'basic', // Defaulting to basic for simulation if not stored
      sessionId,
      status: 'paid',
      timestamp: new Date().toISOString()
    };

    paymentDebugService.logStep('StripeService', 'Session Verified', result);
    return result;

  } catch (error) {
    paymentDebugService.logError('StripeService:Verify', error);
    return { verified: false, error: error.message };
  }
};

export const getPlanDetails = (planId, language = 'es') => {
  const plan = CONSULTATION_PLANS[planId];
  if (!plan) return null;

  return {
    id: plan.id,
    name: plan.name[language],
    price: plan.price,
    currency: plan.currency,
    duration: plan.duration,
    features: plan.features[language],
  };
};

export default {
  CONSULTATION_PLANS,
  createConsultationCheckout,
  verifyPaymentSession,
  getPlanDetails,
};