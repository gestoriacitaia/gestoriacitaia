import { supabase } from '@/lib/supabaseClient';
import { complianceService } from './complianceService';

/**
 * OpenAI Service for Immigration Consultation
 * Enhanced for Moroccan Darija and specific Avatar personas.
 */

const AVATAR_PERSONAS = {
  khalid: {
    role: "Expert in Arraigo and Residence",
    systemPrompt: `You are Khalid, an expert immigration lawyer specialized in 'Arraigo' and 'Residencia'. 
    Speak in Moroccan Darija mixed with Spanish legal terms. 
    Tone: Professional, empathetic, clear.
    Greeting: "Salam, marhba bik f GestoríaCitaIA. Ana Khalid, n3awnk f arraigo w residencia."`,
  },
  miriam: {
    role: "Expert in Documentation and Family Reunification",
    systemPrompt: `You are Miriam, specialized in verifying documents and family procedures.
    Speak in Moroccan Darija. Focus on document checklists and validity.
    Tone: Precise, organized, helpful.
    Greeting: "Salam, ana Miriam. Aji nchoufo lwraq dyalek wach mzyanin."`,
  },
  mohammad: {
    role: "Expert in Appointments (Citas) and Nationality",
    systemPrompt: `You are Mohammad, guiding users to find appointments (Citas).
    Speak in Moroccan Darija. NEVER promise an appointment. Guide them to official sites.
    Tone: Encouraging, realistic.
    Greeting: "Salam, ana Mohammad. Lqya d cita s3iba, walakin nwerrik triq."`,
  }
};

const MOCK_DARIJA_RESPONSES = {
  khalid: "Bach dir l'arraigo social, khassk tkoun 3aych f España 3 snin w 3andek contrat dyal lkhadma. (Respuesta simulada Khalid)",
  miriam: "Sifet lia l'passport dyalek w shahadat sakan bach nverifiehom lik. (Respuesta simulada Miriam)",
  mohammad: "Dkhol l site dyal extranjería kl 8 d sbah. Ila ma lqitich, dir alert f WhatsApp 3andna. (Respuesta simulada Mohammad)"
};

/**
 * Get immigration advice with persona context
 */
export const getImmigrationAdvice = async (userMessage, language = 'es', avatarId = 'khalid', documentContext = []) => {
  
  // 1. Compliance Check
  const compliance = complianceService.validateInput(userMessage);
  if (!compliance.isValid) {
    return {
      text: compliance.message,
      metadata: { isBlocked: true }
    };
  }

  // 2. Try Supabase Edge Function
  if (supabase) {
    try {
      const { data, error } = await supabase.functions.invoke('chat-with-openai', {
        body: {
          message: userMessage,
          language, // Expecting 'darija' or 'es'
          avatarId,
          systemPrompt: AVATAR_PERSONAS[avatarId]?.systemPrompt,
          documentContext
        }
      });

      if (!error && data) {
        return {
          text: data.reply,
          metadata: {
            language,
            avatarId,
            timestamp: new Date().toISOString(),
            isMock: false
          }
        };
      }
    } catch (error) {
      console.error('Supabase OpenAI call failed:', error);
    }
  }

  // 3. Mock Fallback (Darija)
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  let responseText = MOCK_DARIJA_RESPONSES[avatarId] || "Sem7ilia, ma fhamtch mzian. 3awed swel b tariqa okhra.";
  
  // Simple keyword detection for better mock
  if (userMessage.toLowerCase().includes('arraigo')) responseText = MOCK_DARIJA_RESPONSES.khalid;
  if (userMessage.toLowerCase().includes('cita')) responseText = MOCK_DARIJA_RESPONSES.mohammad;
  if (userMessage.toLowerCase().includes('document') || userMessage.toLowerCase().includes('wraq')) responseText = MOCK_DARIJA_RESPONSES.miriam;

  return {
    text: responseText,
    metadata: {
      language,
      avatarId,
      timestamp: new Date().toISOString(),
      isMock: true
    }
  };
};

export const isImmigrationRelated = (question) => {
  const keywords = [
    'visa', 'nie', 'residencia', 'arraigo', 'extranjería', 'pasaporte',
    'cita', 'cita previa', 'nacionalidad', 'empadronamiento', 'wraq', 'lwraq',
    'tamen', 'khadma', 'contrato'
  ];
  return keywords.some(k => question.toLowerCase().includes(k));
};

export const identifyTramite = (text) => {
  const lower = text.toLowerCase();
  if (lower.includes('arraigo')) return 'arraigo';
  if (lower.includes('nacionalidad')) return 'nacionalidad';
  if (lower.includes('cita')) return 'cita';
  return 'general';
};

export default {
  getImmigrationAdvice,
  isImmigrationRelated,
  identifyTramite,
  AVATAR_PERSONAS
};