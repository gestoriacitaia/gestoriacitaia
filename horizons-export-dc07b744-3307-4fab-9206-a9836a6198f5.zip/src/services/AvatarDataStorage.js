import { supabase } from '@/lib/supabaseClient';

/**
 * Avatar Data Storage Service
 * Manages persistence for avatar interactions.
 */

export const saveAvatarSession = async (userId, avatarId, mode) => {
  if (!supabase) return null;
  
  try {
    const { data, error } = await supabase
      .from('avatar_sessions')
      .insert({
        user_id: userId,
        avatar_id: avatarId,
        mode: mode,
        started_at: new Date().toISOString()
      })
      .select()
      .single();
      
    if (error) throw error;
    return data;
  } catch (err) {
    console.error('Error saving avatar session:', err);
    return null;
  }
};

export const logInteraction = async (sessionId, role, content) => {
  if (!supabase) return;

  try {
    await supabase.from('user_interactions').insert({
      session_id: sessionId,
      role,
      content,
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    console.error('Error logging interaction:', err);
  }
};

export const saveDocumentVerification = async (userId, docType, status, metadata) => {
  if (!supabase) return;

  try {
    await supabase.from('document_verifications').insert({
      user_id: userId,
      document_type: docType,
      status,
      metadata, // Encrypted fields would be handled here in a real backend
      verified_at: new Date().toISOString()
    });
  } catch (err) {
    console.error('Error saving verification:', err);
  }
};

export default {
  saveAvatarSession,
  logInteraction,
  saveDocumentVerification
};