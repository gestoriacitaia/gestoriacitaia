import { avatarAIService } from './AvatarAIService';
import { elevenLabsVoiceService } from './ElevenLabsVoiceService';
import { didVideoService } from './DIDVideoService';
import { realTimeAudioProcessor } from './RealTimeAudioProcessor';
import { conversationStorageService } from './ConversationStorageService';

class AvatarIntegrationOrchestrator {
  
  constructor() {
    this.sessionId = null;
  }

  async initSession(avatarId) {
    this.sessionId = crypto.randomUUID();
    avatarAIService.resetSession();
    // In real app, we would initialize D-ID connection here
    // await didVideoService.connectAvatar(videoElement, avatarId);
    
    // Log session start
    await conversationStorageService.saveAvatarSession({
      avatarId,
      language: 'detecting',
      duration: 0
    });
  }

  async processUserInteraction(statusCallback) {
    try {
      // 1. Stop Listening & Transcribe
      statusCallback('processing');
      const { text: userText } = await realTimeAudioProcessor.stopListening();
      
      if (!userText || userText.trim().length === 0) {
        statusCallback('idle');
        return null;
      }

      console.log("User said:", userText);

      // 2. Detect Language & Get AI Response
      const detectedLang = avatarAIService.detectLanguage(userText);
      const aiResponse = await avatarAIService.getAvatarResponse(userText, detectedLang);
      
      console.log("AI Replied:", aiResponse.text);

      // 3. Save to DB
      await conversationStorageService.saveConversation({
        userMessage: userText,
        avatarResponse: aiResponse.text,
        language: detectedLang,
        sessionId: this.sessionId
      });

      // 4. Generate Voice
      statusCallback('speaking');
      const audioBlob = await elevenLabsVoiceService.generateVoice(aiResponse.text, detectedLang);
      const audioUrl = URL.createObjectURL(audioBlob);

      // 5. Play Audio & Animate
      // For this demo, we play audio directly. In full D-ID, we'd send audio to D-ID.
      // didVideoService.animateAvatar(audioUrl); // Conceptual
      
      const audio = new Audio(audioUrl);
      await audio.play();
      
      audio.onended = () => {
        statusCallback('idle');
      };

      return {
        userText,
        aiText: aiResponse.text,
        language: detectedLang
      };

    } catch (error) {
      console.error("Orchestration Error:", error);
      statusCallback('error');
      return null;
    }
  }
}

export const avatarOrchestrator = new AvatarIntegrationOrchestrator();