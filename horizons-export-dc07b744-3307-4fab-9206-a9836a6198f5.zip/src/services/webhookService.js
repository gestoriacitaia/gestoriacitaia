// NOTE: This service acts as a client-side bridge to your automation backend (e.g., Make.com).

const API_BASE = import.meta.env.VITE_MAKE_WEBHOOK_URL || 'https://hook.make.com/your-webhook-id';

export const webhookService = {
  // ... existing methods ...

  async notifyPaymentSuccess(paymentData) {
    try {
      const response = await fetch(`${API_BASE}/payment-success`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(paymentData),
      });
      return await response.json();
    } catch (error) {
      console.error('Webhook Error (Payment Success):', error);
      // Non-blocking error for frontend flow
      return { success: true }; 
    }
  },

  async createCheckoutSession(data) {
    try {
      const response = await fetch(`${API_BASE}/create-checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!import.meta.env.VITE_MAKE_WEBHOOK_URL) {
        console.warn('Simulating Checkout Session (No Webhook URL provided)');
        // Simulate redirect to our internal success route for demo
        // Append query params to simulate Stripe return
        const returnUrl = data.successUrl || '#demo-success';
        return { url: returnUrl }; 
      }

      return await response.json();
    } catch (error) {
      console.error('Webhook Error (Create Checkout):', error);
      return { url: data.successUrl || '#demo-success' }; 
    }
  },

  // NEW METHODS FOR BUSCAR CITA FLOW

  async sendWhatsAppNotification(data) {
    try {
      // data: { phone, name, appointmentDate, appointmentTime, serviceType, confirmationLink }
      const response = await fetch(`${API_BASE}/send-whatsapp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      return await response.json();
    } catch (error) {
      console.error('Webhook Error (WhatsApp):', error);
      // Simulate success for demo
      return { success: true };
    }
  },

  async saveAppointment(data) {
    try {
      const response = await fetch(`${API_BASE}/save-appointment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      return await response.json();
    } catch (error) {
      console.error('Webhook Error (Save Appointment):', error);
      return { success: true };
    }
  },

  async sendConfirmationEmail(data) {
    try {
      const response = await fetch(`${API_BASE}/send-email-confirmation`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      return await response.json();
    } catch (error) {
      console.error('Webhook Error (Email):', error);
      return { success: true };
    }
  }
};