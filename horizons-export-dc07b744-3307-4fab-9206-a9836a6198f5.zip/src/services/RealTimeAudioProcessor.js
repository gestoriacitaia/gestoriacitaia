import OpenAI from 'openai';

class RealTimeAudioProcessor {
  constructor() {
    this.openai = new OpenAI({
      apiKey: import.meta.env.VITE_OPENAI_API_KEY,
      dangerouslyAllowBrowser: true
    });
    this.mediaRecorder = null;
    this.audioChunks = [];
  }

  async startListening() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.mediaRecorder = new MediaRecorder(stream);
      this.audioChunks = [];

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) this.audioChunks.push(event.data);
      };

      this.mediaRecorder.start();
      return true;
    } catch (error) {
      console.error("Mic Access Error:", error);
      throw error;
    }
  }

  async stopListeningAndTranscribe() {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        resolve(null);
        return;
      }

      this.mediaRecorder.onstop = async () => {
        try {
          const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
          
          const file = new File([audioBlob], "speech.webm", { type: "audio/webm" });
          
          const response = await this.openai.audio.transcriptions.create({
            file,
            model: "whisper-1",
            language: "es", // Prioritize Spanish
            response_format: "verbose_json"
          });

          resolve({
            text: response.text,
            confidence: response.task === 'transcribe' ? 0.9 : 0.5, // Simplified confidence
            language: response.language
          });

        } catch (error) {
          console.error("Transcription Error:", error);
          reject(error);
        }
      };

      this.mediaRecorder.stop();
      this.mediaRecorder.stream.getTracks().forEach(t => t.stop());
    });
  }
}

export const realTimeAudioProcessor = new RealTimeAudioProcessor();