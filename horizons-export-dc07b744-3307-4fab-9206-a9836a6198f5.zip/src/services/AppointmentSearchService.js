import axios from 'axios';

class AppointmentSearchService {
  constructor() {
    this.webhookUrl = import.meta.env.VITE_MAKE_WEBHOOK_URL || 'https://hook.make.com/your-appointment-webhook-id';
  }

  async searchAppointments(params) {
    const { province, procedure, datePreference } = params;

    try {
      console.log(`[Mock] Searching appointments via Make.com for ${province} - ${procedure}`);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Mock Results
      const mockSlots = [
        {
          id: 'slot_1',
          date: '2024-03-15',
          time: '09:00',
          location: 'Oficina de Extranjería, Calle Silva 19',
          status: 'available'
        },
        {
          id: 'slot_2',
          date: '2024-03-16',
          time: '11:30',
          location: 'Oficina de Extranjería, Av. Plaza de Toros',
          status: 'available'
        }
      ];

      return {
        found: true,
        slots: mockSlots,
        searchId: `search_${Date.now()}`
      };

    } catch (error) {
      console.error("Appointment Search Error:", error);
      return {
        found: false,
        message: "Service unavailable temporarily."
      };
    }
  }
}

export const appointmentSearchService = new AppointmentSearchService();