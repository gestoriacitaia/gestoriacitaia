/**
 * Payment Debug Service
 * Centralized utility for validating payment configurations and logging payment flows.
 */

export const paymentDebugService = {
  /**
   * Validates if the Stripe configuration is present.
   * @returns {Object} { isValid, missingKeys, environment }
   */
  validateStripeConfig: () => {
    const publicKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY;
    const mode = import.meta.env.MODE;
    
    // Check if key is the placeholder or actually set
    const isPlaceholder = publicKey === 'pk_test_your_publishable_key_here';
    const isValid = !!publicKey && publicKey.length > 0 && !isPlaceholder;
    
    console.group('💳 Stripe Configuration Check');
    console.log('Environment:', mode);
    console.log('Public Key Present:', isValid ? '✅ Yes' : '❌ No/Placeholder');
    if (isValid) {
      console.log('Key Prefix:', publicKey.substring(0, 7) + '...');
    } else {
      console.warn('Using fallback or invalid key.');
    }
    console.groupEnd();

    return {
      isValid,
      publicKey,
      environment: mode
    };
  },

  /**
   * Logs a step in the payment flow with timestamp.
   * @param {string} stage - The stage name (e.g., 'Validation', 'API Call')
   * @param {string} message - Description of the action
   * @param {Object} data - Optional data to log
   */
  logStep: (stage, message, data = null) => {
    const timestamp = new Date().toISOString().split('T')[1].slice(0, -1); // HH:mm:ss.sss
    const logStyle = 'background: #2563eb; color: white; padding: 2px 5px; border-radius: 3px;';
    
    console.groupCollapsed(`%cPayment Flow [${timestamp}] - ${stage}`, logStyle);
    console.log('Message:', message);
    if (data) {
      console.log('Data:', data);
    }
    console.groupEnd();
  },

  /**
   * Formats and logs errors consistently.
   * @param {string} context - Where the error occurred
   * @param {Error} error - The error object
   */
  logError: (context, error) => {
    const logStyle = 'background: #dc2626; color: white; padding: 2px 5px; border-radius: 3px; font-weight: bold;';
    console.group(`%c❌ Payment Error: ${context}`, logStyle);
    console.error('Message:', error.message);
    console.error('Stack:', error.stack);
    if (error.response) {
      console.error('API Response:', error.response);
    }
    console.groupEnd();
    return {
      message: error.message || 'Unknown payment error',
      context
    };
  },

  /**
   * Logs the status of the payment system on app load.
   */
  logSystemStatus: () => {
    const config = paymentDebugService.validateStripeConfig();
    const style = config.isValid 
      ? 'background: #059669; color: white; padding: 4px 8px; border-radius: 4px; font-weight: bold;'
      : 'background: #f59e0b; color: black; padding: 4px 8px; border-radius: 4px; font-weight: bold;';
    
    console.log('%c Payment System Status ', style);
    if (!config.isValid) {
      console.warn('⚠️ Stripe Public Key is using fallback or missing. Payment forms will run in simulation mode.');
    } else {
      console.log('✅ Payment system configured and ready.');
    }
  }
};