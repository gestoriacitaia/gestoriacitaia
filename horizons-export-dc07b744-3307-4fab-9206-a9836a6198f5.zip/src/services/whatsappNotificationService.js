import { supabase } from '@/lib/supabaseClient';

/**
 * WhatsApp Notification Service
 * Manages appointment alerts and user opt-ins.
 */

const WHATSAPP_TEMPLATE = "Tenemos una cita disponible en tu provincia. Entra a cogerla y te ayudamos a llenarla.";
const DARIJA_TEMPLATE = "Kayna cita dispo f provincia dyalek. Dkhol daba bach n3awnouk t3amroha.";

export const whatsappNotificationService = {
  /**
   * Register user for WhatsApp notifications
   */
  registerForAlerts: async (userId, phoneNumber, province) => {
    console.log(`Registering ${phoneNumber} for alerts in ${province}`);
    
    // Store in localStorage for prototype
    const preferences = {
      userId,
      phoneNumber,
      province,
      optedIn: true,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('whatsapp_pref', JSON.stringify(preferences));

    // Store in Supabase if available
    if (supabase) {
      const { error } = await supabase
        .from('whatsapp_preferences')
        .upsert({ 
          user_id: userId, 
          phone_number: phoneNumber, 
          province, 
          opted_in: true 
        });
      
      if (error) throw error;
    }

    return { success: true, message: "T7adit nmra dyalek banja7. Ghadi nsiftolik message mnin tkon cita." };
  },

  /**
   * Simulate checking for appointments and sending alert
   */
  checkAndSendAlert: async (province) => {
    // Simulation logic
    const isAvailable = Math.random() > 0.7; // 30% chance of availability
    
    if (isAvailable) {
      console.log(`Sending WhatsApp alert to users in ${province}: ${DARIJA_TEMPLATE}`);
      // In real backend, trigger WhatsApp API here
      return { sent: true, message: DARIJA_TEMPLATE };
    }
    
    return { sent: false };
  }
};