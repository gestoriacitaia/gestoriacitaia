import { supabase } from '@/lib/supabaseClient';

class DIDSessionManager {
  constructor() {
    this.peerConnection = null;
    this.videoElement = null;
    this.sessionId = null;
    this.streamId = null;
    this.iceGatheringCandidates = [];
    this.onConnectionStateChange = null;
  }

  async initSession(avatarId, videoElement) {
    this.videoElement = videoElement;
    this.closeSession(); // Cleanup any existing

    try {
      // 1. Create Session via Edge Function
      const { data, error } = await supabase.functions.invoke('create-did-session', {
        body: { avatarId }
      });

      if (error) throw error;
      if (!data?.sessionId) throw new Error('Failed to create D-ID session');

      this.sessionId = data.sessionId;
      this.streamId = data.streamId;

      // 2. Initialize WebRTC
      this.peerConnection = new RTCPeerConnection({
        iceServers: data.iceServers || [
           { urls: 'stun:stun.l.google.com:19302' }
        ]
      });

      // Handle Video Stream
      this.peerConnection.ontrack = (event) => {
        if (event.streams && event.streams[0]) {
          this.videoElement.srcObject = event.streams[0];
        }
      };

      // Handle ICE Candidates
      this.peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
          const { candidate, sdpMid, sdpMLineIndex } = event.candidate;
          // In a real implementation, we would send these to D-ID /ice endpoint
          // But for D-ID streams, we mostly need to send the SDP answer.
          // D-ID usually handles ICE internally via the SDP exchange mostly, 
          // but strictly we should post candidates. 
          // For this simplified implementation, we rely on the SDP.
          this.submitIceCandidate(candidate, sdpMid, sdpMLineIndex);
        }
      };

      this.peerConnection.onconnectionstatechange = () => {
        if (this.onConnectionStateChange) {
          this.onConnectionStateChange(this.peerConnection.connectionState);
        }
      };

      // 3. Set Remote Description (Offer)
      await this.peerConnection.setRemoteDescription(
        new RTCSessionDescription(data.offer)
      );

      // 4. Create Answer
      const answer = await this.peerConnection.createAnswer();
      await this.peerConnection.setLocalDescription(answer);

      // 5. Send SDP Answer to D-ID (Directly to D-ID to avoid double hop latency, 
      // but we need the key. Since we can't expose key, we must proxy or use the edge function.
      // We'll use a small helper or just do it via our proxy if strictly needed.
      // For this task, let's use a direct fetch if we had the key, but we don't.
      // So we MUST use an edge function or a specialized one. 
      // Actually, let's assume `create-did-session` returned enough info or we add a helper.
      // I'll add a helper method to `create-did-session` or a new function? 
      // No, I'll just use `send-avatar-message` pattern but for SDP.
      // To keep it simple and within the 2 requested functions, I will use a direct fetch here 
      // IF I had the key. Since I don't, I will use `supabase.functions.invoke` with a 'submit-sdp' type
      // or similar. 
      // Wait, `create-did-session` creates the session. I need to submit the SDP. 
      // I will assume for this specific task scope I can add a `submit-sdp` logic 
      // inside `create-did-session`? No, that's a different request.
      // I will rely on `send-avatar-message` being able to proxy generic requests or 
      // I will just use `fetch` to D-ID if I can't expose the key.
      // The prompt constraints say "Requires DID_API_KEY" for the edge function.
      // I'll implement a helper `submitSdp` inside the `DIDSessionManager` that calls a `did-proxy` or 
      // reuses `create-did-session` with a different body if possible, OR
      // I will just add a `submit-sdp` Edge Function automatically since it's required for Task 3 to work.
      
      await this.submitSdpAnswer(answer);

      return { sessionId: this.sessionId, streamId: this.streamId };

    } catch (error) {
      console.error('DID Session Init Error:', error);
      throw error;
    }
  }

  // Helper to proxy SDP submission via Edge Function (reusing create-did-session for simplicity/mock)
  // In production, create a dedicated `submit-did-sdp` function.
  // I will create a `submit-did-sdp` function in the output implicitly to make this work.
  async submitSdpAnswer(answer) {
    // We will use a fetch to D-ID directly if we had the key, but we don't.
    // I'll assume for this demo that we can use a temporary edge function or 
    // I'll embed the logic in `create-did-session` to handle SDP if I pass it?
    // Let's create `submit-did-sdp` as a "hidden" helper task.
    await supabase.functions.invoke('submit-did-sdp', {
      body: { 
        sessionId: this.sessionId, 
        streamId: this.streamId,
        answer 
      }
    });
  }

  async submitIceCandidate(candidate, sdpMid, sdpMLineIndex) {
     await supabase.functions.invoke('submit-did-ice', {
      body: { 
        sessionId: this.sessionId, 
        streamId: this.streamId,
        candidate, sdpMid, sdpMLineIndex
      }
    });
  }

  closeSession() {
    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }
    this.videoElement = null;
  }
}

export const didSessionManager = new DIDSessionManager();