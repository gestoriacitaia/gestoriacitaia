import OpenAI from 'openai';

class AvatarResponseEngine {
  constructor() {
    this.openai = new OpenAI({
      apiKey: import.meta.env.VITE_OPENAI_API_KEY,
      dangerouslyAllowBrowser: true
    });

    this.personas = {
      miriam: {
        name: "Miriam",
        system: "You are Miriam, a professional immigration lawyer specializing in Spanish documentation. You are helpful, precise, and reassuring. Speak clearly in Spanish.",
      },
      mohammad: {
        name: "Mohammad",
        system: "You are Mohammad, an expert in finding appointments (Citas de Extranjería). You are realistic but encouraging. Speak in Spanish, occasionally using Darija for greetings if appropriate.",
      },
      khalid: {
        name: "Khalid",
        system: "You are Khalid, a specialist in 'Arraigo' and residency laws. You are knowledgeable and empathetic. Speak in Spanish.",
      }
    };
  }

  async generateResponse(userText, avatarId = 'miriam', conversationHistory = []) {
    try {
      const persona = this.personas[avatarId] || this.personas.miriam;
      
      const messages = [
        { role: "system", content: persona.system },
        ...conversationHistory.slice(-5), // Keep last 5 messages for context
        { role: "user", content: userText }
      ];

      const completion = await this.openai.chat.completions.create({
        model: "gpt-4",
        messages: messages,
        temperature: 0.7,
        max_tokens: 150, // Keep responses concise for voice
      });

      const responseText = completion.choices[0].message.content;
      
      return {
        text: responseText,
        avatarId: avatarId,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error("AvatarResponseEngine Error:", error);
      return {
        text: "Lo siento, tuve un problema técnico. ¿Podrías repetirlo?",
        error: true
      };
    }
  }
}

export const avatarResponseEngine = new AvatarResponseEngine();