import { supabase } from '@/lib/supabaseClient';

class AppointmentAvailabilityService {
  constructor() {
    this.businessHours = {
      start: 9, // 9:00 AM
      end: 18,  // 6:00 PM
    };
    this.slotDuration = 30; // minutes
    this.workDays = [1, 2, 3, 4, 5]; // Mon-Fri
  }

  // Generate all possible slots for a given date range
  generateSlots(startDate, endDate) {
    const slots = [];
    let current = new Date(startDate);
    current.setMinutes(0, 0, 0); // Reset to start of hour
    if (current.getHours() < this.businessHours.start) {
      current.setHours(this.businessHours.start);
    }

    const end = new Date(endDate);

    while (current <= end) {
      const dayOfWeek = current.getDay();
      const hour = current.getHours();

      // Check if it's a workday and within business hours
      if (this.workDays.includes(dayOfWeek) && hour >= this.businessHours.start && hour < this.businessHours.end) {
        slots.push(new Date(current));
      }

      // Increment by slot duration
      current.setMinutes(current.getMinutes() + this.slotDuration);
      
      // If we moved past end of day, reset to start of next day
      if (current.getHours() >= this.businessHours.end) {
        current.setDate(current.getDate() + 1);
        current.setHours(this.businessHours.start);
        current.setMinutes(0);
      }
    }
    return slots;
  }

  async getAvailableSlots(date, avatarId) {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    // 1. Get all potential slots
    const allSlots = this.generateSlots(startOfDay, endOfDay);

    // 2. Fetch existing appointments from DB
    // Note: In a real app, you might want to move this to Edge Function to bypass RLS if users can't see others' bookings.
    // However, since we are calculating "availability", we just need the times, not the user details.
    // If RLS prevents reading others' appointments, this client-side call returns empty for others. 
    // The Edge Function implementation (Task 2) handles the "True" availability check securely.
    // This client-side service is mostly for helper logic or own appointments.
    
    // We will rely on the Edge Function for the actual "Global" availability search to avoid RLS issues.
    // This method here is a local utility or for checking against own calendar.
    
    return allSlots; 
  }

  async reserveSlot(date, time, clienteId, avatarId) {
    const appointmentDate = new Date(date);
    const [hours, minutes] = time.split(':');
    appointmentDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);

    const { data, error } = await supabase
      .from('tabla_citas')
      .insert([
        {
          cliente_id: clienteId,
          avatar_id: avatarId,
          fecha_cita: appointmentDate.toISOString(),
          estado: 'confirmada',
          fecha_creacion: new Date().toISOString(),
          notas: 'Reserva automática via Avatar'
        }
      ])
      .select()
      .single();

    if (error) throw error;
    return data;
  }
}

export const appointmentAvailabilityService = new AppointmentAvailabilityService();