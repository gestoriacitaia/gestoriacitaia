/**
 * Appointment Guidance Service (Mohammad Mode)
 * Guides user through official appointment process without false promises.
 */

export const appointmentGuidanceService = {
  /**
   * Get steps for specific procedure
   */
  getGuidanceSteps: (province, tramite) => {
    return [
      {
        id: 1,
        text: `Dkhol l site dyal 'Sede Electrónica' dyal l pentagono (Administraciones Públicas).`
      },
      {
        id: 2,
        text: `Ikhtar l provincia: ${province}.`
      },
      {
        id: 3,
        text: `Ikhtar t-tramite: ${tramite}.`
      },
      {
        id: 4,
        text: "3ammer lma3loumat dyalek (NIE, Pasaporte, Ism). Rdd balek m3a tawarik."
      },
      {
        id: 5,
        text: "Ila lqiti 'No hay citas', ma tqlaqch. Rejjel l 'WhatsApp alerts' dyalna bach n3almouk mnin tkoun dispo."
      }
    ];
  },

  /**
   * Response for unavailability
   */
  getUnavailabilityMessage: (province) => {
    return `Ila t7ellat cita f provincia dyal ${province}, nsifto lik message WhatsApp bach tdkhol w n3awnok t3amroha.`;
  }
};