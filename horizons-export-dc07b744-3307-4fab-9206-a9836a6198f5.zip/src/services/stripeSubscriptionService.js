import { loadStripe } from '@stripe/stripe-js';
import { supabase } from '@/lib/supabaseClient';
import { paymentDebugService } from './paymentDebugService';

// Ensure we have a key, even if fallback
const STRIPE_KEY = import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_51SxeKKEsTPbZQl0QE6r4pts0c1iaSFfAQ1D8HLGCoQImp8lvXkPz9tYhx3Q4ULJwGIQBpEwTl0nxxqZS9GkLYh3E00NBceUctD';
let stripePromise;

export const getStripe = () => {
  if (!stripePromise) {
    if (STRIPE_KEY) {
      stripePromise = loadStripe(STRIPE_KEY);
    } else {
      console.warn("Stripe public key is missing from environment variables.");
    }
  }
  return stripePromise;
};

// Map internal plan IDs to Stripe Price IDs (using placeholders for now)
const PLAN_PRICE_MAP = {
  basic: 'price_basic_placeholder',
  standard: 'price_standard_placeholder',
  appointments: 'price_appointments_placeholder',
  pro: 'price_pro_placeholder'
};

export const stripeSubscriptionService = {
  /**
   * Create a Checkout Session
   */
  createCheckoutSession: async (userEmail, planId = 'basic') => {
    paymentDebugService.logStep('SubscriptionService', 'createCheckoutSession called', { userEmail, planId });

    if (!STRIPE_KEY) {
      const error = new Error('Configuration Error: Stripe key is missing.');
      paymentDebugService.logError('SubscriptionService:Config', error);
      return { error: error.message };
    }

    if (!userEmail || !planId) {
      const error = new Error('Missing required parameters: email or planId');
      paymentDebugService.logError('SubscriptionService:Validation', error);
      return { error: error.message };
    }

    try {
      paymentDebugService.logStep('SubscriptionService', 'Simulating Backend Call');
      
      // Simulate network request with timeout handling
      const sessionData = await Promise.race([
        new Promise((resolve) => {
          setTimeout(() => {
            const mockSessionId = 'cs_test_' + Math.random().toString(36).substr(2, 9);
            // Redirect back to subscription success/checkout page with simulated params
            const successUrl = `${window.location.origin}/subscription-checkout?session_id=${mockSessionId}&status=success&plan=${planId}`;
            
            resolve({ url: successUrl, id: mockSessionId });
          }, 1500);
        }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout: Payment service unresponsive')), 8000))
      ]);

      if (!sessionData || !sessionData.url) {
        throw new Error('Invalid session response from payment service');
      }

      paymentDebugService.logStep('SubscriptionService', 'Session Created', sessionData);
      return { url: sessionData.url };

    } catch (error) {
      paymentDebugService.logError('SubscriptionService:API', error);
      return { error: error.message || 'Unknown payment service error' };
    }
  },

  /**
   * Verify a payment session
   */
  verifyPaymentSession: async (sessionId, planId) => {
    paymentDebugService.logStep('SubscriptionService', 'verifyPaymentSession', { sessionId });

    const prices = {
      basic: 9.99,
      standard: 14.99,
      appointments: 16.99,
      pro: 27.99
    };

    try {
      const mockSubscription = {
        plan_name: planId || 'basic',
        stripe_session_id: sessionId,
        amount: prices[planId] || 9.99,
        currency: 'eur',
        status: 'active',
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      };

      // Attempt to save to Supabase if user exists
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { error } = await supabase
          .from('subscriptions')
          .insert({
            user_id: user.id,
            ...mockSubscription
          });
        
        if (error) {
            console.warn('⚠️ Failed to save subscription to Supabase:', error);
        } else {
            console.log('✅ Subscription saved to Supabase');
        }
      }

      return { success: true, subscription: mockSubscription };
    } catch (error) {
      paymentDebugService.logError('SubscriptionService:Verify', error);
      return { success: false, error: error.message };
    }
  }
};