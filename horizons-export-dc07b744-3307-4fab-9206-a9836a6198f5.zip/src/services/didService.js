import { supabase } from '@/lib/supabaseClient';

/**
 * D-ID Video Generation Service
 * 
 * Uses Supabase Edge Functions to securely generate avatar videos.
 * Fallback to mock behavior if Supabase is not configured.
 */

// Mock videos for demo purposes
const MOCK_VIDEOS = {
  sarah: "https://d-id-public-bucket.s3.us-west-2.amazonaws.com/alice.mp4", // Placeholder
  ivan: "https://d-id-public-bucket.s3.us-west-2.amazonaws.com/matt.mp4",   // Placeholder
  laetitia: "https://d-id-public-bucket.s3.us-west-2.amazonaws.com/lily.mp4" // Placeholder
};

/**
 * Generate a video of the avatar speaking the text
 * @param {string} text - The text to speak
 * @param {string} avatarId - The avatar identifier
 * @param {string} language - 'es' or 'ar'
 * @returns {Promise<string|null>} - Video URL
 */
export const generateAvatarVideo = async (text, avatarId = 'sarah', language = 'es') => {
  // 1. Try Supabase Edge Function
  if (supabase) {
    try {
      const { data, error } = await supabase.functions.invoke('generate-avatar-video', {
        body: { 
          script: text, 
          avatarId, 
          language 
        }
      });

      if (error) throw error;
      if (data?.videoUrl) return data.videoUrl;
      
    } catch (error) {
      console.error('Supabase D-ID generation failed:', error);
      // Fall through to mock
    }
  }

  // 2. Mock Fallback
  console.log('Using Mock D-ID Video');
  await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate processing
  return MOCK_VIDEOS[avatarId] || MOCK_VIDEOS.sarah;
};

export default {
  generateAvatarVideo
};