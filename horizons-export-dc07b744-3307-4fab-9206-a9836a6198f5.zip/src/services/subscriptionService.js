import { supabase } from '@/lib/supabaseClient';

/**
 * Subscription Service
 * Manages tiers and access validation.
 */

export const SUBSCRIPTION_TIERS = {
  BASIC: {
    id: 'basic',
    name: 'Plan Básico',
    price: 9.99,
    features: ['Consulta IA 15 min', 'Respuesta con videollamada en tiempo real'],
    allowedModes: ['mohamad', 'khalid']
  },
  STANDARD: {
    id: 'standard',
    name: 'Plan Estándar',
    price: 14.99,
    features: [
      'Consulta IA',
      'Videollamada 5 veces al mes',
      'Verificación de documentos PDF',
      'Prioridad en respuesta',
      'Historial de chats guardado'
    ],
    allowedModes: ['mohamad', 'khalid']
  },
  APPOINTMENTS: {
    id: 'appointments',
    name: 'Plan Búsqueda de Citas',
    price: 16.99,
    features: [
      'Buscar citas',
      'Mandar WhatsApp al cliente',
      'Acompañamiento del proceso',
      'Videollamada en vivo paso a paso'
    ],
    allowedModes: ['miriam']
  },
  PRO: {
    id: 'pro',
    name: 'Plan Pro',
    price: 27.99,
    features: [
      'Todo ilimitado en el sitio web',
      'Abonne cada mes',
      'Todo incluido'
    ],
    allowedModes: ['mohamad', 'khalid', 'miriam']
  }
};

export const subscriptionService = {
  /**
   * Get current user subscription
   */
  getUserSubscription: async (userId) => {
    // 1. Try LocalStorage (Prototype)
    const localSub = localStorage.getItem('user_subscription');
    if (localSub) {
      return JSON.parse(localSub);
    }

    // 2. Try Supabase
    if (supabase && userId) {
      const { data } = await supabase
        .from('users_subscriptions')
        .select('*')
        .eq('user_id', userId)
        .single();
      
      if (data) return data;
    }

    // Default: No subscription
    return { planId: null, status: 'inactive' };
  },

  /**
   * Check if user has access to a feature or mode
   */
  checkAccess: (subscription, requiredTier) => {
    const tiers = ['basic', 'standard', 'appointments', 'pro'];
    const userTierIndex = tiers.indexOf(subscription?.planId);
    const requiredTierIndex = tiers.indexOf(requiredTier);

    if (userTierIndex === -1) return false; // No sub
    return userTierIndex >= requiredTierIndex;
  },

  /**
   * Simulate upgrading subscription
   */
  upgradeSubscription: async (userId, planId) => {
    const subData = {
      userId,
      planId,
      status: 'active',
      activeUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // +30 days
    };

    localStorage.setItem('user_subscription', JSON.stringify(subData));
    
    if (supabase) {
      await supabase.from('users_subscriptions').upsert({
        user_id: userId,
        plan_tier: planId,
        active_until: subData.activeUntil,
        consent_rgpd: true
      });
    }

    return subData;
  }
};