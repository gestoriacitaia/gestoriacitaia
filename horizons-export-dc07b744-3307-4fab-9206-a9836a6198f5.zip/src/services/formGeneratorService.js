import { supabase } from '@/lib/supabaseClient';

/**
 * Form Generator Service
 * Collects data and generates PDF forms (EX-10, EX-11, etc.)
 */

export const formGeneratorService = {
  /**
   * Required fields for form generation
   */
  getRequiredFields: (formType) => {
    const common = ['nombre_completo', 'fecha_nacimiento', 'pasaporte', 'nie', 'direccion', 'telefono', 'email'];
    switch(formType) {
      case 'EX-10': return [...common, 'motivo_arraigo'];
      case 'EX-11': return [...common, 'tiempo_residencia']; // Larga duración
      default: return common;
    }
  },

  /**
   * Generate PDF Form (Mock)
   */
  generatePDF: async (formType, userData) => {
    console.log(`Generating ${formType} for`, userData);
    
    if (!userData.rgpdConsent) {
      throw new Error("Darori lmofaqa 3la RGPD.");
    }

    // Simulate generation time
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Return mock PDF URL
    return {
      success: true,
      url: `https://example.com/forms/${formType}_filled.pdf`, // Mock URL
      tasaInfo: formGeneratorService.getTasaInfo(formType),
      message: "Formulaire wajed. Telechargih daba."
    };
  },

  /**
   * Get Tasa information based on form
   */
  getTasaInfo: (formType) => {
    const tasas = {
      'EX-10': { code: '052', amount: '38.28€', desc: 'Tramitación de autorizaciones de residencia' },
      'EX-11': { code: '052', amount: '21.87€', desc: 'Residencia de larga duración' },
      'EX-15': { code: '012', amount: '9.84€', desc: 'Asignación de NIE' },
      'EX-17': { code: '012', amount: '16.08€', desc: 'Tarjeta de identidad de extranjero (TIE)' }
    };
    return tasas[formType] || { code: 'Unknown', amount: '0.00€' };
  }
};