import OpenAI from 'openai';
import { supabase } from '@/lib/supabaseClient';

class ConsultationAudioProcessor {
  constructor() {
    this.openai = new OpenAI({
      apiKey: import.meta.env.VITE_OPENAI_API_KEY,
      dangerouslyAllowBrowser: true
    });
    this.mediaRecorder = null;
    this.audioChunks = [];
    this.isRecording = false;
  }

  async startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.mediaRecorder = new MediaRecorder(stream);
      this.audioChunks = [];
      this.isRecording = true;

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) this.audioChunks.push(event.data);
      };

      this.mediaRecorder.start();
      return true;
    } catch (error) {
      console.error("Audio Start Error:", error);
      throw error;
    }
  }

  async stopAndProcess(avatarId, didSessionId, didStreamId) {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        resolve(null);
        return;
      }

      this.mediaRecorder.onstop = async () => {
        try {
          const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
          const file = new File([audioBlob], "input.webm", { type: "audio/webm" });

          // 1. Whisper Transcription
          const transcription = await this.openai.audio.transcriptions.create({
            file,
            model: "whisper-1",
            language: "es"
          });

          const userText = transcription.text;
          if (!userText.trim()) {
             resolve({ userText: '', aiText: '' });
             return;
          }

          // 2. Generate Response (delegated to Engine, but prompt says Processor passes it...
          // I will use the ConsultationResponseEngine here to keep it clean)
          // Wait, Task 5 says "passes to GPT-4... sends response to send-avatar-message". 
          // Task 6 says "ConsultationResponseEngine... receives transcribed user text".
          // I will call ResponseEngine from here.
          
          const { consultationResponseEngine } = await import('./ConsultationResponseEngine');
          const aiResponse = await consultationResponseEngine.generateResponse(userText, avatarId);

          // 3. Send to D-ID via Edge Function
          await supabase.functions.invoke('send-avatar-message', {
             body: {
               sessionId: didSessionId,
               streamId: didStreamId,
               text: aiResponse.text,
               avatarId
             }
          });

          this.isRecording = false;
          resolve({ userText, aiText: aiResponse.text });

        } catch (error) {
          console.error("Audio Processing Error:", error);
          reject(error);
        }
      };

      this.mediaRecorder.stop();
      this.mediaRecorder.stream.getTracks().forEach(t => t.stop());
    });
  }
}

export const consultationAudioProcessor = new ConsultationAudioProcessor();