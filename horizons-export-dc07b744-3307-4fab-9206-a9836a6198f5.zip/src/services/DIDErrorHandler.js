class DIDErrorHandler {
  static handle(error, context = '') {
    console.error(`D-ID Error [${context}]:`, error);

    let message = 'An unexpected error occurred with the video service.';
    
    if (error.response) {
      // API Error
      const status = error.response.status;
      if (status === 401) message = 'Authentication failed. Please check API keys.';
      else if (status === 402) message = 'D-ID credits exhausted or payment required.';
      else if (status === 500) message = 'D-ID server error. Please try again later.';
      else if (error.response.data?.message) message = `D-ID Error: ${error.response.data.message}`;
    } else if (error.name === 'NotAllowedError') {
      message = 'Microphone or Camera access denied.';
    } else if (error.name === 'NotReadableError') {
      message = 'Hardware error: Could not access input device.';
    }

    // Return structured error for UI
    return {
      message,
      code: error.code || 'UNKNOWN',
      timestamp: new Date().toISOString()
    };
  }

  static isRetryable(error) {
    // Retry on network errors or 500s
    if (!error.response) return true; // Network error
    return error.response.status >= 500;
  }
}

export default DIDErrorHandler;