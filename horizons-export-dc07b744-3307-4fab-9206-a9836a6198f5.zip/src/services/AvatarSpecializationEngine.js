/**
 * Avatar Specialization Engine
 * Routes questions and validates intent.
 */

import { AVATAR_DEFINITIONS } from './AvatarSystemService';

export const routeQuestion = (question) => {
  const lowerQ = question.toLowerCase();
  
  if (lowerQ.includes('cita') || lowerQ.includes('horario') || lowerQ.includes('sede')) {
    return 'mohammad';
  }
  if (lowerQ.includes('revisar') || lowerQ.includes('mirar') || lowerQ.includes('documento') || lowerQ.includes('papel') || lowerQ.includes('foto')) {
    return 'miriam';
  }
  if (lowerQ.includes('ley') || lowerQ.includes('arraigo') || lowerQ.includes('residencia') || lowerQ.includes('renovación') || lowerQ.includes('tasa')) {
    return 'khalid';
  }
  
  return null; // Ambiguous or general
};

export const validateAvatarIntent = (currentAvatarId, question) => {
  const suggestedAvatar = routeQuestion(question);
  
  if (suggestedAvatar && suggestedAvatar !== currentAvatarId) {
    return {
      isValid: false,
      suggestedAvatar,
      message: `Esa pregunta es mejor para ${AVATAR_DEFINITIONS[suggestedAvatar].name}, mi compañero especialista en eso.`
    };
  }
  
  return { isValid: true };
};

export const validateDocumentCoherence = (documents) => {
  // Mock validation logic
  const nie = documents.find(d => d.type === 'NIE');
  const passport = documents.find(d => d.type === 'Passport');
  
  if (nie && passport) {
    // Check if names match (Mock)
    return { coherent: true, message: "Datos coincidentes entre NIE y Pasaporte." };
  }
  
  return { coherent: true, message: "Esperando más documentos para cruzar datos." };
};

export default {
  routeQuestion,
  validateAvatarIntent,
  validateDocumentCoherence
};