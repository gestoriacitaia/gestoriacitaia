import { supabase } from '@/lib/supabaseClient';

/**
 * Moroccan Darija Service (ElevenLabs Integration)
 * specialized for handling Darija dialect synthesis
 */

const VOICES = {
  male: '2EiwWnXFnvU5JabPnv8n', // Example ID for a male voice
  female: 'EXAVITQu4vr4xnSDxMaL' // Example ID for a female voice
};

const synthesizeSpeech = async (text, language = 'es', gender = 'male') => {
  console.log(`Synthesizing ${language} speech for ${gender}: ${text}`);

  // Use the existing Supabase integration if available
  if (supabase) {
    try {
      const { data, error } = await supabase.functions.invoke('generate-avatar-voice', {
        body: { 
          text, 
          language, 
          voiceId: VOICES[gender] 
        }
      });

      if (!error && (data?.audioUrl || data?.audioData)) {
        return {
          audioUrl: data.audioUrl || `data:audio/mpeg;base64,${data.audioData}`,
          success: true
        };
      }
    } catch (err) {
      console.warn('ElevenLabs synthesis failed, falling back to mock', err);
    }
  }

  // Fallback simulation
  await new Promise(resolve => setTimeout(resolve, 1000));
  return {
    success: true,
    audioUrl: null, // Silent success for demo
    isMock: true
  };
};

export default {
  synthesizeSpeech
};