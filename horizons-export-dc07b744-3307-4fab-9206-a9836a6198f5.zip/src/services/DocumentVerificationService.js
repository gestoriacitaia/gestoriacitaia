import { supabase } from '@/lib/supabaseClient';

class DocumentVerificationService {
  async uploadAndVerify(file, documentType, clienteId, citaId) {
    try {
      if (!clienteId) throw new Error("Client ID required");

      // 1. Upload to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9]/g, '_')}`;
      const filePath = `${clienteId}/${citaId || 'general'}/${fileName}.${fileExt}`;

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('documentos')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('documentos')
        .getPublicUrl(filePath);

      // 2. Create Initial Record
      const { data: docRecord, error: dbError } = await supabase
        .from('tabla_documentos')
        .insert([{
          cliente_id: clienteId,
          cita_id: citaId,
          nombre_documento: file.name,
          url_documento: publicUrl,
          tipo: documentType,
          verificado: false,
          fecha_subida: new Date().toISOString()
        }])
        .select()
        .single();

      if (dbError) throw dbError;

      // 3. Call Edge Function for Analysis
      const { data: analysisResult, error: funcError } = await supabase.functions.invoke('verify-pdf-document', {
        body: {
          pdfUrl: publicUrl,
          documentType,
          language: 'es'
        }
      });

      if (funcError) {
        console.error("Analysis Function Error:", funcError);
        // Don't fail the whole process, just return unverified
        return { 
          document: docRecord, 
          verification: { isValid: false, issues: ["Analysis service unavailable"], summary: "Could not verify automatically." }
        };
      }

      // 4. Update Record with Result
      const { error: updateError } = await supabase
        .from('tabla_documentos')
        .update({ verificado: analysisResult.isValid })
        .eq('id', docRecord.id);

      if (updateError) console.error("Failed to update verification status DB", updateError);

      return {
        document: docRecord,
        verification: analysisResult
      };

    } catch (error) {
      console.error("Document Service Error:", error);
      throw error;
    }
  }
}

export const documentVerificationService = new DocumentVerificationService();