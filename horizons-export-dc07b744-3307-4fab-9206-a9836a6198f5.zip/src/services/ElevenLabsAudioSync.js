import axios from 'axios';

class ElevenLabsAudioSync {
  constructor() {
    this.apiKey = import.meta.env.VITE_ELEVENLABS_API_KEY;
    this.baseUrl = 'https://api.elevenlabs.io/v1';
    
    // Voice Mapping
    this.voices = {
      es: 'pNInz6obpgDQGcFmaJgB', // Adam (Good multilingual)
      en: '21m00Tcm4TlvDq8ikWAM', // Rachel
      default: 'pNInz6obpgDQGcFmaJgB'
    };
  }

  /**
   * Generates audio from text and returns a Blob.
   */
  async generateSpeech(text, language = 'es') {
    const voiceId = this.voices[language] || this.voices.default;
    
    try {
      const response = await axios({
        method: 'post',
        url: `${this.baseUrl}/text-to-speech/${voiceId}`,
        data: {
          text: text,
          model_id: "eleven_multilingual_v2",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75
          }
        },
        headers: {
          'Accept': 'audio/mpeg',
          'xi-api-key': this.apiKey,
          'Content-Type': 'application/json',
        },
        responseType: 'blob'
      });

      return {
        audioBlob: response.data,
        durationEstimation: text.length * 0.1 // Rough estimate in seconds
      };
    } catch (error) {
      console.error('ElevenLabs Gen Error:', error);
      throw error;
    }
  }
}

export const elevenLabsAudioSync = new ElevenLabsAudioSync();