import { supabase } from '@/lib/supabaseClient';

class ConsultationSessionStorage {
  constructor() {
    this.useLocalStorage = !supabase;
  }

  async saveSession(sessionData) {
    // sessionData: { clientId, avatarId, startTime, duration, status }
    if (this.useLocalStorage) {
      const sessions = JSON.parse(localStorage.getItem('consultation_sessions') || '[]');
      sessions.push({ ...sessionData, id: `local_${Date.now()}` });
      localStorage.setItem('consultation_sessions', JSON.stringify(sessions));
      return { id: `local_${Date.now()}` };
    }

    try {
      const { data, error } = await supabase
        .from('consultation_sessions')
        .insert([sessionData])
        .select();
      
      if (error) throw error;
      return data[0];
    } catch (error) {
      console.error('Supabase Save Error:', error);
      return { id: null, error: true };
    }
  }

  async saveTranscript(sessionId, messages) {
    if (this.useLocalStorage) {
      localStorage.setItem(`transcript_${sessionId}`, JSON.stringify(messages));
      return true;
    }

    try {
      const { error } = await supabase
        .from('session_transcripts')
        .insert(messages.map(msg => ({ ...msg, session_id: sessionId })));
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Supabase Transcript Error:', error);
      return false;
    }
  }

  async getSessionHistory(clientId) {
    if (this.useLocalStorage) {
      const sessions = JSON.parse(localStorage.getItem('consultation_sessions') || '[]');
      return sessions.filter(s => s.clientId === clientId);
    }

    const { data, error } = await supabase
      .from('consultation_sessions')
      .select('*')
      .eq('client_id', clientId)
      .order('start_time', { ascending: false });
      
    if (error) return [];
    return data;
  }
}

export const consultationSessionStorage = new ConsultationSessionStorage();