import axios from 'axios';

class ElevenLabsVoiceSynthesis {
  constructor() {
    this.apiKey = import.meta.env.VITE_ELEVENLABS_API_KEY;
    this.baseUrl = 'https://api.elevenlabs.io/v1';
    
    // Specific voice IDs for our avatars
    this.voices = {
      miriam: '21m00Tcm4TlvDq8ikWAM', // Rachel (Female)
      mohammad: 'pNInz6obpgDQGcFmaJgB', // Adam (Male)
      khalid: 'VR6AewGX3Rex9jLeOSn3', // Other Male
      default: '21m00Tcm4TlvDq8ikWAM'
    };
  }

  async synthesizeSpeech(text, avatarId = 'miriam', language = 'es') {
    const voiceId = this.voices[avatarId] || this.voices.default;
    
    try {
      const response = await axios({
        method: 'post',
        url: `${this.baseUrl}/text-to-speech/${voiceId}/stream`,
        data: {
          text: text,
          model_id: "eleven_multilingual_v2",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75,
            style: 0.0,
            use_speaker_boost: true
          }
        },
        headers: {
          'Accept': 'audio/mpeg',
          'xi-api-key': this.apiKey,
          'Content-Type': 'application/json',
        },
        responseType: 'blob'
      });

      return {
        audioBlob: response.data,
        duration: text.length * 0.08, // Rough estimation
        format: 'audio/mpeg'
      };
    } catch (error) {
      console.error('ElevenLabs Synthesis Error:', error);
      throw error;
    }
  }
}

export const elevenLabsVoiceSynthesis = new ElevenLabsVoiceSynthesis();