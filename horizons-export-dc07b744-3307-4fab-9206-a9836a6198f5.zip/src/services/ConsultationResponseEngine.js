import OpenAI from 'openai';

class ConsultationResponseEngine {
  constructor() {
    this.openai = new OpenAI({
      apiKey: import.meta.env.VITE_OPENAI_API_KEY,
      dangerouslyAllowBrowser: true
    });
    this.context = [];
    this.cache = new Map();
  }

  async generateResponse(userText, avatarId) {
    // Check Cache
    const cacheKey = `${avatarId}:${userText.trim().toLowerCase()}`;
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }

    const systemPrompt = this.getSystemPrompt(avatarId);
    
    const messages = [
      { role: "system", content: systemPrompt },
      ...this.context.slice(-6), // Keep last 6 turns
      { role: "user", content: userText }
    ];

    try {
      const completion = await this.openai.chat.completions.create({
        model: "gpt-4",
        messages: messages,
        max_tokens: 150,
        temperature: 0.7
      });

      const responseText = completion.choices[0].message.content;
      
      // Update Context
      this.context.push({ role: "user", content: userText });
      this.context.push({ role: "assistant", content: responseText });

      const result = { text: responseText, timestamp: new Date().toISOString() };
      
      // Cache Result
      this.cache.set(cacheKey, result);
      
      return result;

    } catch (error) {
      console.error("GPT Error:", error);
      return { text: "Lo siento, hubo un error de conexión. ¿Puede repetir?" };
    }
  }

  getSystemPrompt(avatarId) {
    const prompts = {
      miriam: "Eres Miriam, abogada experta en inmigración española. Responde de forma concisa, profesional y empática en español.",
      mohammad: "Eres Mohammad, experto en citas de extranjería. Sé directo y útil. Habla en español.",
      khalid: "Eres Khalid, especialista en arraigo. Da consejos legales claros en español.",
    };
    return prompts[avatarId?.toLowerCase()] || prompts.miriam;
  }
}

export const consultationResponseEngine = new ConsultationResponseEngine();