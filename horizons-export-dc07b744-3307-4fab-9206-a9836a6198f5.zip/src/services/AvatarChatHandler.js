import { supabase } from '@/lib/supabaseClient';

class AvatarChatHandlerService {
  async sendMessage(message, history = [], language = 'es') {
    try {
      // Clean history for the API (remove local-only fields if any)
      const cleanHistory = history.map(msg => ({
        role: msg.role === 'me' ? 'user' : 'assistant',
        content: msg.text
      }));

      const { data, error } = await supabase.functions.invoke('chat-consultant', {
        body: {
          message,
          history: cleanHistory,
          language
        }
      });

      if (error) {
        console.error('Edge Function Error:', error);
        throw new Error('Failed to reach consultant');
      }

      return data.reply;
    } catch (error) {
      console.error('Chat Handler Error:', error);
      // Fallback response if offline or error
      return "Lo siento, tengo problemas de conexión en este momento. Por favor intenta de nuevo.";
    }
  }
}

export const avatarChatHandler = new AvatarChatHandlerService();