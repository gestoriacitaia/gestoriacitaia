/**
 * Immigration Service for D-ID Avatar Integration
 * Defines the available avatars and their personas for Real-Time Voice/Video.
 */

const AVATARS = [
  {
    id: 'miriam',
    name: 'Miriam',
    specialty: 'Buscar citas',
    role: 'Asistente IA',
    gender: 'female',
    description: 'Especialista en la búsqueda y gestión de citas previas de extranjería y consulados.',
    image: 'https://horizons-cdn.hostinger.com/dc07b744-3307-4fab-9206-a9836a6198f5/66ccd3435c0bfc22b71b11a47039c667.png',
    imageStyle: {},
    voiceId: '21m00Tcm4TlvDq8ikWAM', // Rachel (ElevenLabs placeholder)
    languages: ['es', 'ar']
  },
  {
    id: 'khalid',
    name: 'Khalid',
    specialty: 'Trámites',
    role: 'Especialista Legal',
    gender: 'male',
    description: 'Especialista en permisos de residencia, arraigo social y laboral, y renovaciones. Te ayuda con todos tus trámites.',
    image: 'https://horizons-cdn.hostinger.com/dc07b744-3307-4fab-9206-a9836a6198f5/403b4a683ac13e24a4929b53a128eb18.png',
    imageStyle: {},
    voiceId: 'ErXwobaYiN019PkySvjV', // Antoni (ElevenLabs placeholder)
    languages: ['es', 'ar']
  },
  {
    id: 'mohammad',
    name: 'Mohammad',
    specialty: 'Trámites',
    role: 'Consultor Senior',
    gender: 'male',
    description: 'Consultor experto en gestión y asesoramiento de trámites de extranjería.',
    image: 'https://horizons-cdn.hostinger.com/dc07b744-3307-4fab-9206-a9836a6198f5/15315bcf9fe99abffd938252e4f61b9d.png',
    imageStyle: { objectPosition: 'top' },
    voiceId: 'ODq5zmih8GrVes37Dizj', // Patrick (ElevenLabs placeholder)
    languages: ['es', 'ar']
  }
];

export const getAvatars = () => AVATARS;

export default {
  getAvatars
};