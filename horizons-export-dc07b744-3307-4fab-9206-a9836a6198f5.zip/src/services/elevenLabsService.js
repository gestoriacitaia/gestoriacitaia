import { supabase } from '@/lib/supabaseClient';

/**
 * ElevenLabs Voice Synthesis Service
 * 
 * Uses Supabase Edge Functions for secure TTS.
 */

/**
 * Generate avatar voice audio
 * @param {string} text 
 * @param {string} language 
 * @param {string} avatarId 
 * @returns {Promise<string|null>} - Audio URL
 */
export const generateAvatarVoice = async (text, language = 'es', avatarId = 'sarah') => {
  
  // 1. Try Supabase Edge Function
  if (supabase) {
    try {
      const { data, error } = await supabase.functions.invoke('generate-avatar-voice', {
        body: { text, language, avatarId }
      });

      if (error) throw error;

      // Ensure we have a usable URL
      if (data?.audioUrl) return data.audioUrl;
      if (data?.audioData) {
        return `data:audio/mpeg;base64,${data.audioData}`;
      }

    } catch (error) {
      console.error('Supabase ElevenLabs call failed:', error);
      // Fall through to mock
    }
  }

  // 2. Mock Fallback (No audio in mock mode to avoid confusing user with static files)
  console.warn('Voice synthesis: Supabase not configured. Returning silent success.');
  return null; 
};

export const isVoiceSynthesisAvailable = () => {
  // Available if supabase is configured or we want to allow mock
  return !!supabase; 
};

export default {
  generateAvatarVoice,
  isVoiceSynthesisAvailable,
};