import { supabase } from '@/lib/supabaseClient';

/**
 * Document Verification Service
 * Validates basic coherence of documents.
 */

const documentVerificationService = {
  verifyDocument: async (file) => {
    console.log(`Verifying document...`);
    
    // Simulation of OCR/AI analysis delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Simple validation logic (mock)
    const isValid = file && file.size > 0 && file.size < 5000000; // Under 5MB
    
    // Mock data generation based on file
    const docType = "NIE/TIE"; // Default assumption for the mock
    const expirationDate = "12/2025"; // Mock expiration

    const result = {
      isValid,
      docType,
      expirationDate,
      feedback: isValid 
        ? "Documento válido y legible. (Simulación)" 
        : "El documento no es legible o es demasiado grande.",
      timestamp: new Date().toISOString()
    };

    // Store result if Supabase is connected
    if (supabase) {
       try {
         // Mock user ID for now
         const userId = 'user_guest'; 
         await supabase.from('document_verifications').insert({
           user_id: userId,
           document_type: docType,
           validation_result: result,
         });
       } catch (error) {
         console.warn("Could not save verification to Supabase:", error);
       }
    }

    return result;
  }
};

export { documentVerificationService };