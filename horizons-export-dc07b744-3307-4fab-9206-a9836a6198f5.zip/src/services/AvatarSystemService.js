import { supabase } from '@/lib/supabaseClient';

/**
 * Avatar System Service
 * Handles OpenAI integration, persona management, and voice synthesis.
 */

const DISCLAIMER = "⚠️ IMPORTANTE: La información es orientativa, no constituye asesoramiento jurídico. No somos organismo oficial ni trabajamos para Policía Nacional.";

const AVATARS = {
  khalid: {
    id: 'khalid',
    name: 'Khalid',
    role: 'Experto en Arraigo y Residencia',
    specialty: 'Trámites',
    description: 'Especialista en EX-10, EX-11 y trámites de residencia. Habla Darija y Español.',
    systemPrompt: `Eres Khalid, experto legal en extranjería española.
    Especialidad: Arraigo (Social, Laboral, Familiar) y Trámites de Residencia.
    Idiomas: Darija Marroquí (principal) y Español (términos legales).
    
    Reglas:
    1. Tus respuestas deben ser NUMERADAS, CLARAS y CORTAS.
    2. Siempre confirma que el usuario entendió antes de avanzar.
    3. NUNCA garantices aprobaciones o citas.
    4. Cita las tasas oficiales (Modelo 790 código 052/062) cuando corresponda.
    5. Advierte siempre: "${DISCLAIMER}" al inicio de temas delicados.
    `
  },
  miriam: {
    id: 'miriam',
    name: 'Miriam',
    role: 'Asistente de Citas',
    specialty: 'Buscar citas',
    description: 'Experta en gestión y búsqueda de citas previas.',
    systemPrompt: `Eres Miriam, experta en verificación documental y búsqueda de citas.
    Especialidad: Revisión técnica de documentos para citas y gestión de las mismas.
    Idiomas: Español y Darija.
    
    Reglas:
    1. Pide los documentos uno por uno.
    2. Verifica fechas de caducidad y coherencia de nombres.
    3. Si un documento está caducado, avisa inmediatamente.
    4. No des consejos legales, solo técnicos sobre los documentos y citas.
    5. Respuestas cortas y directas.
    `
  },
  mohammad: {
    id: 'mohammad',
    name: 'Mohammad',
    role: 'Guía de Trámites',
    specialty: 'Trámites',
    description: 'Guía paso a paso para la correcta gestión de trámites de extranjería.',
    systemPrompt: `Eres Mohammad, guía de trámites administrativos.
    Especialidad: Trámites de extranjería y orientación.
    Idiomas: Darija y Español.
    
    Reglas:
    1. Guía al usuario en sus trámites.
    2. NO prometas conseguir resultados imposibles.
    3. Explica los pasos de forma clara y concisa.
    4. Sé empático y paciente.
    5. Respuestas numeradas paso a paso.
    `
  }
};

export const getAvatarResponse = async (avatarId, userMessage, history = []) => {
  const avatar = AVATARS[avatarId] || AVATARS.khalid;
  
  // Simulation of OpenAI call
  // In a real implementation, this would call a Supabase Edge Function
  
  console.log(`[AvatarSystem] Generating response for ${avatar.name} with prompt: ${userMessage}`);
  
  await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate latency

  let responseText = "";

  // Mock Logic for Demo Purposes
  if (avatarId === 'khalid') {
    if (userMessage.toLowerCase().includes('arraigo')) {
      responseText = `1. Para el Arraigo Social necesitas 3 años en España.\n2. ¿Tienes el certificado de empadronamiento histórico?\n3. Confírmame para explicarte el contrato de trabajo.`;
    } else {
      responseText = `Salam. Soy Khalid. Puedo ayudarte con tus trámites. ¿Qué trámite necesitas empezar hoy?`;
    }
  } else if (avatarId === 'miriam') {
    if (userMessage.toLowerCase().includes('nie') || userMessage.toLowerCase().includes('subir')) {
      responseText = `He recibido tu documento. Voy a verificar la información para buscar la cita. Por favor, espera un momento...`;
    } else {
      responseText = `Hola, soy Miriam. Te ayudaré a buscar citas. Por favor indícame qué trámite necesitas.`;
    }
  } else if (avatarId === 'mohammad') {
    responseText = `1. Para iniciar el trámite, primero reúne los documentos básicos.\n2. Te guiaré paso a paso.\n¿Quieres que te envíe la lista de requisitos?`;
  }

  return {
    text: responseText,
    audioUrl: null, // Would come from ElevenLabs
    disclaimer: DISCLAIMER
  };
};

export const AVATAR_DEFINITIONS = AVATARS;

export { DISCLAIMER };

export default {
  getAvatarResponse,
  AVATAR_DEFINITIONS,
  DISCLAIMER
};