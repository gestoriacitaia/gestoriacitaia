import { supabase } from '@/lib/supabaseClient';

class ConversationStorageService {
  
  async saveConversation({ userMessage, avatarResponse, language, sessionId }) {
    try {
      const { data, error } = await supabase
        .from('conversations')
        .insert([
          { 
            user_message: userMessage, 
            avatar_response: avatarResponse, 
            language,
            session_id: sessionId 
          }
        ]);

      if (error) {
        console.error('Error saving conversation:', error);
        return null;
      }
      return data;
    } catch (err) {
      console.error('Unexpected error in saveConversation:', err);
      return null;
    }
  }

  async saveAvatarSession({ avatarId, language, duration }) {
    try {
      const { data, error } = await supabase
        .from('avatar_sessions')
        .insert([
          { 
            avatar_id: avatarId, 
            language, 
            duration 
          }
        ])
        .select()
        .single();

      if (error) {
        console.error('Error saving avatar session:', error);
        return null;
      }
      return data;
    } catch (err) {
      console.error('Unexpected error in saveAvatarSession:', err);
      return null;
    }
  }
}

export const conversationStorageService = new ConversationStorageService();