import { useState, useEffect, useRef, useCallback } from 'react';
import { didVideoService } from '@/services/DIDVideoService';
import { elevenLabsAudioSync } from '@/services/ElevenLabsAudioSync';

export const useAvatarAnimation = (videoRef, avatarId = 'default') => {
  const [connectionState, setConnectionState] = useState('disconnected'); // disconnected, connecting, connected, error
  const [isSpeaking, setIsSpeaking] = useState(false);
  const sessionRef = useRef(null);

  const startSession = useCallback(async () => {
    if (!videoRef.current) return;
    
    try {
      setConnectionState('connecting');
      const session = await didVideoService.createVideoSession(videoRef.current, avatarId);
      sessionRef.current = session;
      setConnectionState('connected');
    } catch (error) {
      console.error("Failed to start avatar session:", error);
      setConnectionState('error');
    }
  }, [avatarId, videoRef]);

  const stopSession = useCallback(() => {
    didVideoService.disconnect();
    setConnectionState('disconnected');
    sessionRef.current = null;
  }, []);

  const speakText = useCallback(async (text, language = 'es') => {
    if (!text) return;
    
    setIsSpeaking(true);
    try {
      const voiceId = language === 'es' ? 'pNInz6obpgDQGcFmaJgB' : 'VR6AewGX3Rex9jLeOSn3';
      
      // 1. Get Audio
      const { audioBlob } = await elevenLabsAudioSync.generateSpeechWithTiming(text, voiceId);
      const audioUrl = URL.createObjectURL(audioBlob);

      // 2. Send to D-ID (simulated/real depending on env)
      await didVideoService.sendAudioStream(audioUrl);

      // 3. Play locally for fallback feedback since we are simulating D-ID backend
      const audio = new Audio(audioUrl);
      await audio.play();
      
      audio.onended = () => {
        setIsSpeaking(false);
      };
      
    } catch (error) {
      console.error("Animation Error:", error);
      setIsSpeaking(false);
    }
  }, []);

  useEffect(() => {
    return () => {
      stopSession();
    };
  }, [stopSession]);

  return {
    connectionState,
    isSpeaking,
    startSession,
    stopSession,
    speakText
  };
};