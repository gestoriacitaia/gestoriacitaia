import React from 'react';

// This hook and context have been deprecated as part of the removal of e-commerce functionality.
// Keeping empty exports to prevent build errors if there are lingering imports.

export const CartContext = React.createContext();

export const useCart = () => {
  console.warn('useCart is deprecated and should not be used.');
  return {
    cartItems: [],
    addToCart: async () => {},
    removeFromCart: () => {},
    updateQuantity: () => {},
    clearCart: () => {},
    getCartTotal: () => '0.00',
  };
};

export const CartProvider = ({ children }) => {
  return <>{children}</>;
};

export default useCart;