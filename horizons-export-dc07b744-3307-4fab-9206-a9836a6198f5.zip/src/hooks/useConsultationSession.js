import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { avatarChatHandler } from '@/services/AvatarChatHandler';
import { useAuth } from '@/contexts/SupabaseAuthContext';

export const useConsultationSession = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState([
    { role: 'assistant', text: "Hola, soy Miriam. ¿En qué puedo ayudarte hoy con tus trámites de extranjería?" }
  ]);
  const [loading, setLoading] = useState(false);

  const sendMessage = useCallback(async (text) => {
    if (!text.trim()) return;

    // 1. Add User Message
    const userMsg = { role: 'me', text, timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      // 2. Save User Message to DB
      if (user) {
        await supabase.from('tabla_sesiones_avatar').insert([{
          cliente_id: user.id,
          transcripcion: text,
          fecha_inicio: new Date().toISOString(),
          avatar_id: 'Miriam'
        }]);
      }

      // 3. Get Response
      const reply = await avatarChatHandler.sendMessage(text, messages);
      
      // 4. Add AI Message
      const aiMsg = { role: 'assistant', text: reply, timestamp: new Date().toISOString() };
      setMessages(prev => [...prev, aiMsg]);

      // 5. Save AI Response to DB (Update previous or insert new - simplifying to just insert for log)
      if (user) {
        await supabase.from('tabla_sesiones_avatar').insert([{
          cliente_id: user.id,
          respuesta_avatar: reply,
          fecha_inicio: new Date().toISOString(),
          avatar_id: 'Miriam'
        }]);
      }

    } catch (error) {
      console.error('Session Error:', error);
      setMessages(prev => [...prev, { role: 'system', text: "Error de conexión. Intenta de nuevo." }]);
    } finally {
      setLoading(false);
    }
  }, [messages, user]);

  return {
    messages,
    sendMessage,
    loading,
    currentUser: user
  };
};