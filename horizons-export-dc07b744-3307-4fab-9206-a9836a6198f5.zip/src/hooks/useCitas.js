import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';

export const useCitas = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getCitas = useCallback(async (clienteId) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_citas')
        .select('*')
        .eq('cliente_id', clienteId)
        .order('fecha_cita', { ascending: false });
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const getCitaById = useCallback(async (id) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_citas')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const createCita = useCallback(async (citaData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_citas')
        .insert([citaData])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateCita = useCallback(async (id, updates) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_citas')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteCita = useCallback(async (id) => {
    setLoading(true);
    try {
      // Often soft delete or cancel is preferred, but physical delete requested
      const { error } = await supabase
        .from('tabla_citas')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      return true;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    getCitas,
    getCitaById,
    createCita,
    updateCita,
    deleteCita
  };
};