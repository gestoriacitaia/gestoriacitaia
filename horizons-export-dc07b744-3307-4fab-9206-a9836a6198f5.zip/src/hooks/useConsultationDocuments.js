import { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { useToast } from '@/components/ui/use-toast';

export const useConsultationDocuments = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDocs, setGeneratedDocs] = useState(null);
  const { toast } = useToast();

  const generateDocuments = async (sessionData) => {
    setIsGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke('upload-consultation-documents', {
        body: sessionData
      });

      if (error) throw error;
      setGeneratedDocs(data.documentUrls);
      return data.documentUrls;

    } catch (error) {
      console.error("Doc Generation Error:", error);
      toast({ title: "Error", description: "Failed to generate documents.", variant: "destructive" });
      return null;
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadAllDocuments = async (urls) => {
    const zip = new JSZip();
    
    const promises = Object.entries(urls).map(async ([name, url]) => {
      const response = await fetch(url);
      const blob = await response.blob();
      zip.file(`${name}.pdf`, blob);
    });

    await Promise.all(promises);
    
    const content = await zip.generateAsync({ type: "blob" });
    saveAs(content, "consultation-documents.zip");
  };

  return {
    isGenerating,
    generatedDocs,
    generateDocuments,
    downloadAllDocuments
  };
};