import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';

export const useDocumentos = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getDocumentos = useCallback(async (clienteId) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_documentos')
        .select('*')
        .eq('cliente_id', clienteId)
        .order('fecha_subida', { ascending: false });
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const uploadDocumento = useCallback(async (file, clienteId, citaId = null, tipo = 'general') => {
    setLoading(true);
    try {
      // 1. Upload file to Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${clienteId}/${Date.now()}.${fileExt}`;
      const filePath = fileName;

      const { error: uploadError } = await supabase.storage
        .from('documentos')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('documentos')
        .getPublicUrl(filePath);

      // 2. Insert record in DB
      const { data, error: dbError } = await supabase
        .from('tabla_documentos')
        .insert([{
          cliente_id: clienteId,
          cita_id: citaId,
          nombre_documento: file.name,
          url_documento: publicUrl,
          tipo: tipo,
          verificado: false
        }])
        .select()
        .single();

      if (dbError) throw dbError;
      return data;

    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteDocumento = useCallback(async (id) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('tabla_documentos')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      return true;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateVerificado = useCallback(async (id, isVerified) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_documentos')
        .update({ verificado: isVerified })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    getDocumentos,
    uploadDocumento,
    deleteDocumento,
    updateVerificado
  };
};