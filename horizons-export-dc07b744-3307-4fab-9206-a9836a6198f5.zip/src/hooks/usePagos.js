import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';

export const usePagos = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getPagos = useCallback(async (clienteId) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_pagos')
        .select('*')
        .eq('cliente_id', clienteId)
        .order('fecha_pago', { ascending: false });
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const createPago = useCallback(async (pagoData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_pagos')
        .insert([pagoData])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updatePagoStatus = useCallback(async (id, status) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_pagos')
        .update({ estado: status })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const getPagoByStripeId = useCallback(async (stripeId) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_pagos')
        .select('*')
        .eq('stripe_payment_id', stripeId)
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    getPagos,
    createPago,
    updatePagoStatus,
    getPagoByStripeId
  };
};