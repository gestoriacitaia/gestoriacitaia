import { useState, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';

export const useReferralSystem = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const generateReferralLink = useCallback(async (userId) => {
    try {
      setLoading(true);
      const { data: user, error: fetchError } = await supabase
        .from('tabla_clientes')
        .select('referral_code')
        .eq('id', userId)
        .single();

      if (fetchError) throw fetchError;

      let code = user?.referral_code;
      if (!code) {
        code = `ref-${Math.random().toString(36).substring(2, 10)}`;
        const { error: updateError } = await supabase
          .from('tabla_clientes')
          .update({ referral_code: code })
          .eq('id', userId);
        if (updateError) throw updateError;
      }
      return `${window.location.origin}/ref/${code}`;
    } catch (err) {
      setError(err);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const trackReferral = useCallback(async (referrerCode, newUserId) => {
    try {
      const { data: referrer } = await supabase
        .from('tabla_clientes')
        .select('id')
        .eq('referral_code', referrerCode)
        .single();

      if (!referrer) return false;

      const { error } = await supabase
        .from('tabla_referidos')
        .insert({
          referrer_id: referrer.id,
          referred_user_id: newUserId,
          status: 'completed'
        });

      if (error) throw error;
      
      await checkAndAwardReward(referrer.id);
      return true;
    } catch (err) {
      console.error('Error tracking referral:', err);
      return false;
    }
  }, []);

  const getReferralCount = useCallback(async (userId) => {
    try {
      const { count, error } = await supabase
        .from('tabla_referidos')
        .select('*', { count: 'exact', head: true })
        .eq('referrer_id', userId)
        .eq('status', 'completed');
        
      if (error) throw error;
      return count || 0;
    } catch (err) {
      console.error('Error getting count:', err);
      return 0;
    }
  }, []);

  const checkAndAwardReward = useCallback(async (userId) => {
    try {
      const count = await getReferralCount(userId);
      const { count: rewardsCount } = await supabase
        .from('tabla_referral_rewards')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('reward_type', 'referral_milestone');

      const expectedRewards = Math.floor(count / 3);
      
      if (expectedRewards > (rewardsCount || 0)) {
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30);
        
        await supabase.from('tabla_referral_rewards').insert({
          user_id: userId,
          reward_type: 'referral_milestone',
          plan_type: 'Plan Estándar',
          expires_at: expiresAt.toISOString(),
          status: 'active'
        });

        // Update user plan
        await supabase.from('tabla_clientes').update({
          plan_actual: 'Plan Estándar (Referido)',
          fecha_inicio_plan: new Date().toISOString(),
          fecha_vencimiento: expiresAt.toISOString(),
        }).eq('id', userId);

        return true;
      }
      return false;
    } catch (err) {
      console.error('Error awarding:', err);
      return false;
    }
  }, [getReferralCount]);

  const getReferralRewards = useCallback(async (userId) => {
    try {
      const { data, error } = await supabase
        .from('tabla_referral_rewards')
        .select('*')
        .eq('user_id', userId)
        .order('activated_at', { ascending: false });
        
      if (error) throw error;
      return data || [];
    } catch (err) {
      console.error('Error fetching rewards:', err);
      return [];
    }
  }, []);

  const getReferralHistory = useCallback(async (userId) => {
     try {
       const { data, error } = await supabase
         .from('tabla_referidos')
         .select(`
           id, created_at, status,
           referred_user:tabla_clientes!referred_user_id (nombre, email)
         `)
         .eq('referrer_id', userId)
         .order('created_at', { ascending: false });
         
       if (error) throw error;
       return data || [];
     } catch (err) {
       console.error('Error fetching history', err);
       return [];
     }
  }, []);

  return {
    generateReferralLink,
    trackReferral,
    getReferralCount,
    checkAndAwardReward,
    getReferralRewards,
    getReferralHistory,
    loading,
    error
  };
};