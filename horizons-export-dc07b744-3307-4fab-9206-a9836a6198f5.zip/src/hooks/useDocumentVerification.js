import { useState } from 'react';
import { documentVerificationService } from '@/services/documentVerificationService';
import { useToast } from '@/components/ui/use-toast';

export const useDocumentVerification = (clienteId, citaId) => {
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState(null);
  const [lastUploadedDoc, setLastUploadedDoc] = useState(null);
  const { toast } = useToast();

  const uploadDocument = async (file, documentType) => {
    setIsVerifying(true);
    setVerificationResult(null);
    setLastUploadedDoc(null);

    try {
      const result = await documentVerificationService.uploadAndVerify(
        file, 
        documentType, 
        clienteId, 
        citaId
      );

      setLastUploadedDoc({
        name: result.document.nombre_documento,
        type: documentType
      });
      setVerificationResult(result.verification);

      if (result.verification.isValid) {
        toast({ title: "Document Verified", description: "The document is valid." });
      } else {
        toast({ title: "Verification Issues", description: "Issues detected with the document.", variant: "destructive" });
      }

      return result;
    } catch (error) {
      console.error("Verification Hook Error:", error);
      toast({ title: "Upload Failed", description: error.message, variant: "destructive" });
      return null;
    } finally {
      setIsVerifying(false);
    }
  };

  return {
    uploadDocument,
    isVerifying,
    verificationResult,
    lastUploadedDoc
  };
};