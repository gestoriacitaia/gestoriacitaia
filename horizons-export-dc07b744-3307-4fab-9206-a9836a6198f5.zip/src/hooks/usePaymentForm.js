import { useState } from 'react';

export const usePaymentForm = (initialState = {}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    countryCode: '+34',
    serviceType: '',
    selectedPlan: null,
    ...initialState
  });

  const [errors, setErrors] = useState({});

  const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validatePhone = (phone) => {
    // Basic validation for length, allowing spaces and dashes
    return phone.replace(/[\s-]/g, '').length >= 6;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };

  const handlePlanSelect = (planId) => {
    setFormData(prev => ({ ...prev, selectedPlan: planId }));
    if (errors.selectedPlan) {
      setErrors(prev => ({ ...prev, selectedPlan: null }));
    }
  };

  const handleServiceSelect = (value) => {
    setFormData(prev => ({ ...prev, serviceType: value }));
    if (errors.serviceType) {
      setErrors(prev => ({ ...prev, serviceType: null }));
    }
  };
  
  const handleCountryCodeChange = (code) => {
    setFormData(prev => ({ ...prev, countryCode: code }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = 'El nombre es requerido';
    if (!formData.email.trim()) {
      newErrors.email = 'El email es requerido';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Email inválido';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'El teléfono es requerido';
    } else if (!validatePhone(formData.phone)) {
      newErrors.phone = 'Teléfono inválido';
    }

    if (!formData.serviceType && !formData.selectedPlan) {
       // Optional check depending on form usage, but usually we need at least one intent
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      countryCode: '+34',
      serviceType: '',
      selectedPlan: null,
      ...initialState
    });
    setErrors({});
  };

  return {
    formData,
    errors,
    handleChange,
    handleCountryCodeChange,
    handlePlanSelect,
    handleServiceSelect,
    validateForm,
    resetForm
  };
};