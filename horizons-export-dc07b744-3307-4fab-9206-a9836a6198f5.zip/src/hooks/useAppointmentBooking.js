import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { appointmentAvailabilityService } from '@/services/AppointmentAvailabilityService';

export const useAppointmentBooking = (clienteId, avatarId) => {
  const [step, setStep] = useState('calendar'); // calendar, time, confirm
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [availableDates, setAvailableDates] = useState([]);
  const [availableSlots, setAvailableSlots] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const searchAvailableSlots = useCallback(async (startDate) => {
    setIsLoading(true);
    try {
      // Calculate end date (e.g., 14 days from start)
      const end = new Date(startDate);
      end.setDate(end.getDate() + 14);

      const { data, error } = await supabase.functions.invoke('search-available-appointments', {
        body: {
          avatarId,
          startDate: startDate.toISOString(),
          endDate: end.toISOString()
        }
      });

      if (error) throw error;
      
      setAvailableDates(data.availableDates);
      setAvailableSlots(data.slots);

    } catch (error) {
      console.error("Availability Search Error:", error);
      toast({ title: "Error", description: "Could not fetch availability.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [avatarId, toast]);

  const selectDate = (date) => {
    setSelectedDate(date);
    setStep('time');
  };

  const selectTime = (time) => {
    setSelectedTime(time);
    setStep('confirm');
  };

  const confirmAppointment = async () => {
    setIsLoading(true);
    try {
      if (!selectedDate || !selectedTime) throw new Error("Missing details");
      
      const appointmentDate = new Date(selectedDate);
      const [hours, minutes] = selectedTime.split(':');
      appointmentDate.setHours(parseInt(hours), parseInt(minutes));

      const { data, error } = await supabase
        .from('tabla_citas')
        .insert([{
          cliente_id: clienteId,
          avatar_id: avatarId,
          fecha_cita: appointmentDate.toISOString(),
          estado: 'confirmada',
          fecha_creacion: new Date().toISOString(),
          notas: 'Booked via interactive session'
        }])
        .select()
        .single();

      if (error) throw error;
      
      setStep('success');
      return data;

    } catch (error) {
      console.error("Booking Error:", error);
      toast({ title: "Booking Failed", description: error.message, variant: "destructive" });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const resetFlow = () => {
    setStep('calendar');
    setSelectedDate(null);
    setSelectedTime(null);
  };

  return {
    step,
    setStep,
    selectedDate,
    selectedTime,
    availableDates,
    getSlotsForDate: (date) => {
       const key = date.toISOString().split('T')[0];
       return availableSlots[key] || [];
    },
    searchAvailableSlots,
    selectDate,
    selectTime,
    confirmAppointment,
    resetFlow,
    isLoading
  };
};