import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';

export const useClientes = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getClientes = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('tabla_clientes').select('*');
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const getClienteById = useCallback(async (id) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_clientes')
        .select('*')
        .eq('id', id)
        .single();
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const createCliente = useCallback(async (clienteData) => {
    setLoading(true);
    try {
      // Ensure we use the current user's ID for safety if not provided
      const { data: { user } } = await supabase.auth.getUser();
      
      const payload = {
        id: user?.id,
        ...clienteData
      };

      const { data, error } = await supabase
        .from('tabla_clientes')
        .insert([payload])
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateCliente = useCallback(async (id, updates) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tabla_clientes')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteCliente = useCallback(async (id) => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('tabla_clientes')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      return true;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    loading,
    error,
    getClientes,
    getClienteById,
    createCliente,
    updateCliente,
    deleteCliente
  };
};