# Supabase Integration Guide

This project is configured to use Supabase for secure backend operations (Edge Functions) and database storage.

## 1. Environment Setup

Create a project at [supabase.com](https://supabase.com).

Copy your credentials to `.env.local`: